#!/bin/bash

#---------------------------------------------------------------------------
#
#   File:       cluster_runtime_setup.sh
#   Created:    15-Dec-2023 11:16:00
#   Creator:    Alekh Chaudhary
#   $Revision:$
#   $Id:$
#
#===========================================================================
# This software and related information is confidential and proprietary to
#   Intec Telecom Systems and may not be disclosed, copied, modified, or
#otherwise used except in accordance with the licence agreement entered into
#with Intec.  This information is protected by international copyright laws
#  and any unauthorised use thereof may violate copyright, trademark, and
#other laws.  Any unauthorised use of this software and/or information will
#automatically terminate your right to use this software and/or information.
#
#              (c) Independent Technology Systems Limited 1997-2004
#               (An Intec Telecom Systems PLC Group Company).
#                           All Rights Reserved.
#===========================================================================
#
# USAGE:
#
#
# DESCRIPTION:
#     Shell script to exeute recreate pcs cluster, create SV HA cluster
#     resources and start HA resources.
#     Script also create test data for traffic generation.
#
#---------------------------------------------------------------------------

typeset prog="cluster_runtime_setup"
typeset log="$(pwd)/$prog.$TEST_SUITE.$TEST_GROUP.log"
typeset out="$(pwd)/_$$.cmd"
typeset failure=0

#-------------------------------------------------------------------------------
# _log
#   Description
#      Prints a log message in following format
#      <timestamp> <programm name>:: <log message>
#   parameters
#   - Log message
#-------------------------------------------------------------------------------
function _log {
    ### Display a message
    typeset msg="$(date +'%Y-%m-%d %H:%M:%S.%3N') ${prog}:: $*"
    echo "$msg"
    echo "$msg" >> "$log"
}

cd ${HOME}

_log "Update CPU to 4, CB_CPU to 3 in ubbconfig.tpl on svrollupg1"
sudo sed -i'.bak' -e 's/^CPUS.*2$/CPUS		4/' -e 's/^CB_CPUS.*2$/CB_CPUS		3/' $ATA_DATA_SERVER_CONFIG/ubbconfig.tpl

_log "Update CPU to 4, CB_CPU to 3 in ubbconfig.tpl on svrollupg2"
ssh svrollupg2 <<EOF
    sudo sed -i'.bak' -e 's/^CPUS.*2$/CPUS		4/' -e 's/^CB_CPUS.*2$/CB_CPUS		3/' \$ATA_DATA_SERVER_CONFIG/ubbconfig.tpl
EOF

_log "Update CPU to 4, CB_CPU to 3 in ubbconfig.tpl on svrollupg3"
ssh svrollupg3 <<EOF
    sudo sed -i'.bak' -e 's/^CPUS.*2$/CPUS		4/' -e 's/^CB_CPUS.*2$/CB_CPUS		3/' \$ATA_DATA_SERVER_CONFIG/ubbconfig.tpl
EOF

_log "Run cluster reconfigure and start SV....."
sudo chmod +x ${ATA_HOME}/cluster_reconfig.sh
$ATA_HOME/cluster_reconfig.sh 

cfg THP_TREREST_IN1 ENABLED -v 1
cfg THP_TREREST_IN2 ENABLED -v 1
cfg THP_TREREST_IN3 ENABLED -v 1

# Uninstalling ECCS
_log  "Uninstalling ECCS....."
$HOME/svtest-upgradeproc/tests/eccs_uninstall.sh
RC=$?
if [ $RC -ne 0 ]; then
    _log  "Failed to uninstall ECCS..."
    exit ${RC}
fi

_log "Start SV....."
sv_start -cluster
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to start SV...'
    exit ${RC}
fi

export TH_INCLUDE_PATH=$TH_INCLUDE_PATH:$HOME/svtest-upgradeproc/tests
echo $TH_INCLUDE_PATH
_log "Creating Product data....."
epmtestharness $HOME/svtest-upgradeproc/tests/create_svrollupg_product_data.eth
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to create product data...'
    exit ${RC}
fi

_log "Creating Customer data....."
epmtestharness $HOME/svtest-upgradeproc/tests/create_svrollupg_customer_data.eth
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to create customer data...'
    exit ${RC}
fi

_log 'Run CE Traffic Generation setup...'
epmtestharness $HOME/svtest-upgradeproc/tests/cesetup.eth
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to create customer data...'
    exit ${RC}
fi


_log 'Wait for cluster_reconfig to finish.....'
parallel --retries 30 --delay 15 ::: 'pcs status | grep "Online"|grep "svrollupg1 svrollupg2 svrollupg3"'
RC=$?
if [ $RC -ne 0 ]; then
    _log 'HA cluster refusing to start'
    exit ${RC}
fi

_log "Setting up session conitinuity and updating CustomerPartition DA....."
epm $ATA_HOME/sv_test/Library/EpmTestharness/svrollupg_sessioncont_and_cluster_config.epm
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to setup session continuity...'
    exit ${RC}
fi
epm $ATA_HOME/sv_test/Library/Utils/svrollupg_update_customer_partition.epm
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to update cutomer partition DA...'
    exit ${RC}
fi

echo $DEV_HA_VIP1
da_dump CustomerPartition
da_dump ClusterResource

_log "Resatring SV after session continuity and customer partition setup....."
sv_stop -cluster
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to stop SV...'
    exit ${RC}
fi

sv_start -cluster
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Failed to start SV...'
    exit ${RC}
fi

_log "Create HA cluster resources....."
sv_ha_ctl cluster_create
RC=$?
if [ $RC -ne 0 ]; then
    _log 'Cluster resource creation failed...'
    exit ${RC}
fi
pcs property set stonith-enabled=true
_log "Start HA cluster resource....."
sv_ha_ctl cluster_start
RC=$?
if [ $RC -ne 0 ]; then
    _log 'HA cluster resources start failed...'
    exit ${RC}
fi

_log "Check HA cluster resource status....."
sv_ha_ctl cluster_status
RC=$?
if [ $RC -ne 0 ]; then
    _log 'HA cluster resource status check failed...'
    exit ${RC}
fi

exit 0

