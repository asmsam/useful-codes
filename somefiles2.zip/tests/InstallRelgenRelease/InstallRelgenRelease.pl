#!/usr/bin/env perl
use strict;
use Getopt::Long;
use VerifyInstallation;
use POSIX qw(strftime);
use Cwd qw(getcwd);


my $zrelInfo;  # array reference
my @zserversInfo; # array containing hash of file details

our $zinstallOut = "$ENV{ATA_HOME}/InstallSVUpgrade.out";
our $zinstallLog = "$ENV{ATA_HOME}/InstallSVUpgrade.log";

use constant INSTALL_TIMEOUT => 3600;
my $zpackage ;
my $COLD_INSTALL = "cold";

sub RunInstall
{
    my ($package, $installOut, $installLog, $timeout, $installMode ) = @_;
    $installMode = 'warm' if (!$installMode);

    my $version = $package;
    $version =~ s/(.*)_(.*)_(.*)_(.*)\.tar\.gz/$2/;

    system("cd $ENV{HOME}/svtest-upgradeproc/tests");
    my $untar_cmd = "tar -zxvf $package -C ./test_results";
    my $install_file = "./test_results/$version/install.$version";

    print("Untarring install package $package \n");
    system($untar_cmd);
    if (!-d "./test_results/$version") {
        print("Untarring failed, directory ./test_results/$version does not exist\n");
    }
    if (!-e "$ENV{HOME}/svtest-upgradeproc/tests/$install_file") {
        print("Untarring failed, install file $install_file does not exist\n");
        exit 1;
    }

    my $date = strftime "%m/%d/%Y %H:%M:%S", localtime;
    print $date . "\n";

    my $install_cmd = "$install_file -ni -installmode cold >/dev/null 2>&1";
    warn "Running relgen installer command: $install_cmd\n" ;
    eval {
        `$install_cmd`;
    };

    warn "Install process completed.\n" ;

    1;
}

sub PerformSVUpgrade
{

    $zpackage = "$ENV{ATA_HOME}/$ENV{RELGEN_PACKAGE_NAME}";
    if (!defined($zpackage)) {
        print "SV MINOR PACKAGE not found";
        exit 1;
    }
    RunInstall($zpackage, $zinstallOut, $zinstallLog, INSTALL_TIMEOUT , $COLD_INSTALL);
    print "$zpackage\n";

}

sub CheckInstallationErrors
{
    my $packageName = "V" . "$ENV{TO_VERSION}";
    my $logFileName = `ls $ENV{HOME}/svtest-upgradeproc/tests/test_results/$packageName/install.$packageName.SVWDEV.*.log`;
    $logFileName =~ s/\n//;
    print "install log file name is " . $logFileName;
    my $rc = VerifyInstallation->CheckInstallationResultsForErrors($logFileName);
    if (!$rc) {
        print "Installation failed.";
        exit 1;
    }
    VerifyInstallation->AssertInstallRanOnInstances("CLUSTER", $zpackage);
    VerifyInstallation->AssertReleaseVersion("CLUSTER", "$ENV{TO_VERSION}");
    print "All verifications Done\n";
}


# Main code
print "Starting SV Minor Upgrade process\n";

VerifyInstallation->InitClusterInfo();
print "*********Cluster Information fetched successfully**********\n";

VerifyInstallation->MoveSTD('SV2');
print "********STD is now on SV2*******\n";

PerformSVUpgrade();
print "************ Upgrade SV Completed *********\n";

CheckInstallationErrors();
print "********* All Verifications Done *********\n";

exit 0;
