#!/usr/bin/expect -f

set timeout -1

spawn $::env(ATAI_REL_SERVER_BIN)/eccs -i uninstall

expect "?\r"

send -- "y\r"

expect "?\r"

send -- "y\r"

expect eof
