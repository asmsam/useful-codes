#!/bin/bash
#---------------------------------------------------------------------
# File:    install_perestapi.sh
# Created: 12-Oct-2023 04:05:20
# Creator: nasmd001 (Md Naseem)
#=====================================================================
# COPYRIGHT (c) 2017 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS
# AFFILIATES ( CSG ). ALL RIGHTS RESERVED.
#
# THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY
# TO CSG AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED
# EXCEPT IN ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG.
# THIS INFORMATION IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY
# UNAUTHORIZED USE THEREOF MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER
# LAWS. ANY UNAUTHORIZED USE OF THIS SOFTWARE AND/OR INFORMATION WILL
# AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS SOFTWARE AND/OR
# INFORMATION.
#=====================================================================
# USAGE:
#       ./install_perestapi.sh
#
# DESCRIPTION:
#       This script installs perestapi code pack
# Note:
# This script is used for temporary purpose until the mms container 
# contains the perest api code pack from ADO. This script is not 
# required and can be deleted once perest code pack officially 
# migrated to ADO and part of mms container
#---------------------------------------------------------------------

if svversion -a | grep -q "perestapi"; then
    echo "perestapi codepack is already installed"
else
    cp ./../config/perestapi.11.00.07.tar.gz $ATAI_SRC/deli
    cd $ATAI_SRC/deli
    gzip -cd perestapi.11.00.07.tar.gz | tar xf -
    cd perestapi
    make
    make install
    make messages
    sv_stop -pe
    pe_archive -x -d -r -7 -o -f $ATAI_REL_SERVER_INSTALL/UI_PE_archive.exp -script 'update_last_mod_user 7 -c'
    pe_archive -x -d -r -7 -o -f $ATAI_REL_SERVER_INSTALL/UI_PE_OthersArchive.exp -script 'update_last_mod_user 7 -c'
    sv_start –pe
    deli_install ux_base -dir PE -noowner -ifnotmod -remap 50000
    deli_install perestapi -dir config -noowner -ifnotmod -remap 495000
    deli_install perestapi.sample -dir config -noowner -ifnotmod -remap 595000
    ecpsql 'fSIL_UpgradeCreateFullAccessCoreNoAlias&(1)'
    ecpsql 'fSIL_UpgradeCreateFullOtherAccess&(4)'
    genfast -p
    sv_stop; sv_start
    echo "perestapi codepack installation completed"
fi
