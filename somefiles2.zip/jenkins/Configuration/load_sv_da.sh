#!/bin/ksh

echo "Loading SV DA configuration"
rt_load -s ATA_DB_INSTANCE rt_ATA_DB_INSTANCE.csv
rt_load -s ATA_INSTANCE rt_ATA_INSTANCE.csv
da_load -s DBInstance.csv DBInstance
sqlplus $ATADBACONNECT @InstanceStatusDa.sql
#da_load -s InstanceStatus.csv InstanceStatus
cfg -f BMP_ConfigItem.ini
cfg -f LICENCE_ConfigItem.ini
cfg -f CACHE_CONFIG_BKR_ConfigItem.ini
cfg -f BKR.ini

sqlplus -s $ATADBACONNECT <<EOS
whenever sqlerror exit sql.sqlcode;
set echo on
set termout on

update configuration_attribute set value=1 where CONFIGURATION_ATTR_TYPE_ID in (122, 123, 230, 231, 737);
commit;

exit success;

EOS

echo "Successfully completed Loading of SV DA."
