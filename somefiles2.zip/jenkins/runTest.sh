#!/bin/ksh
#---------------------------------------------------------------------------
#
#   File:       runtest.sh
#   Created:    26-Oct-2023 10:13:01
#   Creator:    Kunal Parekh
#   $Revision:  $ 501552
#   $Id: runtest.sh,v 1.0 2023/10/26 10:13:01 parkun01 Exp $
#
#===========================================================================
# This software and related information is confidential and proprietary to
#   Intec Telecom Systems and may not be disclosed, copied, modified, or
#otherwise used except in accordance with the licence agreement entered into
#with Intec.  This information is protected by international copyright laws
#  and any unauthorised use thereof may violate copyright, trademark, and
#other laws.  Any unauthorised use of this software and/or information will
#automatically terminate your right to use this software and/or information.
#
#              (c) Independent Technology Systems Limited 1997-2004
#               (An Intec Telecom Systems PLC Group Company).
#                           All Rights Reserved.
#===========================================================================
#
# USAGE:
#
#
# DESCRIPTION:
#     Shell script to exeute tests for the sv rolling upgrade using the 
#     Test Harness.
#
#---------------------------------------------------------------------------

typeset prog="runTest"
typeset log="$(pwd)/$prog.$TEST_SUITE.$TEST_GROUP.log"
typeset out="$(pwd)/_$$.cmd"
typeset failure=0

#-------------------------------------------------------------------------------
# _log
#   Description
#      Prints a log message in following format
#      <timestamp> <programm name>:: <log message>
#   parameters
#   - Log message
#-------------------------------------------------------------------------------
function _log {
    ### Display a message
    typeset msg="$(date +'%Y-%m-%d %H:%M:%S.%3N') ${prog}:: $*"
    echo "$msg"
    echo "$msg" >> "$log"
}

#-------------------------------------------------------------------------------
# _cmd
#   Description
#      Executes a given command and writes the output to STDOUT and log file.
#   parameters
#   - Command to execute
#-------------------------------------------------------------------------------
function _cmd {
    ### Display and run a command, showing output
    _log "$*"
    "$@" > "$out" 2>&1
    typeset ret=$?
    cat "$out"
    cat "$out" >> "$log"
    return $ret
}

#-------------------------------------------------------------------------------
# insertRegressStep
#   parameters
#   -  Start Date
#   -  test Result
#   -  test Case
#-------------------------------------------------------------------------------
function insertRegressStep
{
    typeset startD=${1}
    typeset testResult=${2}
    typeset testCase="${3}"
    typeset endD diffD

    typeset jenkinsBuildLogUrl=${S3_LOG_BASEURL}/${TEST_GROUP}/attempt${ATTEMPT_NUM}/${TEST_GROUP}.log

    if [ ! -z "$JENKINS_BUILD_TAG" ]; then
        endD=`perl -e "print time;"`
        diffD=$(( $endD - $startD ))

        ####perl $HOME/TestDB/insert_regress_step.pl \
        $ATA_HOME/sv_test/Library/Utils/insert_regress_step.pl \
            -step=test \
            -jenkinstag=$JENKINS_BUILD_TAG \
            -fulllog=${jenkinsBuildLogUrl} \
            -duration=${diffD} \
            -result=${testResult} \
            -module="${TEST_GROUP}_${FROM_VERSION}" \
            -testcase="${testCase}"
    else
        echo "JENKINS_BUILD_TAG is not defined: skipping inserting '${TEST_GROUP}/${testCase}' result=${testResult} into TestDB"
    fi
}

#-------------------------------------------------------------------------------
# zexit
#     Standard exit Routine to
#     -  Collect logs and store in S3://
#     -  Collect artifacts and store in S3://
#-------------------------------------------------------------------------------
function zexit
{
    echo "### Start zexit ###"

    _cmd cd /svw/svwdev/work/svwdev/TestDB
    insertRegressStep ${STARTD} ${TESTDB_RC} "make ${TEST_GROUP}"

    typeset s3Base
    s3Base="${S3_LOG_LOCATION}/${TEST_GROUP}/attempt${ATTEMPT_NUM}"

    echo "Remove release files on svrollupg1"
    cd ${HOME}/svtest-upgradeproc/tests/test_results/${PACKAGE_NAME}/
    rm -fv !(install.${PACKAGE_NAME}.SVWDEV.*.log|"install.${PACKAGE_NAME}")
    rm -f .eccs_manifest.*

    _log "Remove release files on svrollupg2"
    _cmd ssh svrollupg2 <<EOF
        cd \$HOME/svtest-upgradeproc/tests/test_results/${PACKAGE_NAME}/
        rm -fv !(install.${PACKAGE_NAME}.SVWDEV.*.log|"install.${PACKAGE_NAME}")
        rm -f .eccs_manifest.*
EOF

    _log "Remove release files on svrollupg3"
    _cmd ssh svrollupg3 <<EOF
        cd \$HOME/svtest-upgradeproc/tests/test_results/${PACKAGE_NAME}/
        rm -fv !(install.${PACKAGE_NAME}.SVWDEV.*.log|"install.${PACKAGE_NAME}")
        rm -f .eccs_manifest.*
EOF

    cd ${WORKSPACE}

    for instance in svrollupg1 svrollupg2 svrollupg3
    do
        echo ''
        echo "Collecting build/test log files on ${instance}"
        mkdir -p ${instance}
        scp -rq ${USER}@${instance}:${FULL_TEST_DIR}/test_results ${instance}/.
        scp -rq ${USER}@${instance}:${ATA_HOME}/data/server/log ${instance}/.
        # Copy CE traffic log file
        if [ ${instance} == 'svrollupg1' ]
        then
            mkdir -p ${instance}/Traffic_Logs/
            scp -q ${USER}@${instance}:${HOME}/svtest-upgradeproc/tests/ce_traffic_message_* ${instance}/Traffic_Logs/.
            scp -q ${USER}@${instance}:${HOME}/svtest-upgradeproc/tests/Log/Global* ${instance}/Traffic_Logs/.
        fi
    done
    echo ''

    echo 'Archive artifacts'
    tar -zcf artifacts.tar.gz *
    # If artifacts exist and JENKINS_BUILD_TAG is defined
    if [ -f artifacts.tar.gz ] && [ ! -z "$JENKINS_BUILD_TAG" ]; then
        echo ''
        echo 'Store archives in S3'
        cd ${WORKSPACE}
        aws s3 cp artifacts.tar.gz "${s3Base}/artifacts.tar.gz"
    elif [ -z "$JENKINS_BUILD_TAG" ]; then
        # Assume this is a non-CT run, no need to store artifacts in S3
        echo "JENKINS_BUILD_TAG is not defined: skipping storing archives in S3"
    fi

    echo "### End: zexit ###"
}

#-------------------------------------------------------------------------------
# prepareEnvForUpgrade
#   Description
#      Prepares the 3 nodes of a SV cluster for upgrade. Which includes
#      - Adjusting the env variables on other 2 instances.
#      - Updating cluster configuration
#      - Creating SV HA cluster and starting it.
#   parameters
#      None
#-------------------------------------------------------------------------------
function prepareEnvForUpgrade
{
    _log "Relax permissions on /shared as it is a docker volume created by root"
    _cmd sudo chmod 777 /shared

    sudo chmod +x /usr/sbin/fence_docker_ct
    sudo chmod +x /svw/svwdev/fence_docker_ct
    sudo chmod 777 $ATA_HOME/sv/

    # email.xml issue
    sudo chmod 777 /shared/
    mkdir -p /shared/config/email/
    sudo chmod u+rw /shared/config/email/

    # Upgrade tuxedo to 22
    if [ "$FROM_MINOR_VERSION" -le "04" ] && [ "$TO_MINOR_VERSION" -ge "05" ]; then
        _log "Installing tuxedo on svrollupg1"
        sudo dnf config-manager --add-repo http://yum-svrnd.csgicorp.com/repos/el8_sv.repo
        sudo rpm --import http://yum-svrnd.csgicorp.com/repos/RPM-GPG-KEY-SVAPP
        TUXEDO_PACKAGE_NAME='tuxedo-sv-22.1.0.0.0-1.el8.x86_64.rpm'
        TUXEDO_PACKAGE_URL="http://yum-svrnd.csgicorp.com/repos/ol/8/stable/x86_64/${TUXEDO_PACKAGE_NAME}"
        curl -O ${TUXEDO_PACKAGE_URL}
        sudo rpm -i ${TUXEDO_PACKAGE_NAME}
        rm -rf ${TUXEDO_PACKAGE_NAME}
        _log "Installing tuxedo on svrollupg2"
        _cmd ssh svrollupg2 <<EOF
            sudo dnf config-manager --add-repo http://yum-svrnd.csgicorp.com/repos/el8_sv.repo
            sudo rpm --import http://yum-svrnd.csgicorp.com/repos/RPM-GPG-KEY-SVAPP
            curl -O ${TUXEDO_PACKAGE_URL}
            sudo rpm -i ${TUXEDO_PACKAGE_NAME}
            rm -rf ${TUXEDO_PACKAGE_NAME}
EOF
        _log "Installing tuxedo on svrollupg3"
        _cmd ssh svrollupg3 <<EOF
            sudo dnf config-manager --add-repo http://yum-svrnd.csgicorp.com/repos/el8_sv.repo
            sudo rpm --import http://yum-svrnd.csgicorp.com/repos/RPM-GPG-KEY-SVAPP
            curl -O ${TUXEDO_PACKAGE_URL}
            sudo rpm -i ${TUXEDO_PACKAGE_NAME}
            rm -rf ${TUXEDO_PACKAGE_NAME}
EOF
    fi
    # Adjust ATA_INSTANCE and ATA_LICENCE env vars on other instances
    # because we are using a single image from instance SV1 to run
    # all instances
    # NOTE: For PE HA, SV1 is the ACTIVE instance, SV2 is the STANDBY
    # instance and PE is not started on the SV3 instance.
    _log "Updating env vars on svrollupg2"
    _cmd ssh svrollupg2 <<EOF
        sed -i s/ATA_INSTANCE=SV1/ATA_INSTANCE=SV2/ ${ATA_HOME}/clusterenv
        sed -i s/ATA_LICENCE=LICENCE1/ATA_LICENCE=LICENCE2/ ${ATA_HOME}/clusterenv
        sudo chmod +x /usr/sbin/fence_docker_ct
        sudo chmod +x /svw/svwdev/fence_docker_ct
        sudo chmod 777 $ATA_HOME/sv/
EOF

    _log "Updating env vars on svrollupg3"
    _cmd ssh svrollupg3 <<EOF
        sed -i s/ATA_INSTANCE=SV1/ATA_INSTANCE=SV3/ ${ATA_HOME}/clusterenv
        sed -i s/ATA_LICENCE=LICENCE1/ATA_LICENCE=LICENCE3/ ${ATA_HOME}/clusterenv
        sed -i s/ATA_SV_START_OPTIONS=.*/ATA_SV_START_OPTIONS="\" \-nope\"/" ${ATA_HOME}/clusterenv
        echo ${ATA_SV_START_OPTIONS}
        sudo chmod +x /usr/sbin/fence_docker_ct
        sudo chmod +x /svw/svwdev/fence_docker_ct
        sudo chmod 777 $ATA_HOME/sv/
EOF

    # Running archive command to remove external definitions 
    # This is workaround due to the issue in ed_schema_write.
    # This should be removed once ed_schema_write issue is fixed.
    archive -x -xml -z 1 -noext -t ExternalDefinitionNamespaceAll -f external_definition.xml -w "NAMESPACE in ('allowancexfer', 'balxfer' ,'mnp.imp' ,'sdaCommonBusinessEntity' ,'sdaCustomer' ,'sdaProduct')" -p
    archive -x -xml -z 1 -noext -t InterfaceDefinitions -f interface_definition.xml -w "INTERFACE_DEFN_NAME in ('AccelerateOutboundTemplate', 'AccelerateInboundAPITemplate' ,'MNPOutbound_T' ,'MNPInbound_T' ,'BalanceTransferInbound' ,'AllowanceTransferInbound')" -p


    echo "Perform cluster resource setup and start the cluster resources......"
    _cmd sudo chmod +x ${FULL_TEST_DIR}/cluster_runtime_setup.sh
    _cmd ${FULL_TEST_DIR}/cluster_runtime_setup.sh
    RC=$?
    if [ $RC -ne 0 ]; then
        echo "***  Failed to prepare environment. Cluster setup failed."
        exit ${RC}
    fi

    echo ''
    echo 'Environment prepared for upgrade test - Success'
}

#-------------------------------------------------------------------------------
# relegenReleaseDownload
#   Description
#      Downloades the relegen release package from the artifacts location
#      of relgen CT (RELGEN_BuildAndExecuteTests). Uses loation of latest
#      V12 main line (trunk) CT run.
#      - Adjusting the env variables on other 2 instances.
#      - Updating cluster configuration
#      - Creating SV HA cluster and starting it.
#   parameters
#      None
#-------------------------------------------------------------------------------
function relegenReleaseDownload
{
    # Download tar package and replace sv_install_release.pl
    echo "Downloading relgen release package."
    cd ${HOME}
    mkdir extract
    if ! echo ${JENKINS_BUILD_TAG} | grep -Eq "jenkins-RollingUpgrade_BuildAndExecuteTests-"; then
        cd $ATAI_REL
        tar -cf ${PACKAGE_NAME}.methods.tar *
        mv ${PACKAGE_NAME}.methods.tar $HOME/extract
    fi
    cd $HOME/extract

    echo "relgenpkgLocation: ${RELGEN_PACKAGE_URL}"
    echo "relgenpkgName: ${RELGEN_PACKAGE_NAME}"

    aws s3 sync --no-progress --exclude "*" --include "${RELGEN_PACKAGE_NAME}" ${RELGEN_PACKAGE_URL} .
    RC=$?
    if [ $RC -ne 0 ]; then
        echo "***  Failed to download packages from S3"
        exit ${RC}
    fi

    tar -xzf ${RELGEN_PACKAGE_NAME}
    cd ${PACKAGE_NAME}
    sed -i "s/opt_export = 1/opt_export = 0/" install.${PACKAGE_NAME}
    sed -i "s/opt_dvp = 1/opt_dvp = 0/" install.${PACKAGE_NAME}
    sed -i "s/\s*(\$INTERACT\s?\s'\s-i'\s:\s'')\s\.*/\0 \n                        (\$NONINTERACT ? ' -ni' : '') ./" install.${PACKAGE_NAME}
    if ! echo ${JENKINS_BUILD_TAG} | grep -Eq "jenkins-RollingUpgrade_BuildAndExecuteTests-"; then
        rm -rf ${PACKAGE_NAME}.methods.tar
        cp ./../${PACKAGE_NAME}.methods.tar ${PACKAGE_NAME}.methods.tar
        _cmd pwd 
        _cmd ls
    fi
    cd ..
    tar -czf ${RELGEN_PACKAGE_NAME} ${PACKAGE_NAME}
    mv ${RELGEN_PACKAGE_NAME} $ATA_HOME
    echo "Relgen release package downloaded."

}

#---------------------------------------------------------------------
# Main script body
#---------------------------------------------------------------------
rm -f "$log"
if [ -z ${TEST_GROUP} ];then
    _log "No test provided"
    _log "Exiting on failure"
    exit 2
fi

_log "Started for test suite=${TEST_SUITE} group=${TEST_GROUP} type=${TEST_TYPE}"

TESTDB_RC=2     # Default make result

# ### Collect Logs and artifacts upon exit
trap zexit EXIT

FULL_TEST_DIR=${HOME}/svtest-upgradeproc/tests

# Ensure $WORKSPACE is set and empty.
if [ -z ${WORKSPACE} ]; then
    WORKSPACE=${HOME}/test-artifacts
fi
_cmd rm -rf ${WORKSPACE}
_cmd mkdir -p ${WORKSPACE}
_cmd ls ${WORKSPACE}
_cmd mkdir -p /svw/svwdev/work/svwdev/TestDB
_cmd export LD_LIBRARY_PATH=/lib64:$LD_LIBRARY_PATH

_cmd cd /svw/svwdev/work/svwdev/TestDB
_cmd svn export svn://brirepo/svapp/trunk/TestDB/TestDBAccess.pm
_cmd svn export svn://brirepo/svapp/trunk/TestDB/IntermittentReport.pm
_cmd svn export svn://brirepo/cb/trunk/server/src/util/insert_regress_step.pl
_cmd export PERL5LIB=/svw/svwdev/work/svwdev/TestDB:$PERL5LIB

# we are adding all the test cases as missed before executing test groups.
STARTD=`perl -e "print time;"`
insertRegressStep ${STARTD} 3 "make ${TEST_GROUP}"

FROM_MINOR_VERSION=$(echo "${FROM_VERSION}" | cut -d '.' -f 3)
_log "FROM_MINOR_VERSION=${FROM_MINOR_VERSION}"

TO_MINOR_VERSION=$(echo "${TO_VERSION}" | cut -d '.' -f 3)
_log "TO_MINOR_VERSION=${TO_MINOR_VERSION}"

PACKAGE_NAME="V${TO_VERSION}"
_log "PACKAGE_NAME=${PACKAGE_NAME}"


if [ "$FROM_MINOR_VERSION" -lt "18" ]; then
    # Fix pe.vip Issue
    echo "Updating CM_Pacemaker.pm for env with less than 11.00.18"
    sudo sed -i 's/cidr_netmask=\$lmask/cidr_netmask=\$lmask nic=eth0/' /svw/svwdev/rel/server/perlmod/CM_Pacemaker.pm
fi

prepareEnvForUpgrade

relegenReleaseDownload

_cmd sv_version
_cmd cd ${FULL_TEST_DIR}
_cmd sudo chmod +x ./InstallRelgenRelease/InstallRelgenRelease.pl

# Update rel to point to tuxedo 22
if [ "$FROM_MINOR_VERSION" -le "04" ] && [ "$TO_MINOR_VERSION" -ge "05" ]; then
    _log "Updating tuxedo rel link on svrollupg1"
    _cmd sudo rm -rf /svw/svw_app/tuxedo/rel
    _cmd sudo ln -s /sv/app/tuxedo/product/22c/tuxedo22.1.0.0.0/ /svw/svw_app/tuxedo/rel
    _cmd tmadmin -v
    _log "Updating tuxedo rel link on svrollupg2"
    _cmd ssh svrollupg2 <<EOF
        echo \$ATA_INSTANCE
        sudo rm -rf /svw/svw_app/tuxedo/rel
        sudo ln -s /sv/app/tuxedo/product/22c/tuxedo22.1.0.0.0/ /svw/svw_app/tuxedo/rel
        tmadmin -v 
EOF
    _log "Updating tuxedo rel link on svrollupg3"
    _cmd ssh svrollupg3 <<EOF
        echo \$ATA_INSTANCE
        sudo rm -rf /svw/svw_app/tuxedo/rel
        sudo ln -s /sv/app/tuxedo/product/22c/tuxedo22.1.0.0.0/ /svw/svw_app/tuxedo/rel
        tmadmin -v 
EOF
fi

_cmd make minor_release

RC=$?
TESTDB_RC=1   # Make completed

if [ $RC -ne 0 ]; then
    echo "***  Upgrading HA environment - Failed."
    TESTDB_RC=2
    exit ${RC}
fi

_log "Tuxedo version after running minor upgrade"
_cmd tmadmin -v 

_log "TESTDB_RC: $TESTDB_RC"
_log "SV version after upgrade on svrollupg1"
echo ${ATA_INSTANCE}
_cmd sv_version

_log "SV version after upgrade on svrollupg2"
_cmd ssh svrollupg2 <<EOF
    echo \$ATA_INSTANCE
    sv_version
    tmadmin -v
EOF

_log "SV version after upgrade on svrollupg3"
_cmd ssh svrollupg3 <<EOF
    echo \$ATA_INSTANCE
    sv_version
    tmadmin -v
EOF

_cmd sv_ha_ctl cluster_status

exit 0;

