#!/bin/bash
#---------------------------------------------------------------------
# File:    cluster_setup.sh
# Created: 04-08-2023
# Creator: nasmd001 (Md Naseem)
#=====================================================================
# COPYRIGHT (c) 2017 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS
# AFFILIATES ( CSG ). ALL RIGHTS RESERVED.
#
# THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY
# TO CSG AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED
# EXCEPT IN ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG.
# THIS INFORMATION IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY
# UNAUTHORIZED USE THEREOF MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER
# LAWS. ANY UNAUTHORIZED USE OF THIS SOFTWARE AND/OR INFORMATION WILL
# AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS SOFTWARE AND/OR
# INFORMATION.
#=====================================================================
# USAGE:
#       ./cluster_setup.sh
#
# DESCRIPTION:
#       This script should be executed from SV1.
#---------------------------------------------------------------------

sudo chmod 777 /shared && \
sudo cp /svw/svwdev/fence_docker_ct /shared && \
sudo chmod 755 /shared/fence_docker_ct && \
sudo cp /svw/svwdev/fence_docker_ct /usr/sbin && \
sudo chmod 755 /usr/sbin/fence_docker_ct && \
ssh svrollupg2 sudo cp /shared/fence_docker_ct /usr/sbin && \
sudo chmod 755 /usr/sbin/fence_docker_ct && \
ssh svrollupg3 sudo cp /shared/fence_docker_ct /usr/sbin && \
sudo chmod 755 /usr/sbin/fence_docker_ct

/svw/svwdev/cluster_reconfig.sh
RC=${?}
if [[ ${RC} != 0 ]];then
    echo "Execution of cluster reconfig failed"
    exit ${RC}
fi
sudo usermod -a -G haclient svwdev

echo " Setting up cluster resource and alerts "
sudo mkdir -p /usr/lib/ocf/resource.d/csg
sudo cp $ATA_HOME/rel/server/config/ocf_sv /usr/lib/ocf/resource.d/csg/sv
sudo chmod 755 /usr/lib/ocf/resource.d/csg/sv
sudo chown -R  root:root /usr/lib/ocf/resource.d/csg/sv

sudo cp $ATA_HOME/rel/server/bin/sv_alert /tmp/
sudo cp $ATA_HOME/rel/server/bin/sv_cluster_mon /tmp/
sudo cp $ATA_HOME/rel/server/bin/install_alert /tmp/

sudo chmod 755 /tmp/install_alert
sudo /tmp/install_alert

# uncomment sleep infinity if setting dev env
#echo " calling sleep infinity "
#sleep infinity
