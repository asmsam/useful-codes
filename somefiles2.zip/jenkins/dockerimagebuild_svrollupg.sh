#!/bin/bash

REMOTE_REGISTRY=785148479268.dkr.ecr.ap-southeast-2.amazonaws.com

STARTD=`perl -e "print time;"`

# Copy files to home dir
cp cluster_setup.sh cluster_reconfig.sh fence_docker_ct /svw/svwdev/
echo "Replacing relgenenv on svrollupg1....."
cp $HOME/svtest-upgradeproc/tests/relgenenv $ATA_HOME/relgenenv
mkdir -p $HOME/svtest-upgradeproc/tests/test_results

export LD_LIBRARY_PATH=/lib64:$LD_LIBRARY_PATH
svn co -q svn://brirepo/sv_test/trunk /svw/svwdev/sv_test


scp -r /svw/svwdev/sv_test svwdev@svrollupg2:/svw/svwdev/
scp -r /svw/svwdev/sv_test svwdev@svrollupg3:/svw/svwdev/
echo "Replacing relgenenv on svrollupg2....."
scp -r /svw/svwdev/relgenenv svwdev@svrollupg2:/svw/svwdev/
echo "Replacing relgenenv on svrollupg3....."
scp -r /svw/svwdev/relgenenv svwdev@svrollupg3:/svw/svwdev/

# Adding call of install_perestapi.sh for temporary purpose until 
# the mms container contains the perest api code pack from ADO.
# Once perest code pack officially migrated to ADO and part of mms container 
# call of install_perestapi.sh script should be removed.
chmod 755 ./../config/install_perestapi.sh && ./../config/install_perestapi.sh

cd /svw/svwdev/
chmod 755 cluster_setup.sh cluster_reconfig.sh
./cluster_setup.sh

RC=${?}
if [[ ${RC} != 0 ]];then
    echo "Execution of cluster setup failed"
    exit ${RC}
fi

ls $ATA_HOME/sv_test
echo "Running svrollupg_createenv."
unset ATA_INSTANCE; export CBSVNROOT=svn://brirepo/cb; export PESVNROOT=svn://brirepo/pe; export STSVNROOT=svn://brirepo/sv_test; cd $ATA_HOME/sv_test/Library/Utils; sv_start; perl svrollupg_createenv.pl -cluster=HAActiveActive_docker_svroll_upg_ct -sv_test_loc=/svw/svwdev/sv_test
RC=${?}
if [[ ${RC} != 0 ]];then
    echo "Execution of cluster config failed"
    exit ${RC}
else
    echo "Finished running svrollupg_createenv."
fi

echo "Singleview cluster status....."
export ATA_INSTANCE=SV1;sv_status -cluster

# If we are in ECS we may have multiple clusters on an ec2 instance so we
# use a different mechanism to get the container names
if [ -z ${ECS_CONTAINER_METADATA_URI} ];then
    svrollupg1Container=$(sudo docker ps --format {{.ID}} --filter name=svrollupg1)
    dbhostContainer=$(sudo docker ps --format {{.ID}} --filter name=dbhost)
else
    svrollupg1Container=$(curl ${ECS_CONTAINER_METADATA_URI}/task|jq -r '.Containers[] | select(.Name == "svrollupg1").DockerId')
    dbhostContainer=$(curl ${ECS_CONTAINER_METADATA_URI}/task|jq -r '.Containers[] | select(.Name == "dbhost").DockerId')
fi
if [[ -z ${svrollupg1Container} || -z ${dbhostContainer} ]];then
    echo "Failed to find the svrollupg1 or dbhost containers"
    exit 1
fi
echo ${svrollupg1Container}
echo ${dbhostContainer}

# If build successful, save images to be used for testing
echo ""
echo "Generating Rolling upgrade multi-instance images with pcs cluster setup"

# Use part of the container name for the local image to keep it unique
APPLOCALIMAGE=$(echo ${svrollupg1Container} | cut -b 1-12)
DBLOCALIMAGE=$(echo ${dbhostContainer} | cut -b 1-12)                                                                                                    
sudo docker commit --change "ENV ECS_CONTAINER_PREFIX ''" --change "ENV ECS_CONTAINER_METADATA_URI ''" ${svrollupg1Container} ${APPLOCALIMAGE}
RC=$?
if [ $RC -ne 0 ];then
    echo "docker commit of the app container: ${svrollupg1Container} failed"
    exit $RC
fi
sudo docker commit --change "ENV ECS_CONTAINER_METADATA_URI ''" ${dbhostContainer} ${DBLOCALIMAGE}
RC=$?
if [ $RC -ne 0 ];then
    echo "docker commit failed for db image: container ${dbhostContainer}"
    exit $RC
fi
# Source our labels from the rolling upgrade base app image that we just committed
# This eval sets local env vars according to the labels in the docker image
# SV_MAJOR_VERSION etc
set -a
eval "$(sudo docker inspect -f '{{json .Config.Labels }}' ${APPLOCALIMAGE} | \
       jq -r 'to_entries[] | "\(.key)=\(.value)"' | grep -E 'CSG_SVVERSION')"
# Login into ECR
aws ecr get-login-password --region ap-southeast-2 | sudo docker login --username AWS --password-stdin ${REMOTE_REGISTRY}

BRANCHDASHES=$(echo ${SVUPGITBRANCH} | sed 's|/|-|g')
APPIMAGETAG=svrollupg-app-${BRANCHDASHES}-${CSG_SVVERSION}
APPPUSHIMAGETAG=latest-svrollupgapp-${BRANCHDASHES}-${CSG_SVVERSION}
DBIMAGETAG=svrollupg-db-${BRANCHDASHES}-${CSG_SVVERSION}
DBPUSHIMAGETAG=latest-svrollupgdb-${BRANCHDASHES}-${CSG_SVVERSION}
# Perform tagging
sudo docker tag ${APPLOCALIMAGE} ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:latest-${APPIMAGETAG}
sudo docker tag ${APPLOCALIMAGE} ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${PRIMARY_BUILD_ID}-${APPIMAGETAG}
sudo docker tag ${APPLOCALIMAGE} ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${APPPUSHIMAGETAG}

sudo docker tag ${DBLOCALIMAGE} ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:latest-${DBIMAGETAG}
sudo docker tag ${DBLOCALIMAGE} ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${PRIMARY_BUILD_ID}-${DBIMAGETAG}
sudo docker tag ${DBLOCALIMAGE} ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${DBPUSHIMAGETAG}

# Push latest images
sudo docker push ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:latest-${APPIMAGETAG}
sudo docker push ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:latest-${DBIMAGETAG}
sudo docker push ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${PRIMARY_BUILD_ID}-${APPIMAGETAG}
sudo docker push ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${PRIMARY_BUILD_ID}-${DBIMAGETAG}
sudo docker push ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${APPPUSHIMAGETAG}
sudo docker push ${REMOTE_REGISTRY}/csg/ct/sv_upgrade:${DBPUSHIMAGETAG}
RC=${?}
if [[ ${RC} != 0 ]];then
    echo "Docker push failed"
    exit ${RC}
fi

exit  ${RC}
