#!/bin/bash
#---------------------------------------------------------------------
# File:    cluster_reconfig.sh
# Created: 17-07-2023
# Creator: nasmd001
#=====================================================================
# COPYRIGHT (c) 2020 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS
# AFFILIATES ( CSG ). ALL RIGHTS RESERVED.
#
# THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY
# TO CSG AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED
# EXCEPT IN ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG.
# THIS INFORMATION IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY
# UNAUTHORIZED USE THEREOF MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER
# LAWS. ANY UNAUTHORIZED USE OF THIS SOFTWARE AND/OR INFORMATION WILL
# AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS SOFTWARE AND/OR
# INFORMATION.
#=====================================================================
# USAGE:
#       ./cluster_reconfig.sh
#
# DESCRIPTION:
#       Used to reconfigure the cluster in a docker CT environment
#       when initialising a new cluster to run tests base on existing
#       images.  Primarily recreates the fencing config due to new
#       container names.
#       Cluster setup and authorisation is based on pcs 0.10.x
#---------------------------------------------------------------------

echo "### Re-configuring cluster ..."

# If we are in ECS we may have multiple clusters on an ec2 instance so we
# use a different mechanism to get the container names
if [ -z ${ECS_CONTAINER_METADATA_URI} ];then
    CNT2=$(sudo docker ps --format {{.ID}} --filter name=svrollupg2)
    CNT3=$(sudo docker ps --format {{.ID}} --filter name=svrollupg3)
else
    CNT2=$(curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Containers[] | select(.Name == "svrollupg2").DockerId')
    CNT3=$(curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Containers[] | select(.Name == "svrollupg3").DockerId')
fi
echo Container ID for svrollupg2 is ${CNT2}
echo Container ID for svrollupg3 is ${CNT3}
if [[ -z $CNT2 || -z $CNT3 ]];then
    echo "Failed to set container name vars: svrollupg2=$CNT2, svrollupg3=$CNT3"
    exit 1
fi

# Authorise each host to self and every other host
sudo /usr/sbin/pcs host auth svrollupg1 svrollupg2 svrollupg3 -u hacluster -p hacluster
sudo docker exec $CNT2 sudo /usr/sbin/pcs host auth svrollupg1 svrollupg2 svrollupg3 -u hacluster -p hacluster
sudo docker exec $CNT3 sudo /usr/sbin/pcs host auth svrollupg1 svrollupg2 svrollupg3 -u hacluster -p hacluster

# Set up the cluster
sudo /usr/sbin/pcs cluster setup sv svrollupg1 svrollupg2 svrollupg3 transport knet --force
sleep 20

# Restart pcsd and pcsd-ruby on all hosts
sudo systemctl restart pcsd pcsd-ruby
sudo docker exec $CNT2 sudo systemctl restart pcsd pcsd-ruby
sudo docker exec $CNT3 sudo systemctl restart pcsd pcsd-ruby

# Authorise pcs locally
sudo pcs client local-auth -u hacluster -p hacluster
sudo docker exec $CNT2 sudo pcs client local-auth -u hacluster -p hacluster
sudo docker exec $CNT3 sudo pcs client local-auth -u hacluster -p hacluster

parallel --retries 10 --delay 5 ::: 'sudo pcs status pcsd|grep "svrollupg1: Online"' && \
parallel --retries 10 --delay 5 ::: 'sudo pcs status pcsd|grep "svrollupg2: Online"' && \
parallel --retries 10 --delay 5 ::: 'sudo pcs status pcsd|grep "svrollupg3: Online"' && \
sudo pcs cluster start --all && \
parallel --retries 10 --delay 10 ::: 'sudo pcs status | grep "Online"|grep "svrollupg1 svrollupg2 svrollupg3"' && \
sudo pcs stonith create sv_fencer fence_docker_ct pcmk_host_map="svrollupg2:${CNT2};svrollupg3:${CNT3}" pcmk_host_check=none --force
echo "### Cluster re-configuration complete."

