package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"net/url"
	"os"
	"regexp"

	log "github.com/Sirupsen/logrus"
	"github.com/docker/engine-api/types/container"
	"github.com/docker/go-plugins-helpers/authorization"
	"strings"
)

var exemptUsers []string
var exemptCaps []string

func loadExemptUsers() {

	// Get the list of users for who these checks will be bypassed
	log.Info("Loading list of exempt users")
	file, err := os.Open("/etc/docker/auth/ctauth-user-whitelist")
	if err != nil {
		log.Info("Unable to read file - no users will be exempted from privilege escalation prevention checks")
	} else {
		defer file.Close()

		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			userToAdd := scanner.Text()
			log.Info("Adding user " + userToAdd + " to list of exempt users.")
			exemptUsers = append(exemptUsers, userToAdd)
		}
	}
}

func loadExemptCaps() {

	// Get the list of Linux capabilities that will be allowed
	log.Info("Loading list of exempt capabilities")
	file, err := os.Open("/etc/docker/auth/ctauth-caps-whitelist")
	if err != nil {
		log.Info("Unable to read file - no additional Linux capabilities will be allowed.")
	} else {
		defer file.Close()

		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			capToAdd := scanner.Text()
			log.Info("Adding capability " + capToAdd + " to list of exempt capabilities.")
			exemptCaps = append(exemptCaps, capToAdd)
		}
	}
}

func isCapExempt(cap string) bool {
	for _, elem := range exemptCaps {
		if elem == cap {
			return true
		}
	}
	return false
}


func isUserExempt(username string) bool {
	for _, elem := range exemptUsers {
		if elem == username {
			return true
		}
	}
	return false
}

func newPlugin() (*ctauth, error) {
	loadExemptUsers()
	loadExemptCaps()
	return &ctauth{}, nil
}

type ctauth struct {
}

type configWrapper struct {
	*container.Config
	HostConfig *container.HostConfig
}

// --- implement authorization.Plugin

func (p *ctauth) AuthZReq(req authorization.Request) authorization.Response {

	uri, err := url.QueryUnescape(req.RequestURI)
	if err != nil {
		return authorization.Response{Err: err.Error()}
	}

	// Remove query parameters
	i := strings.Index(uri, "?")
	if i > 0 {
		uri = uri[:i]
	}

	// Check for any disallowed options for container creation
	createContainerRegEx := *regexp.MustCompile(`/v.*/containers/create`)
	if req.RequestMethod == "POST" && createContainerRegEx.MatchString(uri) {
		if req.RequestBody != nil {
			message := ""
			body := &configWrapper{}
			if err := json.NewDecoder(bytes.NewReader(req.RequestBody)).Decode(body); err != nil {
				return authorization.Response{Err: err.Error()}
			}

			// No privileged containers
			if body.HostConfig.Privileged {
				message = "The use of privileged containers is not allowed"
			}

			// User namespace can not be overridden
			if body.HostConfig.UsernsMode != "" {
				message = "User namespace may not be overridden"
			}

			// No new Linux capabilities may be added to the container
			if body.HostConfig.CapAdd != nil {
			        for _, elem := range body.HostConfig.CapAdd {
                			if ! isCapExempt(elem) {
                        			message = "The given Linux capabilities may not be added."
						break;
					}
				}
			}	

			if message != "" {
				if isUserExempt(req.User) {
					log.Info("User " + req.User + " exempted from privilege escalation prevention.")
				} else {
					log.Warn("Authorisation failed for user " + req.User + ": " + message)
					return authorization.Response{Msg: message}
				}
			}
		}
	}

	return authorization.Response{Allow: true}
}

func (p *ctauth) AuthZRes(req authorization.Request) authorization.Response {
	return authorization.Response{Allow: true}
}
