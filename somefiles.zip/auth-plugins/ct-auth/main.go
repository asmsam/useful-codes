package main

import (
	"flag"
	log "github.com/Sirupsen/logrus"
	"github.com/docker/go-plugins-helpers/authorization"
)

func main() {
	formatter := &log.TextFormatter{
		FullTimestamp: true,
	}
	log.SetFormatter(formatter)

	log.Info("Singleview privilege escalation prevention plugin started.")

	flag.Parse()

	ctauth, err := newPlugin()
	if err != nil {
		log.Fatal(err)
	}

	h := authorization.NewHandler(ctauth)

	if err := h.ServeUnix("ctauth", 0); err != nil {
		log.Fatal(err)
	}
}
