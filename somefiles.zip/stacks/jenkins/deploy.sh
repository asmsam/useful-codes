#!/bin/sh

# To deploy to brilxct18 swarm:
# DOCKER_HOST=tcp://brilxct18:2376 DOCKER_CERT_PATH=~/jenkins_cert/ docker --tls stack deploy -c docker-compose.yml jenkins

docker stack deploy -c docker-compose.yml jenkins
