#!/bin/bash
#*********************************************************************
#        File: dockerimagebuild.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2019 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#       ./dockerbuildimage.sh
#
#
# DESCRIPTION:
#       Used to build the base os, db and cthost docker images and push to ECR.
#       Relies on BUILDDIR, DOCKERFILE and IMAGEREPOTAG to be set to control which
#       image to build and push.  DOCKERFILE must exist in BUILDDIR
#       IMAGEREPOTAG can be a comma-delimited list of tags to use (including the
#       ECR repository) eg. csg/sv/cthost:latest-abc,csg/sv/cthost:20200728-abc
#
#-------------------------------------------------------------------------------*/
ECR_REGISTRY=785148479268.dkr.ecr.ap-southeast-2.amazonaws.com
S3_DOCKER_CERTIFICATE_LOCATION=s3://csgibri-svrndct-tools-and-software/dock_cert/

#
# Parameters
#
[ -n "${1}" ] && REPO_BRANCH="${1}"
[ -n "${2}" ] && REPO="${2}"
[ -n "${3}" ] && PACKAGE="${3}"

# The PACKAGE parameter is mandatory and must be valid.
# Assume meta-package name is dash separated string of 4 substrings
# e.g. third-party-devel-sv
# Only the first three are significant.
packageBundle=$(echo "${PACKAGE}" | awk -F- '{print $1$2$3}')
if [ "${packageBundle}" != "thirdpartydevel" ] && [ "${packageBundle}" != "thirdpartyruntime" ]
then
    >&2 echo "Package '$PACKAGE' not supported in build."
    exit 2
fi

#
# Build environment variable checks.
#
if [[ -z ${BUILDDIR} ]];then
    echo "BUILDDIR not set"
    exit 2
fi
if [[ -z ${DOCKERFILE} ]];then
    echo "DOCKERFILE not set"
    exit 2
fi
if [[ ! -d ${BUILDDIR} ]];then
    echo "Directory ${BUILDDIR} does not exist"
    exit 2
fi
if [[ ! -f ${BUILDDIR}/${DOCKERFILE} ]];then
    echo "${DOCKERFILE} does not exist in directory ${BUILDDIR}"
    exit 2
fi

#
# If USE_BRILXVM73 env var is set (to anything), we setup the certificates
# and env vars required to use the Brisbane on-prem brilxvm73 server as the
# docker host for the build.
# This is required for the rhel OS layer image builds
#
# NOTE: Unused at the moment. Packages are currently built only in Oracle Linux.
#
if [ -n "${USE_BRILXVM73}" ];then
    echo "Using brilxvm73 as docker host"
    mkdir -p /tmp/dock_cert
    aws s3 sync ${S3_DOCKER_CERTIFICATE_LOCATION} /tmp/dock_cert/
    export DOCKER_CERT_PATH=/tmp/dock_cert
    export DOCKER_TLS_VERIFY=1
    export DOCKER_HOST=tcp://brilxvm73:2376
fi

#
# Builds the image.
#
# Assumes various ARGs are available in the Dockerfile.
#
buildImage() {
    builddir="${1}"
    dockerfile="${2}"
    imageName="${3}"
    branch="${4}"
    repo="${5}"
    package="${6}"

    # accumulate the docker build arguments
    build_args=
    # see dockerfile for default arg values
    if [ -n "${branch}" ] && [ "${branch}" != "master" ]; then
        build_args="${build_args} --build-arg REPO_BRANCH=${branch}"
    fi
    if [ -n "${repo}" ]; then
        build_args="${build_args} --build-arg REPO=${repo}"
    fi
    if [ -n "${package}" ]; then
        build_args="${build_args} --build-arg PACKAGE=${package}"
    fi

    cd "${builddir}" || exit 1
    if ! docker build \
        --pull \
        --no-cache \
        ${build_args} \
        -t "${imageName}" \
        -f "${dockerfile}" \
        .
    then
        exit 1
    fi
}

#
# Tag the image and push it to the container registry.
#
pushTaggedImage() {
    imageName="${1}"
    pushTag="${2}"
    echo "Tagging ${imageName} as ${pushTag}"
    if ! docker tag "${imageName}" "${pushTag}"; then
        exit 1
    fi
    echo "Pushing tag ${pushTag}"
    if ! docker push "${pushTag}"; then
        exit 1
    fi
}

IMAGE_NAME="baseimages$$-${PRIMARY_BUILD_ID}-$(cat /proc/sys/kernel/random/uuid)"

aws ecr get-login-password --region ap-southeast-2 \
    | docker login --username AWS --password-stdin "${ECR_REGISTRY}"

if ! buildImage \
    "${BUILDDIR}" \
    "${DOCKERFILE}" \
    "${IMAGE_NAME}" \
    "${REPO_BRANCH}" \
    "${REPO}" \
    "${PACKAGE}"
then
    echo "Failed to build image using ${BUILDDIR}/${DOCKERFILE}"
    exit 1
fi

# Tagging checks various details to determine what is "latest":
#  * this (docker baseimages) repository's branch
#  * the svapp repository's branch
#  * the package repository name
#  * the svapp meta-package installed
#  * OS version (and implicitly Singleview version)
#
# The meta-package names are assumed to be fixed values.
#
# "latest" should be what downstream "production" images use.
# According to the criteria above, the "latest" tags are:
#   latest, and its alias latest-runtime:
#     * master
#     * master
#     * stable
#     * third-party-runtime
#     * OL7.6
#   latest-devel:
#     * master
#     * master
#     * stable
#     * third-party-devel
#     * OL7.6
#
# The presence of images with these tags is intended to be assumed to exist by
# downstream containers.
# The runtime and devel parts of the tag are derived from the name of the
# package installed
#
# Image variants are intended to only be identifiable by the build number. That
# is, variants are created as desired by a Jenkins job calling this one and it
# is expected that the parent job can determine what image this job created by
# its build number.
#
# Any other distinguishing information in the tag should be considered to exist
# for meatspace discoverability in the container registry and not for build
# automation to assume.
#
dockerInspect() {
    docker inspect $IMAGE_NAME | jq -r ".[].Config.Labels.$1"
}
dbTag="$(dockerInspect DBSUPPLIER)$(dockerInspect DBVERSION)$(dockerInspect DBCLASS)"
osTag="$(dockerInspect OSRELEASE)$(dockerInspect OSVERSION)"
ecrTag="${ECR_REGISTRY}/csg/sv/cthost"
tagPostfix="-$dbTag-$osTag-${REPO}-${PACKAGE}"

# The list of tags to apply against the image
taglist=

# Add the "latest" tags for the image to the tag list if appropriate for the build
if [ "${BASEIMAGESBRANCH}" = "master" ] && [ "${REPO_BRANCH}" = "master" ] && [ "$(echo "${REPO}" | awk -F_ '{print $1}')" != "testing" ]
then
    latestTag="${ecrTag}:latest"
    taglist="${taglist} ${latestTag}${tagPostfix}"

    latestTag="${latestTag}-$(echo "${PACKAGE}" | awk -F- '{print $4}')"
    taglist="${taglist} ${latestTag}${tagPostfix}"
fi

# Add the build tag for the image to the tag list
taglist="${taglist} ${ecrTag}:${PRIMARY_BUILD_ID}${tagPostfix}"

# Send image to container registry tagged with each tag in the tag list
for tag in ${taglist}; do
    if ! pushTaggedImage "${IMAGE_NAME}" "$tag"; then
        echo "Failed to tag or push image ${IMAGE_NAME} using ${pushTag}"
        exit 1
    fi
done

exit 0
