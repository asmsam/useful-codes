#!/bin/bash
#*********************************************************************
#        File: dockerimagebuild.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2019 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#       ./dockerbuildimage.sh
#
#
# DESCRIPTION:
#       Used to build the base os, db and cthost docker images and push to ECR.
#       Relies on BUILDDIR, DOCKERFILE and IMAGEREPOTAG to be set to control which
#       image to build and push.  DOCKERFILE must exist in BUILDDIR
#       IMAGEREPOTAG can be a comma-delimited list of tags to use (including the
#       ECR repository) eg. csg/sv/cthost:latest-abc,csg/sv/cthost:20200728-abc
#
#-------------------------------------------------------------------------------*/

if [[ -z ${PRIMARY_BUILD_ID} ]];then
    echo "PRIMARY_BUILD_ID not set"
    exit 2
fi
if [[ -z ${BUILDDIR} ]];then
    echo "BUILDDIR not set"
    exit 2
fi
if [[ -z ${DOCKERFILE} ]];then
    echo "DOCKERFILE not set"
    exit 2
fi
if [[ -z ${IMAGEREPOTAG} ]];then
    echo "IMAGEREPOTAG not set"
    exit 2
fi
if [[ ! -d ${BUILDDIR} ]];then
    echo "Directory ${BUILDDIR} does not exist"
    exit 2
fi
if [[ ! -f ${BUILDDIR}/${DOCKERFILE} ]];then
    echo "${DOCKERFILE} does not exist in directory ${BUILDDIR}"
    exit 2
fi

# Handle ability to generate two images in the same run
if [[ ! -z ${SECOND_IMAGEREPOTAG} ]]; then
    if [[ -z ${SECOND_TARGET} && -z ${SECOND_DOCKERFILE} ]]; then
        echo "SECOND_TARGET or SECOND_DOCKERFILE not set but SECOND_IMAGEREPOTAG is set"
        exit 2
    fi

    if [[ ! -z ${SECOND_DOCKERFILE} && ! -f ${BUILDDIR}/${SECOND_DOCKERFILE} ]]; then
        echo "${SECOND_DOCKERFILE} does not exist in directory ${BUILDDIR}"
        exit 2
    fi
fi

ECR_REGISTRY=785148479268.dkr.ecr.ap-southeast-2.amazonaws.com
S3_DOCKER_CERTIFICATE_LOCATION=s3://csgibri-svrndct-tools-and-software/dock_cert/

# If USE_BRILXVM73 env var is set (to anything), we setup the certificates
# and env vars required to use the Brisbane on-prem brilxvm73 server as the
# docker host for the build.
# This is required for the rhel OS layer image builds
if [[ ! -z ${USE_BRILXVM73} ]];then
    echo "Using brilxvm73 as docker host"
    mkdir -p /tmp/dock_cert
    aws s3 sync ${S3_DOCKER_CERTIFICATE_LOCATION} /tmp/dock_cert/
    export DOCKER_CERT_PATH=/tmp/dock_cert
    export DOCKER_TLS_VERIFY=1
    export DOCKER_HOST=tcp://brilxvm73:2376
fi

#############################
## Build main image
#############################
aws ecr get-login-password --region ap-southeast-2 | docker login --username AWS --password-stdin ${ECR_REGISTRY} && \
cd ${BUILDDIR} && \
docker build --pull --no-cache . -f ${DOCKERFILE} -t baseimages$$-${PRIMARY_BUILD_ID}

RC=$?
if [[ ${RC} != 0 ]];then
    echo "Failed to build image using ${BUILDDIR}/${DOCKERFILE}"
    exit 1
fi

#############################
## Build second image (if reqd)
#############################
if [[ ! -z ${SECOND_IMAGEREPOTAG} ]]; then
    dockerOpts=''
    [ ! -z ${SECOND_DOCKERFILE} ] && dockerOpts='--pull --no-cache'
    SECOND_DOCKERFILE=${SECOND_DOCKERFILE:-$DOCKERFILE}
    [ ! -z ${SECOND_TARGET} ]     && dockerOpts="${dockerOpts} --target ${SECOND_TARGET}"

    docker build ${dockerOpts} . -f ${DOCKERFILE} -t baseimages-2nd$$-${PRIMARY_BUILD_ID}
    RC=$?
    if [[ ${RC} != 0 ]];then
        echo "Failed to build image using ${BUILDDIR}/${SECOND_DOCKERFILE} using ${dockerOpts}"
        exit 1
    fi
fi

#############################
## Tag and push main Image
#############################
# IMAGEREPOTAG can be a list of repo+tag strings, comma-separated
modImageRepoTag=$(echo ${IMAGEREPOTAG} | sed "s/###PRIMARY_BUILD_ID###/${PRIMARY_BUILD_ID}/g")
IFS=',' read -r -a TAGS <<< "${modImageRepoTag}"
for tag in "${TAGS[@]}"
do
    docker tag baseimages$$-${PRIMARY_BUILD_ID} ${ECR_REGISTRY}/${tag} && \
    docker push ${ECR_REGISTRY}/${tag}
    RC=$?
    if [[ ${RC} != 0 ]];then
        echo "Failed to tag or push image using ${tag}"
        exit 1
    fi
done
##############################
## Tag and push second image (if reqd)
#############################
# SECOND_IMAGEREPOTAG can be a list of repo+tag strings, comma-separated
if [[ ! -z ${SECOND_IMAGEREPOTAG} ]]; then
    modImageRepoTag=$(echo ${SECOND_IMAGEREPOTAG} | sed "s/###PRIMARY_BUILD_ID###/${PRIMARY_BUILD_ID}/g")
    IFS=',' read -r -a TAGS <<< "${modImageRepoTag}"
    for tag in "${TAGS[@]}"
    do
        docker tag baseimages-2nd$$-${PRIMARY_BUILD_ID} ${ECR_REGISTRY}/${tag} && \
        docker push ${ECR_REGISTRY}/${tag}
        RC=$?
        if [[ ${RC} != 0 ]];then
            echo "Failed to tag or push image using ${tag}"
            exit 1
        fi
    done
fi
