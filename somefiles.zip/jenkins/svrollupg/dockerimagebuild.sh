#!/bin/bash
#*********************************************************************
#        File: dockerimagebuild.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2019 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#       ./dockerbuildimage.sh
#
#
# DESCRIPTION:
#       Used to build the base svrollupg docker images and push to ECR.
#       Relies on BUILDDIR, DOCKERFILE and APPIMAGEREPOTAG to be set to control which
#       image to build and push.  DOCKERFILE must exist in BUILDDIR
#       APPIMAGEREPOTAG can be a comma-delimited list of tags to use (including the
#       ECR repository)
#
#-------------------------------------------------------------------------------*/
ECR_REGISTRY=785148479268.dkr.ecr.ap-southeast-2.amazonaws.com
S3_DOCKER_CERTIFICATE_LOCATION=s3://csgibri-svrndct-tools-and-software/dock_cert/

#
# Build environment variable checks.
#
if [[ -z ${PRIMARY_BUILD_ID} ]];then
    echo "PRIMARY_BUILD_ID not set"
    exit 2
fi
if [[ -z ${BUILDDIR} ]];then
    echo "BUILDDIR not set"
    exit 2
fi
if [[ -z ${DOCKERFILE} ]];then
    echo "DOCKERFILE not set"
    exit 2
fi
if [[ -z ${APPIMAGEREPOTAG} ]];then
    echo "APPIMAGEREPOTAG not set"
    exit 2
fi
if [[ -z ${DBIMAGEREPOTAG} ]];then
    echo "DBIMAGEREPOTAG not set"
    exit 2
fi
if [[ ! -d ${BUILDDIR} ]];then
    echo "Directory ${BUILDDIR} does not exist"
    exit 2
fi
if [[ ! -f ${BUILDDIR}/${DOCKERFILE} ]];then
    echo "${DOCKERFILE} does not exist in directory ${BUILDDIR}"
    exit 2
fi

#
# If USE_BRILXVM73 env var is set (to anything), we setup the certificates
# and env vars required to use the Brisbane on-prem brilxvm73 server as the
# docker host for the build.
# This is required for the rhel OS layer image builds
#
# NOTE: Unused at the moment. Packages are currently built only in Oracle Linux.
#
if [ -n "${USE_BRILXVM73}" ];then
    echo "Using brilxvm73 as docker host"
    mkdir -p /tmp/dock_cert
    aws s3 sync ${S3_DOCKER_CERTIFICATE_LOCATION} /tmp/dock_cert/
    export DOCKER_CERT_PATH=/tmp/dock_cert
    export DOCKER_TLS_VERIFY=1
    export DOCKER_HOST=tcp://brilxvm73:2376
fi

#############################
## Build main image
#############################
appimagetag="latest-svmms-app-main-${SV_VERSION}"
aws ecr get-login-password --region ap-southeast-2 | docker login --username AWS --password-stdin ${ECR_REGISTRY} && \
cd ${BUILDDIR} && \
docker build --pull --no-cache . -f ${DOCKERFILE} --build-arg MMS_APP_TAG=$appimagetag --build-arg SV_VERSION=$SV_VERSION -t baseimages$$-${PRIMARY_BUILD_ID}     
RC=$?
if [[ ${RC} != 0 ]];then
    echo "Failed to build image using ${BUILDDIR}/${DOCKERFILE}"
    exit 1
fi

#############################
## Tag and push app Image
#############################
modImageRepoTag="${APPIMAGEREPOTAG}-$SV_VERSION,$(echo ${APPIMAGEREPOTAG} | sed "s/latest/${PRIMARY_BUILD_ID}/g")-$SV_VERSION"

IFS=',' read -r -a TAGS <<< "${modImageRepoTag}"
for tag in "${TAGS[@]}"
do
    docker tag baseimages$$-${PRIMARY_BUILD_ID} ${ECR_REGISTRY}/${tag} && \
    docker push ${ECR_REGISTRY}/${tag}
    RC=$?
    if [[ ${RC} != 0 ]];then
        echo "Failed to tag or push image using ${tag}"
        exit 1
    fi
done

###############################
## Pull, Tag and push db Image
###############################
dbimagetag="csg/scde/sv:latest-svmms-db-main-${SV_VERSION}"

# Pull db image for specified SV_VERSION, Re-tag it and Push.
docker pull ${ECR_REGISTRY}/${dbimagetag}
modImageRepoTag="${DBIMAGEREPOTAG}-$SV_VERSION,$(echo ${DBIMAGEREPOTAG} | sed "s/latest/${PRIMARY_BUILD_ID}/g")-$SV_VERSION"

IFS=',' read -r -a TAGS <<< "${modImageRepoTag}"
for tag in "${TAGS[@]}"
do
    docker tag  ${ECR_REGISTRY}/${dbimagetag} ${ECR_REGISTRY}/${tag} && \
    docker push ${ECR_REGISTRY}/${tag}
    RC=$?
    if [[ ${RC} != 0 ]];then
        echo "Failed to tag or push image using ${tag}"
        exit 1
    fi
done

