#!/bin/env python3
#!groovy
#*********************************************************************
#        File: rerun_ecs_task.py
# ==================================================================================
#  COPYRIGHT (c) 1995-2019 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#
#     /efs/ct/bin/rerun_ecs_task.py <application> <branch> <test module/group>
#     eg. /efs/ct/bin/rerun_ecs_task.py cb branches/trunk-dtl cb_sok
#     see help (-h) for more details
#
# DESCRIPTION:
#
#     Reruns ECS (Elastic Container Service) test or build tasks that have 
#     previously been run in CT jobs
#
#-------------------------------------------------------------------------------*/

import json
import sys
import subprocess
import boto3
import argparse
import time
import codecs
import os
import uuid
from pprint import pprint
import signal
import sys
import datetime
from botocore.exceptions import ClientError

def signal_handler(signal, frame):
    ecsclient = boto3.client('ecs', region_name='ap-southeast-2')
    for taskArn in taskArns:
        kwargs = {
            'cluster': ecsCluster,
            'task': taskArn
        }
        print("Killing " + taskArn)
        ecsclient.stop_task(**kwargs)
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Creates file in the current directory with the logs from each container from the task
def getLogs(myTaskArn):
    kwargs = {
        'cluster': ecsCluster,
        'tasks': [myTaskArn]
    }
    ecsclient = boto3.client('ecs', region_name='ap-southeast-2')
    resp = ecsclient.describe_tasks(**kwargs)
    # We only passed one task so should only see one task in the result - hence the [0]
    for container in resp['tasks'][0]['containers']:
        # Log stream names follow a certain format eg ecs/cbtest/<taskId>
        logStream = 'ecs/'+container['name']+'/'+str(myTaskArn.split('/')[-1])

        # Create the file
        fileName = str(myTaskArn.split('/')[-1])+'.'+args.testgroup+'.'+container['name']+'.log'
        print('Creating file '+fileName+' for task '+myTaskArn)
        myFile = codecs.open(fileName,encoding='utf-8',mode='a')

        logsclient = boto3.client('logs', region_name='ap-southeast-2')
        kwargs = {
            'logGroupName': '/ecs/'+args.application+args.jobtype,
            'logStreamName': logStream
        }
        resp = logsclient.describe_log_streams(logGroupName='/ecs/'+args.application+args.jobtype,logStreamNamePrefix=logStream)
        if resp['logStreams']:
            # get_log_events is paginated, so we loop until no events
            while True:
                resp = logsclient.get_log_events(**kwargs)
                for line in resp['events']:
                    myFile.write(line['message'] + u"\n")
                try:
                    kwargs['nextToken'] = resp['nextToken']
                except KeyError:
                    break
            s3_client = boto3.client('s3')
            s3FileName = 'rerunlogs/' + logdir + '/' + fileName
            try:
                response = s3_client.upload_file(fileName, 'csgibri-svrndct-misc', s3FileName)
            except ClientError as e:
                print(e)
        else:
            print(logStream + ' not found')


# Gets the IP address of the EC2 instance being used as the container instance for the given task
# Must describe the task to get the container instance, then describe the container instance to
# get the ec2 instance ID and finally describe the ec2 instance to get the IP address
def getContainerInstanceIp(myTaskArn):
    kwargs = {
        'cluster': ecsCluster,
        'tasks': [myTaskArn]
    }
    ecsclient = boto3.client('ecs', region_name='ap-southeast-2')
    resp = ecsclient.describe_tasks(**kwargs)
    containerInstanceArn = resp['tasks'][0]['containerInstanceArn']
    kwargs = {
        'cluster': ecsCluster,
        'containerInstances': [containerInstanceArn]
    }
    resp = ecsclient.describe_container_instances(**kwargs)
    ec2InstanceId = resp['containerInstances'][0]['ec2InstanceId']
    ec2client = boto3.client('ec2', region_name='ap-southeast-2')
    resp = ec2client.describe_instances(InstanceIds=[ec2InstanceId])
    return resp['Reservations'][0]['Instances'][0]['PrivateIpAddress']

# Set up command line args
desc = "Reruns a CT build or test task. "+ \
       "By default it will use the most recent ECS task definition for the application/branch combination. "+ \
       "Optionally an s3 folder can be supplied as an argument to identify the location of a specific task_defn.json file. "+ \
       "If this is done the location of the task_overrides.json file will also be derived from that s3 location. "+ \
       "Logs generated by the task will be saved to the current directory."
parser = argparse.ArgumentParser(description=desc)
parser.add_argument("application", type=str, help="Test suite/application (eg. cb, hafn, dbhadg, st, pe, sprt")
parser.add_argument("branch", type=str, default="trunk", help="Branch")
parser.add_argument("testgroup", type=str, help="Test group (eg. cb_sok, HAATestMIRE) or for a build jobtype cbbuild, stbuild etc")
parser.add_argument("--taskdefnlocation", type=str, help="The full s3 path, excluding the filename, to use for the task_defn.json file. Defaults to s3://csgibri-svrndct-jenkins/<cluster>/<branch>/<app>_<jobtype>/latest")
parser.add_argument("--count", type=int, default=1, help="Count of tasks to run in parallel")
parser.add_argument("--leave_running", type=int, help="Leave the container(s) running for this many minutes when the task finishes")
parser.add_argument("--cluster", type=str, help="ECS cluster to use. If left blank, the script will work out the appropriate cluster")
parser.add_argument("--jobtype", type=str, choices=['build','test'], default="test", help="build or test, default is test")
parser.add_argument("--logdir", type=str, help="Artifacts will be placed in this folder in jenkins/rerunlogs in s3.  If left blank a unique ID will be used for the folder name. If a folder already exists at that location its contents will be replaced.")

parser.parse_args()
args = parser.parse_args()

print('Application: ' + args.application)
print('Branch: ' + args.branch)
print('Test group: ' + args.testgroup)

# Set cluster
# hafn/halc/dbhadg tests - all use the same 'ha' cluster
# Rather than have developers know this - we just set it here for them
# Probably could be an override
if args.cluster:
    ecsCluster = args.cluster
elif args.application[0:2] == 'ha':
    ecsCluster = 'ha'
else:
    ecsCluster = args.application

branchdashes = args.branch.replace('/','-')

if not args.taskdefnlocation:
    taskdefnlocation = 's3://csgibri-svrndct-jenkins/'+ecsCluster+'/'+branchdashes+'/'+args.application+'_'+args.jobtype+'/latest/'
else:
    taskdefnlocation = args.taskdefnlocation

taskDefinitionNames = []
taskDefinitionNamesMatchApp = []
taskDefinitionNamesMatchBranch = []

s3client = boto3.client('s3')

if(subprocess.call('aws s3 cp '+taskdefnlocation+'task_defn.json .',shell=True) != 0):
    print("Task definition (task_defn.json) not found at "+taskdefnlocation)
    exit(1)

taskoverlocation = taskdefnlocation+args.testgroup+'/task_overrides.json'
if(subprocess.call('aws s3 cp '+taskoverlocation+' .',shell=True) != 0):
    print("Task overrides file (task_overrides.json) not found at "+taskoverlocation)
    exit(1)

taskDefn = {}
with open('task_defn.json') as json_file:
    taskDefn = json.load(json_file)

# Find the image, and command for the task defn
for containerDefn in taskDefn['containerDefinitions']:
    print('Container ' + containerDefn['name'] + ' will use image ' + containerDefn['image'])
command = taskDefn['containerDefinitions'][0]['command']

newCommand = ''

taskDefn['family'] = taskDefn['family']+'-rerun'

if args.leave_running:
    sleepSeconds = args.leave_running * 60
    if len(command) == 1:
        # If we have a single-word command, replace it with a complex one including a sleep
        newCommand = ["sh","-c"] + [command[0] + "; sleep " + str(sleepSeconds)]
        print("replacing command with " + str(newCommand))
    else:
        # If we already have a complex command, just add a sleep to the final part of the command
        newCommand = command[:-1] + [command[-1] + "; sleep " + str(sleepSeconds)]
    taskDefn['containerDefinitions'][0]['command'] = newCommand
    taskDefn['family'] = taskDefn['family']+'-rerun'

with open('task_defn.json', 'w') as outfile:
    json.dump(taskDefn, outfile)

overrides = {}
with open('task_overrides.json') as json_file:
    overrides = json.load(json_file)

# Search through env vars in the overrides and replace JENKINS_BUILD_TAG and
# S3_LOG_LOCATION
s3LogLocation = 's3://csgibri-svrndct-jenkins/rerunlogs/'
for cnter, envVar in enumerate(overrides['containerOverrides'][0]['environment']):
    if envVar['name'] == 'JENKINS_BUILD_TAG':
        overrides['containerOverrides'][0]['environment'][cnter]['value'] = 'NONE'
    if envVar['name'] == 'S3_LOG_LOCATION':
        s3LogLocationIndex = cnter 

# Create task
if(subprocess.call('aws ecs register-task-definition --cli-input-json file://task_defn.json --region ap-southeast-2 >register.out',shell=True) != 0):
    print("Failed to create task definition")
    exit(1)

if not args.logdir:
    logdir = str(uuid.uuid1())
else:
    logdir = args.logdir

# Ignore errors 
if subprocess.call('aws s3 rm --recursive '+s3LogLocation+logdir+'/',shell=True) != 0:
    print("Error occurred during deletion of the s3 log location "+s3LogLocation+logdir+'/')
    exit(1)


# Run task(s)
client = boto3.client('ecs', region_name='ap-southeast-2')
taskArns = []
for i in range(1,args.count+1):

    overrides['containerOverrides'][0]['environment'][s3LogLocationIndex]['value'] = s3LogLocation+logdir+'/'+str(i)
    kwargs = {
        'taskDefinition': taskDefn['family'],
        'cluster': ecsCluster,
        'overrides': overrides
    }

    resp = client.run_task(**kwargs)
    if resp['failures']:
        print('Task failed to start:')
        pprint(resp['failures'])
        exit(1)
    else:
        taskArns.append(str(resp['tasks'][0]['taskArn']))
        print(str(resp['tasks'][0]['taskArn']) + ' successfully launched ('+str(i)+' of '+str(args.count)+')')

while taskArns:
    kwargs = {
        'cluster': ecsCluster,
        'tasks': taskArns
    }
    resp = client.describe_tasks(**kwargs)
    for task in resp['tasks']:
        if task['lastStatus'] == 'STOPPED':
            print(task['taskArn'] + ' has stopped')
            getLogs(task['taskArn'])
            taskArns.remove(task['taskArn'])
        else:
            if task['lastStatus'] == 'RUNNING':
                print(str(datetime.datetime.now())+' '+task['taskArn'] + ' has status ' + task['lastStatus'] + ' on ' + getContainerInstanceIp(task['taskArn']))
            else:
                print(str(datetime.datetime.now())+' '+task['taskArn'] + ' has status ' + task['lastStatus'])
    if taskArns:
        print(str(datetime.datetime.now())+' sleeping for 30 secs...')
        time.sleep(30)

print('Artifacts can be found at https://csgibri-svrndct-jenkins.s3-ap-southeast-2.amazonaws.com/index.html?prefix=rerunlogs/'+logdir)
print('or downloaded to the current directory with aws s3 sync '+s3LogLocation+logdir+' .')
print('Logs are copied into s3://csgibri-svrndct-misc/rerunlogs/' + logdir + '/ and can be downloaded with a similar aws s3 sync command for that location')
