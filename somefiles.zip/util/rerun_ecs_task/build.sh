#!/bin/bash
sudo docker login -u AWS -p $(aws ecr get-login-password --region ap-southeast-2) 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com
sudo docker  build . -t 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/ct/rerun_ecs_task:latest
sudo docker push 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/ct/rerun_ecs_task:latest
