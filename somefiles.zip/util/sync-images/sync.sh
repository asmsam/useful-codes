#!/bin/sh

SKOPEO="podman run --rm -e REGISTRY_AUTH_FILE=/auth.json -v $HOME/containers/auth.json:/auth.json quay.io/skopeo/stable:v1.4.1"
NEW_IMAGES=""

sync_images() {
    echo "###########################################################"
    echo "Syncing image ${1} where tags match ${3}"
    echo "###########################################################"
    echo "Finding all tags that match ${3}..."
    IMG_TAGS=$(${SKOPEO} list-tags docker://${1} | jq -r  '.Tags[] | select(.? | match("'${3}'"))')
    echo "Found:"
    echo ${IMG_TAGS}
    echo
    for IMG_TAG in ${IMG_TAGS}; do
        echo "Syncing ${IMG_TAG}"
        SYNC_OUTPUT=$(${SKOPEO} sync --src docker ${1}:${IMG_TAG} --dest docker ${2})
        if [ $? -ne 0 ]; then
            echo "Error while trying to sync ${1}:${IMG_TAG} to ${2}"
        exit 1
    fi

    echo ${SYNC_OUTPUT} | grep "Writing manifest to image destination"
    if [ $? -eq 0 ]; then
        echo "New image ${IMG_TAG}"
        NEW_IMAGES+="${1}:${IMG_TAG} "
    fi
    done
}

# Sync golang 1.21 images
GOLANG_TAGS="^1\\\.21(?:\\\.[0-9]+?)*$"
for SEARCH_TAG in ${GOLANG_TAGS}; do
    sync_images golang 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com ${SEARCH_TAG}
done

# Sync Red Hat ubi8 images
REDHAT_TAGS="^8.*(?<!-source)$ ^latest$"
for SEARCH_TAG in ${REDHAT_TAGS}; do
    sync_images registry.access.redhat.com/ubi8/ubi-micro 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi8 ${SEARCH_TAG}
    sync_images registry.access.redhat.com/ubi8/ubi-minimal 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi8 ${SEARCH_TAG}
    sync_images registry.access.redhat.com/ubi8/ubi-init 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi8 ${SEARCH_TAG}
    sync_images registry.access.redhat.com/ubi8/ubi 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi8 ${SEARCH_TAG}
done

# Sync Red Hat ubi9 images
REDHAT_TAGS="^9.*(?<!-source)$ ^latest$"
for SEARCH_TAG in ${REDHAT_TAGS}; do
    sync_images registry.access.redhat.com/ubi9/ubi-micro 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi9 ${SEARCH_TAG}
    sync_images registry.access.redhat.com/ubi9/ubi-minimal 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi9 ${SEARCH_TAG}
    sync_images registry.access.redhat.com/ubi9/ubi-init 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi9 ${SEARCH_TAG}
    sync_images registry.access.redhat.com/ubi9/ubi 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/redhat/ubi9 ${SEARCH_TAG}
done

# Sync Oracle Linux images
ORACLE_TAGS="^9.* ^8.* ^7\\\.9.* ^7$ ^7-slim$ ^7\\\.6.*"
for SEARCH_TAG in ${ORACLE_TAGS}; do
    sync_images oraclelinux 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com ${SEARCH_TAG}
done

# Sync Elasticsearch and Kibana images
ELASTIC_TAGS="^7.16.2$"
for SEARCH_TAG in ${ELASTIC_TAGS}; do
    sync_images docker.elastic.co/elasticsearch/elasticsearch 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com ${SEARCH_TAG}
    sync_images docker.elastic.co/kibana/kibana 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com ${SEARCH_TAG}
done

# Sync Azul Java images
AZUL_TAGS="^17-latest$ ^11-latest$"
for SEARCH_TAG in ${AZUL_TAGS}; do
    sync_images azul/zulu-openjdk 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/azul ${SEARCH_TAG}
done

# Sync Apache Tomcat images
TOMCAT_TAGS="^9.0$"
for SEARCH_TAG in ${TOMCAT_TAGS}; do
    sync_images tomcat 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com ${SEARCH_TAG}
done

if [ -z "${NEW_IMAGES}" ]; then
    echo "No new images found"
    exit 0
else
    echo
    echo "#############################################################"
    echo "NEW IMAGES FOUND"
    echo "================"
    echo ${NEW_IMAGES} | tr " " "\\n" | sort
    echo "#############################################################"
    exit 100
fi
