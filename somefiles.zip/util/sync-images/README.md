# Container image synchronisation

The `sync.sh` script in this directory is used to synchronise commonly used base images from 3rd party registries to the SV RnD ECR registry.
It uses a set of regular expressions to match the tags of images that be synchronised.
It uses `skopeo` to perform the synchronisation between the registries.

## Job execution
The synchronisation job is scheduled to run every Monday morning between 12am and 8am.
It does not automatically run when changes are made to the source repository.
If new images or tags are added to the script the job must be executed manually to synchronise the images, or the images will be synchronised the next the job runs.

The job is currently executed on the `brilxvm101` server by the [Image Sync Jenkins job](http://jenkins-svrnd-aws:8080/jenkins/job/Image_Sync).
Ideally this should run somewhere in AWS, preferably as a Lambda function that is scheduled to run weekly.

## Notification of new images

If new images are found and synchronised, a notification is sent via the [ecrNewImagesSynced](https://ap-southeast-2.console.aws.amazon.com/sns/v3/home?region=ap-southeast-2#/topic/arn:aws:sns:ap-southeast-2:785148479268:ecrNewImagesSynced) SNS topic.
To receive notifications when new images are synced and available for use, a subscription to the topic can be created via the AWS console.
