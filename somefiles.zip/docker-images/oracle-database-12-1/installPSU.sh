#!/bin/ksh

cd $ORACLE_BASE
curl http://svrelease/release/oracle/OPatch/p6880880_122010_Linux-x86-64.zip -o p6880880_122010_Linux-x86-64.zip
curl http://svrelease/release/oracle/PSU12.1.0.2.180417/p27338041_121020_Linux-x86-64.zip -o p27338041_121020_Linux-x86-64.zip

# Install OPatch
cd $ORACLE_HOME
unzip -o /opt/oracle/p6880880_122010_Linux-x86-64.zip

# Install PSU
cd $ORACLE_BASE
unzip p27338041_121020_Linux-x86-64.zip
cd 27338041/
PATH=$ORACLE_HOME/OPatch:$PATH opatch apply -silent

# Manually apply prvtash.plb from p27338041 due to a bug in the PSU. See Oracle bug 27938623
# https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=419047187690629&id=2392962.1&displayIndex=1&_afrWindowMode=0&_adf.ctrl-state=12rad8qvf8_85
cp -f $ORACLE_BASE/27338041/27338041/files/rdbms/admin/prvtash.plb $ORACLE_HOME/rdbms/admin/.
$ORACLE_HOME/bin/sqlplus / as sysdba <<EOF
@$ORACLE_HOME/rdbms/admin/prvtash.plb
quit;
EOF

rm -rf $ORACLE_BASE/27338041
rm -f $ORACLE_BASE/p27338041_121020_Linux-x86-64.zip
rm -f $ORACLE_BASE/p6880880_122010_Linux-x86-64.zip

# Remove patch archive area
rm -rf $ORACLE_HOME/.patch_storage
rm -rf $ORACLE_HOME/oc4j/.patch_storage
