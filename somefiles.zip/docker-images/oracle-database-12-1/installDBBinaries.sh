#*********************************************************************
#        File: installDBBinaries.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2018 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#
#      N/A
#
# DESCRIPTION:
#       Used to install the database binaries. Referenced on the Dockerfile to build
#       oracle database image.
#-------------------------------------------------------------------------------*/

INSTALL_DIR=$ORACLE_BASE/install
INSTALL_FILE_1=linuxamd64_12102_database_1of2.zip
INSTALL_FILE_2=linuxamd64_12102_database_2of2.zip
INSTALL_RSP=db_inst.rsp

# Install Oracle binaries
cd $INSTALL_DIR       && \
curl -O http://svrelease/release/oracle/12.1.0.2/$INSTALL_FILE_1 && \
curl -O http://svrelease/release/oracle/12.1.0.2/$INSTALL_FILE_2 && \
unzip $INSTALL_FILE_1 && \
rm $INSTALL_FILE_1    && \
unzip $INSTALL_FILE_2 && \
rm $INSTALL_FILE_2    && \
$INSTALL_DIR/database/runInstaller -silent -force -waitforcompletion -responsefile $INSTALL_DIR/$INSTALL_RSP -ignoresysprereqs -ignoreprereq && \
cd $HOME

# Remove not needed components
rm -rf $ORACLE_HOME/apex && \
# ZDLRA installer files
rm -rf $ORACLE_HOME/lib/ra*.zip && \
rm -rf $ORACLE_HOME/ords && \
rm -rf $ORACLE_HOME/sqldeveloper && \
rm -rf $ORACLE_HOME/ucp && \
# OUI backup
rm -rf $ORACLE_HOME/inventory/backup/* && \
# Network tools help
rm -rf $ORACLE_HOME/network/tools/help/mgr/help_* && \
# Temp location
find /tmp ! -readable -prune -o -type f -user sv_ora -exec rm -f {} \; && \
# Database files directory
rm -rf $INSTALL_DIR/database

# Check whether Perl is working
#chmod ug+x $INSTALL_DIR/installPerl.sh && \
#$ORACLE_HOME/perl/bin/perl -v || \
#$INSTALL_DIR/installPerl.sh
