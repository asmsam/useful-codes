Files in this directory
-----------------------

cb_createdb.ksh
  Automated database creation script. This script creates a database from a given Oracle database template with the follow extras:
    1. Oracle Enterprise Manager is enabled and configured to be managed locally.
    2. Security settings revert to pre-Oracle 11g defaults, mainly to prevent passwords from automatically expiring.
    3. The SYS and SYSTEM passwords are set to "atlanta".
    4. Total memory for Oracle is set to 1000 MB together with automatic memory management. *** Note, however, that it is recommended that automatic memory management be disabled. Read the section "Shared pool problems on development environments" below for instructions.


ORA11_1.dbt
  Oracle dbca template used to create an Oracle 11.1 database for development purposes.
    1. Redo log archiving is disabled, as well as redo log generation on the CB table spaces.
    2. CB table space storage characteristics are Locally Managed with Automatic Allocation. Data file maximums have been set for CB regression requirements.

ORA11_2.dbt
  Oracle dbca template used to create an Oracle 11.2 database for development purposes. Same characteristics as above.

ORA12_1.dbt
  Oracle dbca template used to create an Oracle 12c database for development purposes. Same characteristics as above.

sqlnet.ora
  Typical sqlnet.ora for a CB developement environment. Check $ORACLE_HOME/network/admin/sqlnet.ora to see if anything in this file should be copied over. If this is a brand new Oracle install, just copy the entire file to $ORACLE_HOME/network/admin/sqlnet.ora.


Creating a new CB Development Database
--------------------------------------

While sudoed in as the Oracle owner user:

. oraenv (to set ORACLE_HOME and the PATH - type in the full path to the Oracle home since there is no SID yet e.g. /sv/app/oracle/product/11.2.0)

Run the cb_createdb.ksh script. The script expects environment variables to be set from which it obtains the information it needs to create the database.

ORACLE_SID - the SID that you want to give the database being created.
DB_LISTENER_PORT - the port on which the Oracle listener will listen (look in /etc/services for it).
DB_TEMPLATE_NAME - the full path to the database template to use (e.g. ORA11_1.dbt).

ORACLE_BASE and ORACLE_HOME must also be set; running oraenv beforehand should have set them. ORACLE_BASE should be set to use /f01 if /f01 is available (e.g. /f01/oracle), which it usually is for development environments hosted on Support's hardware.

So, for example:

ORACLE_SID=XPS800 \
ORACLE_BASE=/f01/oracle \
DB_LISTENER_PORT=50461 \
DB_TEMPLATE_NAME=/sv/app/src/7.00/db/ORA11_2.dbt
/sv/app/src/8.00/db/cb_createdb.ksh

If the script fails there may be some manual clean-up required before running the script again.
  1. Shut down the database listener i.e. lsnrctl stop $ORACLE_SID.
  2. Go to $ORACLE_HOME/network/admin and remove any entries that were added for this database from the listener.ora and tnsnames.ora files.
  3. Reset the value of the remote_os_authent initialisation parameter, if it was set during post-installation, otherwise dbca will fail because a deprecated parameter is set:
    alter system reset remote_os_authent;
  4. To delete the database if it was partially created (or successfully created but you want to create it again with different parameters), run "dbca -silent -deleteDatabase -sourceDB <your DB SID>".


Post database creation tasks
----------------------------

1. Enable remote OS authentication if the development envrionment using this database will authenticate ATADBACONNECT using OS authentication i.e. alter system set remote_os_authent=true scope=spfile, and then stop/start the database. Cut and paste the following onto the command line.

sqlplus -L / as sysdba <<EOF
alter system set remote_os_authent=true scope=spfile;
shutdown immediate
startup
EOF

2. Enable redo log archiving if you need database recovery. The ORA11_2.dbt database template disables redo log archiving.

3. Register the database instance with Oracle Grid Control (GC), assuming a GC agent is running on this host.
     i. While the database instance listener is running, run '<path-to-agentca>/agentca -d' to register the listener with GC .e.g. ~/gcagent/agent11g/bin/agentca -d.
         - Or more simply:
             . oraenv
             GCAGENT
             agentca -d 
     ii. Either run 'emca -config centralAgent db' and answer all the prompts, or login to the central GC repository and complete the configuration of the instance.

4. Shut down the local Enterprise Manager control to save resources by running 'emctl stop dbconsole'. You can start it again if required by running 'emctl start dbconsole', but you can access EM for this database instance through GC if you registered it in step 3.

5. Disable large extent allocation for partitioned tables if using Oracle 11.2.0.2. This prevents partitioning of the database using excessive space and filling the tablespaces. This also requires a shutdown and startup of the database to take effect.

sqlplus -L / as sysdba <<EOF
alter system set "_partition_large_extents"=false;
EOF


Shared pool problems on development environments
------------------- ----------------------------
It is recommended that databases configured to use a small memory footprint use manual memory management rather than automatic memory management to prevent problems with Oracle trying to manage the small shared memory pool. If automatic memory management is left in place, you may eventually encounter errors along the lines of "ORA-04031: unable to allocate xxxx bytes of shared memory ("shared pool", ...)".

After creating the Oracle database, the following steps disable automatic memory management and configure the Oracle cache sizes manually.

1. Stop the SV instance.

2. Sudo to the Oracle owner account (sv_ora).

3. Cut and past the following lines onto the Unix command line.  These
settings are contained in OracleMemorySettings.sql and should be updated there as well.

sqlplus -L / as sysdba <<EOF
alter system reset memory_max_target scope=spfile;
alter system reset memory_target scope=spfile;
alter system reset sga_target scope=spfile;
alter system set shared_pool_size=520M scope=spfile;
alter system set db_cache_size=200M scope=spfile;
alter system set pga_aggregate_target=100M scope=spfile;
alter system set streams_pool_size=40M scope=spfile;
alter system set parallel_servers_target = 2;
alter system set parallel_max_servers = 2;
shutdown immediate
startup
EOF

4. Start the SV instance.


Oracle user accounts expired problem on development environments
---------------------------- -----------------------------------
By default, most of the users created under the development environments are
using Oracle 'DEFAULT' profile, for which usually has an expiry period for
180 days.

If you wish to make it never expire in your environment, you can consider the
followings:

1. Sudo to the Oracle owner account (sv_ora).

2. Cut and past the following lines onto the Unix command line.

sqlplus -L / as sysdba <<EOF
alter profile default limit password_life_time unlimited;
EOF

Optimizer statistics retention period
-------------------------------------
This defaults to 31 days and can bloat the SYSAUX tablespace, causing it to
fill.
Recommend setting it to a couple of days.
exec dbms_stats.alter_stats_history_retention(2);

3. Start the SV instance.


Oracle 12c Unified Auditing
---------------------------
It is recommended that unified auditing be used for Oracle 12 intallations. In order to use unified
auditing, it must first be enabled in the Oracle installation itself (ideally before creating any
databases) by enabling the unified auditing executable.

1. cd $ORACLE_HOME/rdbms/lib
2. make -f ins_rdbms.mk uniaud_on ioracle ORACLE_HOME=$ORACLE_HOME

After installing a new database instance, auditing will be enabled.
To disable it:

1. Cut and past the following lines onto the Unix command line.

sqlplus -L / as sysdba <<EOF
noaudit policy ora_secureconfig;
EOF

To check if the new style of auditing has been enabled, in sqlplus type:
1. select value from v$option where parameter = 'Unified Auditing';

To check that all audit policies have been disabled, in sqlplus type:
1. select * from audit_unified_enabled_policies;

See the "Oracle Database 2 Day + Security Guide" for further information on
unified auditing.

