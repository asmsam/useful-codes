#!/usr/bin/env perl
#
#       File:           OracleCleanup.pm
#       Created:        23-02-2016
#       Creator:        Peter Wiseman
#       $Revision: $
#       $Id: $
#
#==================================================================================
# COPYRIGHT (c) 1995-2016 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
# ALL RIGHTS RESERVED.
#
# THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
# AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
# ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
# IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
# MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
# SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
# SOFTWARE AND/OR INFORMATION.
#==================================================================================
#
# USAGE:
#
#       See zUsage()
#
# DESCRIPTION:
#
#       Perl module for cleaning the Oracle environment and database
#
# EXIT STATUS:
#
#       0       - Succeeded
#       1       - Error (+ Description)
#       2       - Usage
#
#
package OracleCleanup;
use strict;
use warnings;

#---------------------------------------------------------------------------
# LIBRARIES
#---------------------------------------------------------------------------
use Getopt::Long;

#---------------------------------------------------------------------------
# GLOBALS
#---------------------------------------------------------------------------
use vars qw (
    $opt_a
    $opt_h
    $opt_sid
);

#---------------------------------------------------------------------
#	CONSTANTS
#---------------------------------------------------------------------

# Exit codes
my $EXIT_SUCCESS        = 0;
my $EXIT_FAILURE        = 1;
my $EXIT_USAGE          = 2;

#---------------------------------------------------------------------------
# FUNCTIONS
#---------------------------------------------------------------------------

#############################################################################
sub zTrace
{
    my ($l_msg) = @_;
    
    printf "$l_msg\n";
}

#############################################################################
sub zCheckOraUser
{
    # All phases must be run as sv_ora user
    my $user = `whoami`;
    chomp $user;
    zTrace(sprintf("User is: $user"));

    if ($user ne "xps_ora" && $user ne "sv_ora")
    {
	print "Aborting. User must be sv_ora.\n";
	exit($EXIT_FAILURE);
    }
}

################################################################################
sub zDropDataPumpLogsForSid
{
    my ($l_oracle_sid) = @_;

    zTrace(sprintf("Dropping data pump logs for SID: $l_oracle_sid"));

    my $script;
    $script = <<'EOS';
startup;
select name from v$database;
select table_name from dba_tables where table_name like 'SYS_%_SCHEMA_%';
REM *** Remove any old failed DB export or DB import tables
SET SERVEROUTPUT on
DECLARE
  cmd varchar(200);

  CURSOR tablelist_cur IS
    SELECT owner, segment_name
      FROM dba_segments
     WHERE segment_name LIKE 'SYS_IMPORT%' OR
           segment_name LIKE 'SYS_EXPORT%';

BEGIN
  FOR tablelist IN tablelist_cur
  LOOP
    cmd := 'drop table ' || tablelist.owner || '.' || tablelist.segment_name;
    DBMS_OUTPUT.put_line(cmd);
    EXECUTE IMMEDIATE cmd;
   END LOOP;
END;
/
exit;
EOS

    open(SCRIPT, ">", "/tmp/script$$.sql") or die "Failed to open file for writing: $!";
    print SCRIPT $script;
    close SCRIPT;

    my $cmd = "dbhome $l_oracle_sid";
    my $rc = system($cmd);
    if ($rc) {
        print "Could not find database instance $l_oracle_sid. Skipping\n";
        return;
    }

    $cmd = "ORACLE_SID=$l_oracle_sid ORAENV_ASK=NO . oraenv; sqlplus / as sysdba @/tmp/script$$.sql";
    printf("Executing:$cmd\n");
    system($cmd);
    unlink("/tmp/script$$.sql");
}

################################################################################
sub zDropDataPumpLogsForHost
{
    my $host = `hostname`;
    chomp $host;
    my ($i,$j);

    # Assert $opt_a
    if (!$opt_a) { zUsage("-a must be specified to clean all databases a host") };

    zTrace("Host: $host\n");

    # Dart is used for script testing
    if ( $host eq 'dart') {
	zDropDataPumpLogsForSid "CB900R1";
	zDropDataPumpLogsForSid "BAD";
    }
    # CB Test Large Hosts
    elsif ($host eq 'hyrax01') {
	for ($i=1; $i<=10; $i++) {
	    for ($j=1; $j<=5; $j++) {
		my $linstance = sprintf("CT%02dR%d", $i, $j);
		zDropDataPumpLogsForSid $linstance;
	    }
	}
    }
    elsif ($host eq 'hyrax02') {
	for ($i=1; $i<=10; $i++) {
	    for ($j=1; $j<=5; $j++) {
		my $linstance = sprintf("CT%02dR%d", $i, $j);
		zDropDataPumpLogsForSid $linstance;
	    }
	}
    }
    elsif ($host eq 'hyrax03') {
	for ($i=1; $i<=10; $i++) {
	    for ($j=1; $j<=5; $j++) {
		my $linstance = sprintf("CT%02dR%d", $i, $j);
		zDropDataPumpLogsForSid $linstance;
	    }
	}
    }
    # PE Test PCs
    elsif ($host eq 'uxbrilx16') {
	for ($i=1; $i<=6; $i++) {
	    my $linstance=sprintf("PE900R%d", $i);
	    zDropDataPumpLogsForSid $linstance;
	}
    }
    elsif ( $host eq 'uxbrilx34') {
	for ($i=1; $i<=6; $i++) {
	    my $linstance=sprintf("CT34R%d", $i);
	    zDropDataPumpLogsForSid $linstance;
	}
    }
    elsif ( $host eq 'uxbrilx35') {
	for ($i=1; $i<=6; $i++) {
	    my $linstance=sprintf("CT35R%d",$i);
	    zDropDataPumpLogsForSid $linstance;
	}
    }
    elsif ( $host eq 'uxbrilx36') {
	for ($i=1; $i<=6; $i++) {
	    my $linstance=sprintf("CT36R%d",$i);
	    zDropDataPumpLogsForSid $linstance;
	}
    }
    elsif ( $host eq 'uxbrilx37') {
	for ($i=1; $i<=6; $i++) {
	    my $linstance=sprintf("CT37R%d",$i);
	    zDropDataPumpLogsForSid $linstance;
	}
    }
    # CB Test PCs (default)
    else {
	for ($i=1; $i<=5; $i++) {
	    my $linstance=sprintf("CB900R%d",$i);
	    zDropDataPumpLogsForSid $linstance
	}
    }
}

#############################################################################
sub zUsage
{
    my ($l_msg) = @_;

    print STDERR "$l_msg\n" if $l_msg;

    print STDERR <<EOS;
Usage:

    OracleCleanup [-a]

    Where
        -a              Cleans up all environments on a host (use with caution)
        -sid <instance> Cleans up the specified instance only

EOS
    exit($EXIT_USAGE);
}

################################################################################
sub zProcessOptions
{
    # Extract command-line arguments
    my @loptions = ("h","a","sid:s");
    if (!GetOptions(@loptions) ) {
        zUsage;
    }

    # Help
    if (defined($opt_h)) {
        zUsage;
    }
}

################################################################################
sub main
{
    zCheckOraUser;

    zProcessOptions;

    # Explicit SID
    if ($opt_sid) {
        zDropDataPumpLogsForSid $opt_sid;
    }
    
    # Default processing
    if (!$opt_sid) {
        zDropDataPumpLogsForHost;    
    }

    return($EXIT_SUCCESS);
}

################################################################################
1;
