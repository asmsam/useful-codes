#!/usr/bin/env perl
#
#       File:           OracleCleanup.pl
#       Created:        22-02-2016
#       Creator:        Peter Wiseman
#       $Revision: $
#       $Id: $
#
#==================================================================================
# COPYRIGHT (c) 1995-2016 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
# ALL RIGHTS RESERVED.
#
# THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
# AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
# ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
# IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
# MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
# SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
# SOFTWARE AND/OR INFORMATION.
#==================================================================================
#
# USAGE:
#
#       See zUsage()
#
# DESCRIPTION:
#
#       Cleanup Oracle environment and database
#
# EXIT STATUS:
#
#       0       - Succeeded
#       1       - Error (+ Description)
#       2       - Usage
#
#
#
use strict;
use warnings;

use File::Basename qw(dirname);
use Cwd qw(abs_path);
use lib dirname abs_path $0;
use OracleCleanup;

#------------------------------------------------------------------------------
# DUMP
#------------------------------------------------------------------------------
sub zDumpInc
{
    print "\$0 = $0\n";
    print "\@INC = (\n";
    foreach my $dir (@INC) {
        printf("  %s\n", $dir);
    }
    print ")\n";
}

#------------------------------------------------------------------------------
# TEST
# To perform adhoc testing, comment the "main" function above and uncomment one of the 
# functions below.
#  
#------------------------------------------------------------------------------
#OracleCleanup::zDropDataPumpLogsForSid('CB900R1');
#OracleCleanup::zDropDataPumpLogsForHost
#zDumpInc();

#------------------------------------------------------------------------------
# MAIN
#------------------------------------------------------------------------------
OracleCleanup::main;
