#!/bin/sh

# To connect back to current node
export DOCKER_HOST=$SLAVE_HOSTNAME:2376

echo "==============Environment==============="
env

echo "==============/run/secrets=============="
ls -l /run/secrets/

PATH=$PATH:/sv/app/10.00/java/rel/bin
JAVA_HOME=/sv/app/10.00/java/rel

# Uncomment to login implcitely for every agent:
#echo "Logging into docker registry:"
#cat /run/secrets/jenkins-nexus-password | docker login --username $(cat /run/secrets/jenkins-nexus-username) --password-stdin ${DOCKER_REGISTRY}

echo "Starting jenkins agent to $DOCKER_SWARM_PLUGIN_JENKINS_AGENT_JNLP_URL"
exec java -jar /home/jenkins/agent.jar -jnlpUrl $DOCKER_SWARM_PLUGIN_JENKINS_AGENT_JNLP_URL -secret $DOCKER_SWARM_PLUGIN_JENKINS_AGENT_SECRET -noReconnect -workDir /tmp
