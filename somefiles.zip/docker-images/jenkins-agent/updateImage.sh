#!/bin/sh
#
#        File: updateCTImages.sh
#     Created: 18-Jun-2018 14:26:59
#     Creator: shird
#   $Revision: $
#        
# ==================================================================================
#  COPYRIGHT (c) 1995-2018 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#
#      ./updateImage.sh
#
# DESCRIPTION:
#       Rebuilds and pushes the images registry-svrnd:5000/csg/ct/jenkins/jenkins-agent:latest
#       Should be run as a one-off service with appropriate secrets set. 
#
#-------------------------------------------------------------------------------

# Login as 'jenkins' for push access
cat /run/secrets/jenkins-nexus-password | docker login --username $(cat /run/secrets/jenkins-nexus-username) --password-stdin ${DOCKER_REGISTRY}

#-------------------------------------------------------------------------------
# Global Variables
#-------------------------------------------------------------------------------
DATE=`date +%Y%m%d`

set -e
LATEST_IMAGE="registry-svrnd:5000/csg/ct/jenkins/jenkins-agent:latest"
LATEST_IMAGE_DATE="registry-svrnd:5000/csg/ct/jenkins/jenkins-agent:${DATE}"

#-------------------------------------------------------------------------------
# zcleanImages
#     Deletes the local images created
#-------------------------------------------------------------------------------
function zcleanImages {
    docker rmi -f ${LATEST_IMAGE} ${LATEST_IMAGE_DATE}
}

#-------------------------------------------------------------------------------
# MAIN CODE
#-------------------------------------------------------------------------------

echo "Downloading slave agent from $DOCKER_SWARM_PLUGIN_JENKINS_AGENT_JAR_URL"
curl -fL -o ./agent.jar $DOCKER_SWARM_PLUGIN_JENKINS_AGENT_JAR_URL

if [[ $? == 0 ]]; then
    echo "Building slave agent image"
    docker build --no-cache -t $LATEST_IMAGE .
else
    echo "Failed downloading slave agent"
    exit 1
fi

if [[ $? == 0 ]]; then
    echo "Tagging"
    docker tag ${LATEST_IMAGE} ${LATEST_IMAGE_DATE}
else
    echo "Failed building docker image"
    exit 1
fi

echo "Pushing slave agent image"
docker push ${LATEST_IMAGE} 
if [[ $? == 0 ]]; then
    docker push ${LATEST_IMAGE_DATE}
else
    zcleanImages
    echo "Failed to push the image"
    exit 1
fi

if [[ $? == 0 ]]; then
    zcleanImages
    echo "Updated image successfully"
else
    zcleanImages
    echo "Failed Pushing the image"
    exit 1
fi
