#!/bin/sh
# Helper script for local development

# For SV10 and Oracle 12.1
# docker build \
#     --pull --no-cache \
#     -f Dockerfile-10-ora12.1ee-rhel7.6-cert \
#     -t dev-11-cert \
#     .
#
# For SV11 and Oracle 19.3 
#docker build \
#    --pull --no-cache \
#    -f Dockerfile-11-ora19.3ee-rhel7.6-cert \
#    -t cthost:dev-11-cert \
#    .

# For SV12 and Oracle 19.7
docker build \
    --pull --no-cache \
    -f Dockerfile-12-ora19.7ee-rhel8.6-cert \
    -t cthost:dev-12-cert \
    .

# Prune all "cert" images to reclaim space
docker image prune --filter="label=CUSTOM=cert" --all --force
