#!/bin/sh
#
#        File:           installTuxedoRP-sv11.sh
#        Created:        10-Jun-2020 00:00:00
#        Creator:        pwi  (Peter Wiseman)
#        $Revision:$
#        $Id:$
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2020 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#       installTuxedoRP-sv11.sh
#
# DESCRIPTION:
#       Download and install a specific Tuxedo binary patch
#
# EXIT STATUS:
#
#        0        - Succeeded
#        1        - Error (+ Description)
#        2        - Usage
#
#-------------------------------------------------------------------------------

# zIsAws
#
# Returns
#   SUCCESS if AWS
#   FAIL    if not AWS
#-------------------------------------------------------------------------------
function zIsAWS
{
    typeset id=''
    if [[ -e /sys/devices/virtual/dmi/id/board_asset_tag ]]; then
        id=$(cat /sys/devices/virtual/dmi/id/board_asset_tag)
    fi
    if [[ -n $id ]]; then
        # AWS
        return 0
    fi

    # Not AWS
    return 1
}

#-------------------------------------------------------------------------------
# zDownloadPatch
#-------------------------------------------------------------------------------
function zDownloadPatch
{
    typeset RC=1

    # Parameters
    typeset PatchDir="${1}"
    typeset PatchFile="${2}"

    typeset Dest=$SVAPP_SRC/$PatchFile

    if zIsAWS; then
        # AWS
        typeset Source="s3://csgibri-svrndct-tools-and-software/$PatchDir/$PatchFile"
        echo "Downloading from $Source to $Dest"
        /usr/local/bin/aws s3 cp $Source $Dest
        RC=$?
    fi

    if [[ ! -e $Dest ]]; then
        # On-Premise
        typeset Source="http://svrelease/release/$PatchDir/$PatchFile"
        echo "Downloading from $Source to $Dest"
        curl $Source -o $Dest
        RC=$?
    fi

    return $RC
}

#-------------------------------------------------------------------------------
# zinstallTuxedo
#-------------------------------------------------------------------------------
function zinstallTuxedo
{
    # Parameters
    typeset TuxInstallBase="${1}"
    typeset TuxInstallDir="${2}"
    typeset TuxPackageDir="${3}"
    typeset TuxPackageFile="${4}"

    # Download patch
    if ! zDownloadPatch $TuxPackageDir $TuxPackageFile; then
        echo "ERROR: Failed to download patch $TuxPackageFile"
        exit 1
    fi

    # Check Install.log as we cannot depend on the return code
    if ! sh ./install_tux_122.sh \
            $TuxInstallBase $TuxInstallDir $TuxPackageFile Linux; then
        echo "ERROR: Failed to install Tuxedo"
        exit 1
    fi
}

#-------------------------------------------------------------------------------
# zinstallTuxedoRP
#-------------------------------------------------------------------------------
function zinstallTuxedoRP
{
    # Parameters
    typeset TuxInstallBase="${1}"
    typeset TuxInstallDir="${2}"
    typeset TuxPackageDir="${3}"
    typeset TuxPackageFile="${4}"
    typeset TuxPatchNumber="${5}"

    typeset TuxPatchTmpDir="tuxedo122_patches"   # Temporary Dir

    # Download patch
    if ! zDownloadPatch $TuxPackageDir $TuxPackageFile; then
        echo "ERROR: Failed to download patch $TuxPackageFile"
        exit 1
    fi

    # Check Install.log as we cannot depend on the return code
    if ! sh ./apply_tux_patch_122.sh \
            $TuxInstallBase $TuxInstallDir \
            $TuxPatchTmpDir $TuxPackageFile \
            $TuxPatchNumber; then
        echo "ERROR: Failed to install Tuxedo"
        exit 1
    fi
}

#-------------------------------------------------------------------------------
# Main Code
#-------------------------------------------------------------------------------

BaseVer=12.2
BaseFile=tuxedo122200_64_Linux_01_x86.zip
PatchNumber=RP108
PatchFileNumber=36005623
PatchFile=p36028378_122200_Linux-x86-64.zip
BaseDir=tuxedo/linux_x86_64/${BaseVer}
PatchDir=${BaseDir}/${BaseVer}_${PatchNumber}

# The patch will be installed into the base directory
# as this is the location the tests expect.
export TUX_INSTALL_BASE=$SVAPP_INSTALLDIR/tuxedo
export TUX_INSTALL_DIR=$TUX_INSTALL_BASE/product/${BaseVer}

# Install base Tuxedo Patch
# Re-installation of the tuxedo base version is typically
# not required when installing a patch.  Uncomment if required.
zinstallTuxedo $TUX_INSTALL_BASE $TUX_INSTALL_DIR $BaseDir $BaseFile

# Install Patch
zinstallTuxedoRP $TUX_INSTALL_BASE $TUX_INSTALL_DIR $PatchDir $PatchFile $PatchFileNumber
