#!/bin/sh
#
#        File:           install_tux_22c.sh
#        Created:        28-Sep-2023 00:00:00
#        Creator:        nirsur01  (Surya Nirvana)
#        $Revision:$
#        $Id:$
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2020 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#       install_tux_22c.sh \
#               <Tuxedo install base> \
#               <Tuxedo install dir> \
#               <Package file> \
#               <OS Name>
#
# DESCRIPTION:
#       Installs a Tuxedo binary package into the required install directory.
#
# EXIT STATUS:
#
#        0        - Succeeded
#        1        - Error (+ Description)
#        2        - Usage
#

if [ "$#" -ne 4 ]; then
    echo "$0"
    echo "$#"
    echo "Illegal number of parameters"
    echo "Usage: install_tux <Tux install base> <Tuxedo install dir> <package file> <OS Name>"
    exit 2
fi
export TUX_INSTALL_BASE=$1   # Example: /sv/app/tuxedo
export TUX_INSTALL_DIR=$2    # Example: /sv/app/tuxedo/product/22c
export TUX_PACKAGE=$3        # Example: V1031234-01_Linux_X86_64.zip
export OS=$4                 # Example: Linux

SCRIPT_NAME=$(basename $0)
SVAPP_SRC=$PWD
TUX_EXTRACT_DIR=$PWD/tuxedo22c_install
TUX_RESPONSE_FILE=install_tuxedo_22c.rsp
TUX_RESPONSE_FILE_LOCALISED=install_tuxedo_22c_local.rsp
TUXDIR=$TUX_INSTALL_DIR/tuxedo22.1.0.0.0
TRACE=0 # 0=disable 1=enable

if [[ -z $JAVA_HOME ]]; then
    JAVA_HOME=/sv/app/java8
fi

log() {
    typeset message=${1}
    echo "$(date +"%F %T"): $SCRIPT_NAME: $message"
}

log_start() {
    typeset step_name=${1}
    log $step_name
}

is_trace() {
    if [[ $TRACE = 1 ]]; then
        # Return success when trace is enabled
        return 0
    fi
    return 1
}

trace() {
    typeset message=${1}
    if ! is_trace; then
        return; 
    fi
    log $message
}

executeCommand() {
    # Execute the command passed. Exit on failure.
    eval $1 > ${SCRIPT_NAME}.$$.log

    if [ $? -ne 0 ]; then
        cat ${SCRIPT_NAME}.$$.log
        rm ${SCRIPT_NAME}.$$.log
        echo "ERROR: ${1} failed!"
        exit 1;
    fi

    rm ${SCRIPT_NAME}.$$.log
}

clean() {
    log_start "clean()"
    rm -rf $TUX_INSTALL_DIR
    rm -rf $TUX_EXTRACT_DIR
}

prepare() {
    log_start "prepare()"
    mkdir -p $TUX_INSTALL_BASE/product
    mkdir -p $TUX_EXTRACT_DIR
}

create_response_file() {
    # Localise the install_tuxedo_22c.rsp file with environment variables
    # ORACLE_HOME      => $TUX_INSTALL_DIR
    # ORACLE_HOME_NAME => Derived from TUX_INSTALL_DIR (e.g. Tuxedo22cHome)
    # FROM_LOCATION    => $TUX_EXTRACT_DIR
    log_start "create_response_file()"
    typeset TUX_INSTALL_NAME=$(basename $TUX_INSTALL_DIR)
    TUX_INSTALL_NAME=$(echo "Tuxedo${TUX_INSTALL_NAME}Home" | tr -d "._")
    trace "TUX_EXTRACT_DIR=$TUX_EXTRACT_DIR"
    trace "TUX_INSTALL_DIR=$TUX_INSTALL_DIR"
    trace "TUX_INSTALL_NAME=$TUX_INSTALL_NAME"
    cd $SVAPP_SRC

    awk -F= -vTUX_EXTRACT_DIR=$TUX_EXTRACT_DIR \
            -vTUX_INSTALL_DIR=$TUX_INSTALL_DIR \
            -vTUX_INSTALL_NAME=$TUX_INSTALL_NAME \
            '{ if ($1=="ORACLE_HOME") print $1"="TUX_INSTALL_DIR;                                \
            else if ($1=="ORACLE_HOME_NAME") print $1"="TUX_INSTALL_NAME;                        \
            else if ($1=="FROM_LOCATION") print $1"="TUX_EXTRACT_DIR"/Disk1/stage/products.xml"; \
            else print $0;                                                                              \
            }' $TUX_RESPONSE_FILE > $TUX_RESPONSE_FILE_LOCALISED

    if [ $? -ne 0 ]; then
        exit 1;
    fi
    if is_trace; then
        diff $TUX_RESPONSE_FILE $TUX_RESPONSE_FILE_LOCALISED
    fi
}

extract_zip() {
    log_start "extract_zip()"
    executeCommand "unzip -o $TUX_PACKAGE -d $TUX_EXTRACT_DIR"
}

create_oraInst() {
    log_start "create_oraInst()"
    trace "ORAINST=$TUX_INSTALL_BASE/product/oraInst.loc"

    echo inventory_loc=$TUX_INSTALL_BASE/product/oraInventory \
            >$TUX_INSTALL_BASE/product/oraInst.loc
    echo inst_group=sv_app \
            >>$TUX_INSTALL_BASE/product/oraInst.loc

    if is_trace; then
        cat $TUX_INSTALL_BASE/product/oraInst.loc
    fi
}

run_installer() {
    log_start "run_installer()"
    typeset RC=1
    export JAVA_HOME=$JAVA_HOME
    export ORACLE_HOME=$TUX_INSTALL_DIR

    cd $TUX_EXTRACT_DIR/Disk1/install
    $SHELL ./runInstaller.sh -silent -waitforcompletion \
            -ignoreSysPrereqs \
            -responseFile $SVAPP_SRC/$TUX_RESPONSE_FILE_LOCALISED \
            -invPtrLoc $TUX_INSTALL_BASE/product/oraInst.loc > ${SCRIPT_NAME}.$$.log
    RC=$?

    if [[ $RC -ne 0 ]]; then
        log "run_installer(): output"
        cat ${SCRIPT_NAME}.$$.log
        rm ${SCRIPT_NAME}.$$.log
        log "run_installer(): end of output"
        #log "run_installer(): installActions log"
        #cat /sv/app/11.00/tuxedo/product/oraInventory/logs/installActions*
        #log "run_installer(): End of installActions log"
        exit 1
    fi
    rm ${SCRIPT_NAME}.$$.log

    return $RC
}

install_locale() {
    log_start "install_locale()"
    if [ ! -d  $TUXDIR/locale ]; then
        echo "ERROR: $TUXDIR/locale not created by $TUX_PACKAGE"
        exit 1;
    fi

    cd $TUXDIR/locale && ln -s C en_US.iso88591
}

install_RM() {
    log_start "install_RM()"
    cd $SVAPP_SRC
    if [ ! -d  $TUXDIR/udataobj ]; then
        echo "ERROR: $TUXDIR/udataobj not created by $TUX_PACKAGE"
        exit 1;
    fi

    if [[ "$OS" = "Linux" ]]; then
        cat RM.sv >> $TUXDIR/udataobj/RM
    else
        cat RM-$OS.sv >> $TUXDIR/udataobj/RM
    fi;
}

clean_detach() {
    # Detach the ORACLE_HOME form the central inventory.
    # Does not appear to be needed when re-installing after removing
    # the ORACLE_HOME.
    log_start "clean_detach()"
    export JAVA_HOME=$JAVA_HOME
    export ORACLE_HOME=$TUX_INSTALL_DIR
    cd $TUX_INSTALL_DIR/oui/bin
    $SHELL ./runInstaller.sh -silent \
            -ignoreSysPrereqs \
            -detachHome ORACLE_HOME=$TUX_INSTALL_DIR \
            -invPtrLoc $TUX_INSTALL_BASE/product/oraInst.loc > ${SCRIPT_NAME}.$$.log
    RC=$?
    if [ "$RC" -ne 0 ]; then
        log "run_installer(): output"
        cat ${SCRIPT_NAME}.$$.log
        log "run_installer(): end of output"
        exit 1
    fi
    rm -f ${SCRIPT_NAME}.$$.log

    return $RC

}

install() {
    clean
    prepare
    create_response_file
    extract_zip
    create_oraInst
    run_installer
    install_locale
    install_RM
    log "Install complete"
}

install
