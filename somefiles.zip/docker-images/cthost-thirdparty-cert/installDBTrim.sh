#*********************************************************************
#        File: installDBTrim.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2022 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#
#      N/A
#
# DESCRIPTION:
#       Used to trim database binaries.
#-------------------------------------------------------------------------------*/

# Remove not needed components
echo Removing not needed components
rm -rf $ORACLE_HOME/apex
# ZDLRA installer files
rm -rf $ORACLE_HOME/lib/ra*.zip
rm -rf $ORACLE_HOME/ords
rm -rf $ORACLE_HOME/ucp
# OUI backup
rm -rf $ORACLE_HOME/inventory/backup/*
# Network tools help
rm -rf $ORACLE_HOME/network/tools/help/mgr/help_*

# Removing log4j libraries
echo Removing log4j 2.x libraries
rm -f $ORACLE_HOME/md/property_graph/lib/log4j-api-2*.jar
rm -f $ORACLE_HOME/md/property_graph/lib/log4j-core-2*.jar
rm -f $ORACLE_HOME/md/property_graph/lib/log4j-jcl-2*.jar
rm -f $ORACLE_HOME/md/property_graph/lib/log4j-slf4j-impl-2*.jar
rm -f $ORACLE_HOME/md/property_graph/pgx/server/pgx-webapp-*.war
rm -f $ORACLE_HOME/suptools/tfa/release/tfa_home/jlib/log4j-api-2*.jar
rm -f $ORACLE_HOME/suptools/tfa/release/tfa_home/jlib/log4j-core-2*.jar
rm -f $ORACLE_HOME/suptools/tfa/release/tfa_home/jlib/tfa.war

# Removing temporary files
echo Removing tmp files
find /tmp ! -readable -prune -o -type f -user sv_ora -exec rm -f {} \;

echo Database install trim finished