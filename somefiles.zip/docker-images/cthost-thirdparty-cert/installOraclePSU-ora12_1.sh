#!/bin/sh
#
#        File:           installOraclePSU-ora12_1.sh
#        Created:        07-Sep-2020 00:00:00
#        Creator:        mantic (Miroljub Antic)
#        $Revision:$
#        $Id:$
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2020 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =================================================================================#
# USAGE:
#       installOraclePSU-ora12_1.sh
#
# DESCRIPTION:
#       Download and install a specific Tuxedo binary patch
#
# EXIT STATUS:
#
#        0        - Succeeded
#        1        - Error (+ Description)
#        2        - Usage
#
#-------------------------------------------------------------------------------

echo "starting ..."
echo "ORACLE_HOME=" $ORACLE_HOME

#-------------------------------------------------------------------------------
# zIsAws
#
# Returns
#   SUCCESS if AWS
#   FAIL    if not AWS
#-------------------------------------------------------------------------------
function zIsAWS
{
    typeset id=''
    if [[ -e /sys/devices/virtual/dmi/id/board_asset_tag ]]; then
        id=$(cat /sys/devices/virtual/dmi/id/board_asset_tag)
    fi
    if [[ -n $id ]]; then
        # AWS
        return 0
    fi

    # Not AWS
    return 1
}

#-------------------------------------------------------------------------------
# zinstallOPatch
#-------------------------------------------------------------------------------
function zinstallOPatch
{
    typeset RC=1

    # Parameters
    typeset OPatchDir="${1}"
    typeset OPatchZip="${2}"

    # Download OPatch
    if ! zDownloadPatch $OPatchDir $OPatchZip; then
        echo "Failed to download patch $OPatchZip"
        exit 1
    fi

    # Install Opatch
    cd $ORACLE_HOME
    rm -rf $ORACLE_HOME/OPatch

    unzip $ORACLE_BASE/$OPatchZip
    RC=$?
    if [[ $RC -ne 0 && $RC -ne 1 ]]; then
        echo "Failed to unzip OPatch $OPatchZip"
        exit 1
    fi

    # Cleanup
    rm -f $ORACLE_BASE/$OPatchZip
}

#-------------------------------------------------------------------------------
# zDownloadPatch
#-------------------------------------------------------------------------------
function zDownloadPatch
{
    typeset RC=1

    # Parameters
    typeset OraPatchDir="${1}"
    typeset OraPatchZip="${2}"

    if zIsAWS; then
        # AWS
        typeset Source="s3://csgibri-svrndct-tools-and-software/oracle/$OraPatchDir/$OraPatchZip"
        echo "Downloading from $Source"
        /usr/local/bin/aws s3 cp $Source $ORACLE_BASE/$OraPatchZip
        RC=$?
    fi

    if [[ ! -e $ORACLE_BASE/$OraPatchZip ]]; then
        # On-Premise
        typeset Source="http://svrelease/release/oracle/$OraPatchDir/$OraPatchZip"
        echo "Downloading from $Source"
        curl $Source -o $ORACLE_BASE/$OraPatchZip
        RC=$?
    fi

    return $RC
}

#-------------------------------------------------------------------------------
# zinstallOraclePatch
#-------------------------------------------------------------------------------
function zinstallOraclePatch
{
    typeset RC=1

    # Parameters
    typeset OraPatchNumer="${1}"
    typeset OraPatchZip="${2}"
    typeset OraPatchDir="${3}"

    # Download patch
    if ! zDownloadPatch $OraPatchDir $OraPatchZip; then
        echo "Failed to download patch $OraPatchZip"
        exit 1
    fi

    # Install patch
    cd $ORACLE_BASE
    unzip $OraPatchZip
    RC=$?
    if [[ $RC -ne 0 && $RC -ne 1 ]]; then
        echo "Failed to unzip patch $OraPatchZip"
        exit 1
    fi
    cd $OraPatchNumer/
    if ! PATH=$ORACLE_HOME/OPatch:$PATH opatch apply -silent; then
        echo "Failed to install patch $OraPatchZip"
        exit 1
    fi

    # Check Patch has been installed
    if ! $ORACLE_HOME/OPatch/opatch lsinventory | grep -E "^Patch  |^Sub-patch  " | grep -E " $OraPatchNumer"; then
         $ORACLE_HOME/OPatch/opatch lsinventory
        echo "Failed to find $OraPatchNumer in lsinventory. See above lsinventory listing"
        exit 1
    fi

    # Cleanup
    rm -rf $ORACLE_BASE/$OraPatchNumer
    rm -f $ORACLE_BASE/$OraPatchZip
    rm -f $ORACLE_BASE/PatchSearch.xml
}

#-------------------------------------------------------------------------------
# Main Code
#-------------------------------------------------------------------------------

# Install OPatch
OPatchZip=p6880880_122010_Linux-x86-64.zip
OPatchDir=12/OPatch
zinstallOPatch $OPatchDir $OPatchZip

# Install Patch
PatchNumber=34386266
PatchDir=12/PSU12.1.0.2.221018
PatchFile=p34386266_121020_Linux-x86-64.zip
zinstallOraclePatch $PatchNumber $PatchFile $PatchDir

# Remove patch archive area
rm -rf $ORACLE_HOME/.patch_storage
rm -rf $HOME/.patch_storage
