# CTHost Third Party Certifications

Used for the following quarterly third party certifications

* Oracle Database
    * Oracle 12.1  - Patch Set Update (PSU)
    * Oracle 19    - Release Update (RU)
* Oracle Tuxedo    - Rolling Patch (RP)

Version numbers and locations of the quarterly packages need to
be updated in the following files

* installOraclePSU-ora12_1.sh
* installOracleRU-ora19.sh
* installTuxedo-tux122.sh

The docker image can be built locally in a vmgui2 instance using a helper 
script. 

* build.sh (Review and edit this script prior to use)

The final image should be built and pushed using the jenkins BASEIMAGES jobs

* http://jenkins-svrnd-aws:8080/jenkins/view/Docker%20Images/

Oracle packages can be downloaded from Oracle direct to a linux instance using
the wget download script from Oracle. The included script is an example. When
running the script, it will appear to hang whilst waiting for a password,as the
prompt is sent to the logfile rather than the commandline.

* wget-*.sh

Naming conventions for images follows the general naming convention with
"-cert" on the end.  If there are multiple certification streams this could
be changed to "-cert1", "-cert2".

* 11-ora19.3ee-rhel7.6-cert

A label on the image will be used to identify the certification stream.

* CERT=cert (deprecated)
* CUSTOM=cert