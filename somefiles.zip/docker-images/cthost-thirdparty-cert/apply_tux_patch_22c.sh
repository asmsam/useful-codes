#!/bin/sh
#
#        File:           apply_tux_patch_22c.sh
#        Created:        06-Dec-2023 00:00:00
#        Creator:        nirsur01  (Surya Nirvana)
#        $Revision:$
#        $Id:$
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2020 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#       apply_tux_patch_22c.sh \
#               <Tuxedo install base> \
#               <Tuxedo install dir> \
#               <Package Tmp Dir>
#               <Package file> \
#               <Patch Number>
#
# DESCRIPTION:
#       Installs a Tuxedo binary patch into the required install directory.
#
# EXIT STATUS:
#
#        0        - Succeeded
#        1        - Error (+ Description)
#        2        - Usage
#
if [ "$#" -ne 5 ]; then
    echo "$0"
    echo "$#"
    echo "Illegal number of parameters"
    echo "Usage: apply_tux_patch.sh <Tux install base> <Tuxedo install dir> <package tmp dir> <package file> <patch number>"
    exit 2
fi
TUX_INSTALL_BASE=$1   # Example: /sv/app/tuxedo
TUX_INSTALL_DIR=$2    # Example: /sv/app/tuxedo/product/22c
TUX_PATCH_DIR=$3      # Example: tuxedo22c_patches
TUX_PATCH_FILE=$4     # Example: p35056749_22c_Linux_X86_64.zip
TUX_PATCH_NUMBER=$5   # Example: 35056749

SCRIPT_NAME=$(basename $0)
SVAPP_SRC=$PWD
TUXDIR=$TUX_INSTALL_DIR/tuxedo22.1.0.0.0
TRACE=0 # 0=disable 1=enable

if [[ -z $JAVA_HOME ]]; then
    JAVA_HOME=/sv/app/java8
fi

log() {
    typeset message=${1}
    echo "$(date +"%F %T"): $SCRIPT_NAME: $message"
}

log_start() {
    typeset step_name=${1}
    log $step_name
}

is_trace() {
    if [[ $TRACE = 1 ]]; then
        # Return success when trace is enabled
        return 0
    fi
    return 1
}

trace() {
    typeset message=${1}
    if ! is_trace; then
        return; 
    fi
    log $message
}

executeCommand() {
    # Execute the command passed.
    eval $1 > ${SCRIPT_NAME}.$$.log

    if [ $? -ne 0 ]; then
        cat ${SCRIPT_NAME}.$$.log
        rm ${SCRIPT_NAME}.$$.log
       echo "ERROR: ${1} failed!"
       exit 1
    fi

    rm -f ${SCRIPT_NAME}.$$.log
}

clean() {
    log_start "clean()"
    rm -rf $SVAPP_SRC/$TUX_PATCH_DIR
}

prepare() {
    log_start "prepare()"
    executeCommand "mkdir $SVAPP_SRC/$TUX_PATCH_DIR"
}

extract_zip() {
    log_start "extract_zip()"
    cd $SVAPP_SRC/$TUX_PATCH_DIR
    executeCommand "unzip -q $SVAPP_SRC/$TUX_PATCH_FILE"
}

apply_patch() {
    log_start "apply_patch()"
    export JAVA_HOME=${JAVA_HOME}
    export ORACLE_HOME=${TUX_INSTALL_DIR}
    cd ${SVAPP_SRC}/${TUX_PATCH_DIR}
    if [[ ! -f ${TUX_PATCH_NUMBER}.zip ]]; then
        echo "ERROR: ${TUX_PATCH_NUMBER}.zip does not exist"
        exit 1
    fi
    sh ${TUX_INSTALL_DIR}/OPatch/opatch apply ${TUX_PATCH_NUMBER}.zip \
            -silent -invPtrLoc ${TUX_INSTALL_BASE}/product/oraInst.loc \
            > ${SCRIPT_NAME}.$$.log
    if [[ $? -ne 0 ]]; then
        cat ${SCRIPT_NAME}.$$.log
        exit 1
    fi
    if ! grep -q "OPatch succeeded" ${SCRIPT_NAME}.$$.log; then
        cat ${SCRIPT_NAME}.$$.log
        exit 1
    fi
}

fix_permissions() {
    log_start "fix_permissions()"
    find ${TUX_INSTALL_DIR} -perm -g+x -exec chmod o+x {} \;
    find ${TUX_INSTALL_DIR} -perm -g+r -exec chmod o+r {} \;
}

install() {
    clean
    prepare
    extract_zip
    apply_patch
    fix_permissions
    log "Install complete"
}

install
