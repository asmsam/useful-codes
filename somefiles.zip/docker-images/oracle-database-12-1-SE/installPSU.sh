#!/bin/ksh

ORA_PATCH_FILE=p6880880_121010_Linux-x86-64.zip
ORA_DB_PSU_NUMBER=24732082
ORA_DB_PSU_DIR=PSU12.1.0.2.170117
ORA_DB_PSU_FILE=p24732082_121020_Linux-x86-64.zip

cd $ORACLE_BASE
curl http://svrelease/release/oracle/OPatch/${ORA_PATCH_FILE} -o ${ORA_PATCH_FILE}
curl http://svrelease/release/oracle/${ORA_DB_PSU_DIR}/${ORA_DB_PSU_FILE} -o ${ORA_DB_PSU_FILE}

# Install OPatch
cd $ORACLE_HOME
unzip -o /opt/oracle/${ORA_PATCH_FILE}

# Install PSU
cd $ORACLE_BASE
unzip ${ORA_DB_PSU_FILE}
cd ${ORA_DB_PSU_NUMBER}/
PATH=$ORACLE_HOME/OPatch:$PATH opatch apply -silent

# Manually apply prvtash.plb from p${ORA_DB_PSU_NUMBER} due to a bug in the PSU. See Oracle bug 27938623
# https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=419047187690629&id=2392962.1&displayIndex=1&_afrWindowMode=0&_adf.ctrl-state=12rad8qvf8_85
cp -f $ORACLE_BASE/${ORA_DB_PSU_NUMBER}/${ORA_DB_PSU_NUMBER}/files/rdbms/admin/prvtash.plb $ORACLE_HOME/rdbms/admin/.
$ORACLE_HOME/bin/sqlplus / as sysdba <<EOF
@$ORACLE_HOME/rdbms/admin/prvtash.plb
quit;
EOF

rm -rf $ORACLE_BASE/${ORA_DB_PSU_NUMBER}
rm -f $ORACLE_BASE/${ORA_DB_PSU_FILE}
rm -f $ORACLE_BASE/${ORA_PATCH_FILE}

# Remove patch archive area
rm -rf $ORACLE_HOME/.patch_storage
rm -rf $ORACLE_HOME/oc4j/.patch_storage
