#!/bin/sh
#
#   File:      updateImage.sh
#   Created:   11-Jan-2021 00:00:00
#   Creator:   cle 
#   $Revision: $
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2021 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#
#      See zusage() 
#
# DESCRIPTION:
#       Rebuilds and pushes the image almalinux:latest-8.6 and almalinux:DATE-8.6
#
#-------------------------------------------------------------------------------
#set -x   # uncomment for debugging

# Login as 'jenkins' for push access; otherwise assume we're already logged in
if [ -e /run/secrets/jenkins-nexus-password ]; then
    cat /run/secrets/jenkins-nexus-password | \
        docker login --username $(cat /run/secrets/jenkins-nexus-username) \
               --password-stdin ${DOCKER_REGISTRY}
fi

#-------------------------------------------------------------------------------
# Global Variables
#-------------------------------------------------------------------------------
DATE=`date +%Y%m%d`

REGISTRY_URL='785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/'
IMAGE_NAMES=( "${REGISTRY_URL}csg/os/almalinux" )
DOCKER_FILES=( 'Dockerfile' )
PUSH_IMAGE=( 1 )

#-------------------------------------------------------------------------------
# Usage
#-------------------------------------------------------------------------------
function zusage() {
    echo "usage: ${0}"
    echo "         [--tls|--vm73]      vm73 has rhel subscriptions."
    echo "         [--os_ver]          OS version to use (Default to 8.6)."
    echo "         [--pcs_ver]         PCS version to use (eg. 0.10.6-4.el8)."
    echo "         [--pacemaker_ver]   Pacemaker version to use (eg. 2.0.4-6.el8_3.1)."
    echo "         [--corosync_ver]    Corosync version to use (eg. 3.0.3-4.el8)."
    echo "         [--use_cache]       Use existing cache (Default no-cache)"
    echo "         [--no_push]         Do not push the image";
    exit 2
}

#-------------------------------------------------------------------------------
# Process command line
#-------------------------------------------------------------------------------
unset opt_pcs_ver
unset opt_pacemaker_ver
unset opt_corosync_ver
unset build_args
unset extra_image_details
docker_cmd="docker"
no_cache='--no-cache'
os_ver='8.6'
do_push=1

OPTIND=1      # Reset in case getopts has been used previously in the shell.
while getopts "h-:" opt; do
    if [ "$opt" = "-" ]; then
        opt="${OPTARG%%=*}"
    fi
    case "$opt" in
        tls)
            export DOCKER_HOST=tcp://`hostname`:2376
            export DOCKER_CERT_PATH=~/dock_cert/
            docker_cmd="docker --tls"
            ;;
        vm73)
            export DOCKER_HOST=tcp://brilxvm73:2376
            export DOCKER_CERT_PATH=~/dock_cert/
            docker_cmd="docker --tls"
            ;;
        os_ver)
            os_ver=${OPTARG#*=}
            if [ "${os_ver}" == 'os_ver' ]; then
                os_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        pcs_ver)
            opt_pcs_ver=${OPTARG#*=}
            if [ "${opt_pcs_ver}" == 'pcs_ver' ]; then
                opt_pcs_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            build_args="${build_args} --build-arg PCS_VER=${opt_pcs_ver}"
            ;;
        corosync_ver)
            opt_corosync_ver=${OPTARG#*=}
            if [ "${opt_corosync_ver}" == 'corosync_ver' ]; then
                opt_corosync_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            build_args="${build_args} --build-arg COROSYNC_VER=${opt_corosync_ver}"
            ;;
        pacemaker_ver)
            opt_pacemaker_ver=${OPTARG#*=}
            if [ "${opt_pacemaker_ver}" == 'pacemaker_ver' ]; then
                opt_pacemaker_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            build_args="${build_args} --build-arg PACEMAKER_VER=${opt_pacemaker_ver}"
            ;;
        use_cache)
            unset no_cache
            ;;
        no_push)
            do_push=0
            ;;
        *)  
            zusage
            ;;
    esac
done

#-------------------------------------------------------------------------------
# zcustomLabel/Tag
#   Creates a custom label/tag.
#-------------------------------------------------------------------------------
function zcustomLabel {
    local customLabel 
    if [ ! -z $opt_pcs_ver ]; then
        customLabel="PCS${opt_pcs_ver}"
    fi
    if [ ! -z ${opt_corosync_ver} ]; then
        [[ ! -z ${customLabel} ]] && customLabel="${customLabel}_"
        customLabel="${customLabel}COROSYNC${opt_corosync_ver}"
    fi
    if [ ! -z ${opt_pacemaker_ver} ]; then
        [[ ! -z ${customLabel} ]] && customLabel="${customLabel}_"
        customLabel="${customLabel}PACEMAKER${opt_pacemaker_ver}"
    fi
    echo $customLabel
}

function zcustomTag {
    local customTag=$(zcustomLabel)
    if [ ! -z $customTag ]; then
        customTag="-${customTag}"
    fi
    echo $customTag
}

#-------------------------------------------------------------------------------
# zimageNameLatest/Date
#-------------------------------------------------------------------------------

function zimageNameLatest {
    echo "${IMAGE_NAMES[$1]}:latest-${os_ver}$(zcustomTag)" 
}

function zimageNameDate {
    echo "${IMAGE_NAMES[$1]}:${DATE}-${os_ver}$(zcustomTag)"
}

#-------------------------------------------------------------------------------
# zcleanImages
#     Deletes the local images created
#-------------------------------------------------------------------------------
function zcleanImages {
    echo "### Cleaning up ###"
    if [ -z ${no_cache} ]; then
        echo "  Not cleaning up due to use-cache specified"
    else
        for (( i=0; i < ${#IMAGE_NAMES[@]}; i=i+1 )); do
            image_latest=$(zimageNameLatest $i)
            image_date=$(zimageNameDate $i)
            ${docker_cmd} rmi -f "${image_latest}" "${image_date}"
        done
    fi
    echo "### Clean up done ###"
}

#-------------------------------------------------------------------------------
# MAIN CODE
#-------------------------------------------------------------------------------

### Remove local images on script exit
trap zcleanImages EXIT

### Build and push each image, starting with the base image
for (( i=0; i < ${#IMAGE_NAMES[@]}; i=i+1 )); do
    image=${IMAGE_NAMES[$i]}
    dockerfile=${DOCKER_FILES[$i]}_${os_ver}
    image_latest=$(zimageNameLatest $i)
    image_date=$(zimageNameDate $i)
    customLabel=$(zcustomLabel)
    if [ ! -z ${customLabel} ]; then
        customLabel="--label CUSTOM=${customLabel}"
    fi

    ### Build the image
    echo "Rebuilding: ${image} using Dockerfile ${dockerfile}"
    if ! ${docker_cmd} image build ${no_cache} ${build_args} ${customLabel} -t ${image_latest} -t ${image_date} -f ${dockerfile} .; then
        echo "!!! Failed to build image '${image_latest}' using Dockerfile '${dockerfile}' !!!"
        exit 1
    fi
    echo "### Successfully built: ${image} ###"

    if [[ $do_push -eq 1 && ${PUSH_IMAGE[$i]} -eq 1 ]];then
        echo "Pushing: ${image}"
        ### Push the image under each of its tags to the registry
        push_tags=( ${image_latest} ${image_date} )
        for t in ${push_tags[@]}; do
            if ! ${docker_cmd} push ${t}; then
                echo "!!! Failed to push image '${t}' !!!"
                exit 1
            fi
            echo "### Successfully pushed: ${t} ###"
        done
    else
        echo "Skipped pushing ${image}"
    fi
done

