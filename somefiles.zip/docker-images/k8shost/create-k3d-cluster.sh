#!/bin/bash
#*********************************************************************
#        File: create-k3d-cluster.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2023 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================

#-------------------------------------------------------------------------------
# Reports usage message then exits.
#-------------------------------------------------------------------------------
function zusage() {
    echo "Usage: ${0} [--jenkins <tag>] [--testgroup <name>]"
    echo "  Creates a k3d Kubernetes cluster"
    echo ""
    echo "Options are:"
    echo "  --jenkins         The Jenkins build tag for the current job if running under Jenkins"
    echo "  --testgroup       The name of the testgroup this cluster is being created for"
    echo "  --cni             CNI to use for the cluster"
    echo "                    Supported options are flannel and calico"
    echo "  --k8s             (deprecated) The version of Kubernetes to install."
    echo "                    Will be ignored.  Use --k3s instead."
    echo "  --k3s             The version of k3s to install.  This must match the tag"
    echo "                    of a k3s image available from https://hub.docker.com/r/rancher/k3s/tags"
    echo "                    Defaults to v1.27.7-k3s2."
    echo "  --servers         Number of servers to run (control plane nodes)"
    echo "                    Defaults to 1"
    exit 2
}

unset opt_jenkins
unset opt_testgroup
unset opt_k8s
unset opt_k3s
unset opt_servers
unset opt_cni

OPTIND=1      # Reset in case getopts has been used previously in the shell.
while getopts "h-:" opt; do
    if [ "$opt" = "-" ]; then
        opt="${OPTARG%%=*}"
    fi
    case "$opt" in
        jenkins)
            opt_jenkins=${OPTARG#*=}
            if [ "${opt_jenkins}" == 'jenkins' ]; then
                opt_jenkins="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        testgroup)
            opt_testgroup=${OPTARG#*=}
            if [ "${opt_testgroup}" == 'testgroup' ]; then
                opt_testgroup="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        cni)
            opt_cni=${OPTARG#*=}
            if [ "${opt_cni}" == 'cni' ]; then
                opt_cni="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        k8s)
            opt_k8s=${OPTARG#*=}
            if [ "${opt_k8s}" == 'k8s' ]; then
                opt_k8s="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        k3s)
            opt_k3s=${OPTARG#*=}
            if [ "${opt_k3s}" == 'k3s' ]; then
                opt_k3s="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        servers)
            opt_servers=${OPTARG#*=}
            if [ "${opt_servers}" == 'servers' ]; then
                opt_servers="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        *)
            zusage
            ;;
    esac
done

ECR_URL=785148479268.dkr.ecr.ap-southeast-2.amazonaws.com
LOCAL_REGISTRY_SHORT_NAME=registry.localhost
LOCAL_REGISTRY_NAME=k3d-${LOCAL_REGISTRY_SHORT_NAME}
LOCAL_REGISTRY_PORT=5000
LOCAL_REGISTRY_URL=${LOCAL_REGISTRY_NAME}:${LOCAL_REGISTRY_PORT}

function check_path {
    builtin type -P "$1" &> /dev/null
}

# Copy an image from ECR to the local registry
function copy_image {
    echo "### Check if image has already been synced to ECR"
    docker manifest inspect ${ECR_URL}/${1} >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        # Use skopeo to sync image to ECR
        echo "### $1 not found in ECR - copying from public registry"
        skopeo copy docker://${1} docker://${ECR_URL}/${1}
        if [ $? -ne 0 ]; then
            echo "*** Error: Failed to copy $1 to ECR"
            echo "Please make sure the supplied k3s version is valid."
            exit 1
        fi
    fi

    echo "### Copying $1 to local registry"
    skopeo copy docker://${ECR_URL}/${1} docker://${LOCAL_REGISTRY_URL}/${1}
}

# Check prerequisites
# 1. Docker
if ! check_path docker; then
    echo "docker not found in path"
    exit 1
fi

# 2. kubectl
if ! check_path kubectl; then
    echo "kubectl not found in path"
    exit 1
fi

# 3. k3d
if ! check_path k3d; then
    echo "k3d not found in path"
    exit 1
fi

# If k8s argument is passed in, tell user that is has been deprecated and is being ignored.
if [ ! -z ${opt_k8s} ]; then
    echo "WARNING: The --k8s argument is deprecated and is being ignored.  Use --k3s instead."
fi

# Default number of servers
if [ -z ${opt_servers} ]; then
    opt_servers=1
fi

# Default the Kubernetes version to 1.27.7-k3s2
if [ -z ${opt_k3s} ]; then
    opt_k3s="v1.27.7-k3s2"
fi

# Default CNI to calico, and verify that either flannel or calico was specified
if [ -z ${opt_cni} ]; then
    opt_cni="calico"
elif [ ${opt_cni} != "calico" ] && [ ${opt_cni} != "flannel" ]; then
    echo "This script does not support installing CNI ${opt_cni}"
    exit 1
fi

echo "Installing cluster..."
echo "  k3s image: ${opt_k3s}"
echo "  Number of nodes: ${opt_servers}"
echo "  Container network interface: ${opt_cni}"

if [ -z ${CLUSTER_NAME} ]; then
    CLUSTER_NAME=sv
fi

echo "#### Create local registry"
# Check if registry exists
k3d registry list ${LOCAL_REGISTRY_NAME} >/dev/null 2>&1
if [ $? -eq 1 ];then
    # Registry does not exist
    docker pull ${ECR_URL}/registry:2
    k3d registry create ${LOCAL_REGISTRY_SHORT_NAME} \
        --image ${ECR_URL}/registry:2 \
        --port ${LOCAL_REGISTRY_PORT}
    if [ $? -ne 0 ]; then
        exit 1
    fi
else
    echo "k3d registry ${LOCAL_REGISTRY_NAME} already exists - not creating a new registry"
fi

# Check if cluster already exists
k3d cluster get ${CLUSTER_NAME} >/dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "k3d cluster ${CLUSTER_NAME} already exists - not creating a new cluster"
    echo "Setting up kubeconfig for existing cluster"
    k3d kubeconfig merge -d ${CLUSTER_NAME}

    exit 0
fi

echo "### Copying images to local registry"
K3S_NODE_IMAGE=rancher/k3s:${opt_k3s}
copy_image ${K3S_NODE_IMAGE}
# Every k3s version requires very specific versions of a number of container images.
# The list of dependencies is published on GitHub, against the specific k3s tag.
# Here we retrieve the list of dependencies for the version of k3s we are using, and
# copy them to the local registry.
K3S_GITHUB_TAG=$(echo ${opt_k3s} | tr "-" "+")
for img in $(curl -s "https://raw.githubusercontent.com/k3s-io/k3s/${K3S_GITHUB_TAG}/scripts/airgap/image-list.txt" | sed 's#docker.io/##g'); do
    copy_image ${img}
done

# images for /etc/calico.yaml
copy_image quay/calico/cni:v3.15.0
copy_image quay/calico/pod2daemon-flexvol:v3.15.0
copy_image quay/calico/node:v3.15.0
copy_image quay/calico/kube-controllers:v3.15.0
# others
copy_image nats:2.8.2-alpine
copy_image grafana/promtail:main

# Get external IP address of host so we can configure k3s to accept API calls from
# clients outside the host
IP_ADDR=$(/sbin/ip -o -4 addr list eth0 | awk '{print $4}' | cut -d/ -f1)

echo "### Creating k3d cluster"
# Determine args, beyond cluster name, for the 'k3d cluster create' call
# Notes:
#  - net.ipv4.ip_forward sysctl is required for load balancer services
#  - tls-san is used to configure the API server certificates to allow kubectl to connect via the
#      external IP address (e.g. connecting from Windows PC to cluster via EC2 IP address)
#  - Ports are exposed to allow developers to connect to services running in the cluster from their PCs.
#      However, doing so means multiple CT jobs cannot run on the same host as the ports will clash.
#      The following ports are exposed:
#      > 80: All incoming HTTP traffic, i.e. PE Web, BAS, TRESOAP, TREREST, PEREST, etc
#      > 443: All incoming HTTPS traffic
#      > 2022: sftp (can't use port 22 as the host machine is probably already running ssh)
#      > 4222: NATS
#      > 6000-6004: Ports for services with type LoadBalancer
#      > 7001-7003: WSL & WSH
#      > 7015: THP
#  - Container log max size is increased so kubectl can show the complete Singleview initialisation logs of
#      the primary instance
K3D_CREATE_ARGS="--image ${LOCAL_REGISTRY_URL}/${K3S_NODE_IMAGE} \
                 --servers ${opt_servers}\
                 --timeout 5m \
                 --registry-use ${LOCAL_REGISTRY_URL} \
                 --k3s-arg '--tls-san="${IP_ADDR}"@server:*' \
                 --k3s-arg '--disable=traefik@server:*' \
                 --k3s-arg '--kubelet-arg=allowed-unsafe-sysctls=net.ipv4.ip_forward,net.ipv4.tcp_keepalive_time,net.ipv4.tcp_keepalive_probes,net.ipv4.tcp_keepalive_intvl,kernel.sem,kernel.msgmnb@all:*' \
                 --k3s-arg '--kubelet-arg=container-log-max-size=30Mi@all:*' \
                 --k3s-arg '--kubelet-arg=container-log-max-files=3@all:*' \
                 --k3s-arg '--system-default-registry=${LOCAL_REGISTRY_URL}@server:*' \
                 --volume k3d-${CLUSTER_NAME}-persistence:/var/lib/rancher/k3s/storage@all \
                 --port 80:80/tcp@loadbalancer \
                 --port 443:443/tcp@loadbalancer \
                 --port 2022:2022/tcp@servers:0:direct \
                 --port 4222:4222/tcp@servers:0:direct \
                 --port 6000:6000/tcp@servers:0:direct --port 6001:6001/tcp@servers:0:direct --port 6002:6002/tcp@servers:0:direct --port 6003:6003/tcp@servers:0:direct --port 6004:6004/tcp@servers:0:direct \
                 --port 7001:7001/tcp@servers:0:direct --port 7002:7002/tcp@servers:0:direct --port 7003:7003/tcp@servers:0:direct \
                 --port 7015:7015/tcp@servers:0:direct"

# If we are running in a container group, mount the main data volume on the k3d nodes
if [ ! -z ${CONTAINER_GROUP_INSTANCE_NAME} ]; then
    K3D_CREATE_ARGS+=" --volume ${CONTAINER_GROUP_INSTANCE_NAME}_${CONTAINER_GROUP_INSTANCE_NAME}:/k8sdev"
fi

# If we are installing Calico, do not install Flannel as part of the k3d cluster creation.
# By setting flannel-backend to none, flannel will not be installed
if [ ${opt_cni} == "calico" ]; then
    K3D_CREATE_ARGS+=" --k3s-arg '--flannel-backend=none@server:*'"
fi

# Create the cluster
K3D_CREATE_CMD="k3d cluster create ${CLUSTER_NAME} ${K3D_CREATE_ARGS}"
echo ${K3D_CREATE_CMD}
K3D_FIX_DNS=1 eval ${K3D_CREATE_CMD}
if [ $? -ne 0 ]; then
    echo "*** Error: Failed to create the cluster!  Retrying one more time."
    echo "Deleting broken cluster"
    k3d cluster delete ${CLUSTER_NAME}

    echo "Try to create cluster again..."
    K3D_FIX_DNS=1 eval ${K3D_CREATE_CMD}
    if [ $? -ne 0 ]; then
        echo "*** Error: Failed to create the cluster!  Giving up"
        exit 1
    fi
fi

if [ ${opt_cni} == "calico" ]; then
    echo
    echo "### Installing Calico"
    kubectl apply -f /etc/calico.yaml

    echo
    echo "### Waiting for Calico controllers to be Ready"
    kubectl rollout status deployment/calico-kube-controllers -n kube-system --timeout 3m
fi

echo
echo "### Registering Helm repositories"
helm repo add nats https://nats-io.github.io/k8s/helm/charts/ --force-update
helm repo add mittwald https://helm.mittwald.de --force-update
helm repo add jetstack https://charts.jetstack.io --force-update
helm repo add linkerd https://helm.linkerd.io/stable --force-update
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx --force-update
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts

echo
echo "### Installing Kubernetes secret generator"
helm install kubernetes-secret-generator mittwald/kubernetes-secret-generator

echo
echo "### Installing nginx ingress controller"
helm install ingress-nginx ingress-nginx/ingress-nginx --namespace ingress-nginx --create-namespace --values /etc/ingress-nginx.yaml
if [ $? -ne 0 ]; then
    echo "*** Error: Failed to install the nginx ingress controller!"
    exit 1
fi

echo
echo "### Installing cert-manager"
helm install cert-manager jetstack/cert-manager --namespace cert-manager --create-namespace --version v1.8.0 --set installCRDs=true --wait
if [ $? -ne 0 ]; then
    echo "*** Error: Failed to install cert-manager!"
    exit 1
fi

echo
echo "### Installing Prometheus and Grafana"
helm install prometheus prometheus-community/kube-prometheus-stack --namespace monitoring --create-namespace --values=/etc/prometheus-values.yaml --wait
if [ $? -ne 0 ]; then
    echo "*** Error: Failed to install Prometheus and Grafana!"
    # Show pods and events in the monitoring namespace
    kubectl get -n monitoring pods,events
    exit 1
fi

# If the "jenkins" parameter was supplied on the command line, we assume it's because we
# want to stream all container logs to Loki.
# To do this, we install Promtail
if [ ! -z $opt_jenkins ]; then
    echo
    echo "### Installing promtail"
    kubectl create namespace monitoring

    # Configure options
    INSTALL_OPTS="--set config.clients[0].url=http://loki.csgisvrndct.com/loki/api/v1/push"
    INSTALL_OPTS+=" --set config.clients[0].external_labels.jenkins_job=$opt_jenkins"
    if [ ! -z $opt_testgroup ]; then
        INSTALL_OPTS+=" --set config.clients[0].external_labels.test_group=$opt_testgroup"
    fi
    helm install promtail grafana/promtail --namespace monitoring \
      -f /etc/promtail-values.yaml \
      --set image.registry=${LOCAL_REGISTRY_URL} \
      ${INSTALL_OPTS}
fi

echo
echo "### Waiting for metrics server to be Ready"
kubectl rollout status deployment/metrics-server -n kube-system --timeout 3m

echo
echo "### Waiting for core DNS to be Ready"
kubectl rollout status deployment/coredns -n kube-system --timeout 3m

echo
echo "### Waiting for local path provisioner to be Ready"
kubectl rollout status deployment/local-path-provisioner -n kube-system --timeout 3m

echo
echo
echo "### Cluster creation complete"

