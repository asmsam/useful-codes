#!/bin/bash

echo
echo "### Installing linkerd"
mkdir -p /tmp/linkerd-certs
pushd /tmp/linkerd-certs

echo "Creating certificates"
rm -f *
step certificate create root.linkerd.cluster.local ca.crt ca.key \
--profile root-ca --no-password --insecure

step certificate create identity.linkerd.cluster.local issuer.crt issuer.key \
--profile intermediate-ca --not-after 8760h --no-password --insecure \
--ca ca.crt --ca-key ca.key

helm install linkerd2 \
  --set-file identityTrustAnchorsPEM=ca.crt \
  --set-file identity.issuer.tls.crtPEM=issuer.crt \
  --set-file identity.issuer.tls.keyPEM=issuer.key \
  linkerd/linkerd2

linkerd check

# Install linkerd dashboard
helm install linkerd-viz \
  --set dashboard.enforcedHostRegexp=".*" \
  linkerd/linkerd-viz

linkerd viz check

# Expose dashboard on host
kubectl apply -f /etc/viz-ingress.yaml

popd
rm -rf /tmp/linkerd-certs
