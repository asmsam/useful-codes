#!/bin/ksh
#*********************************************************************
#        File: entrypoint.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2022 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# DESCRIPTION:
#      Entrypoint for k8shost container image.  
#
#-------------------------------------------------------------------------------*/
SLEEP_PID=

function _exit {
    # Kill sleep if its process ID is known
    if [ -n "${SLEEP_PID}" ]; then
        kill -s KILL $SLEEP_PID
    fi
}

function _int {
   echo "SIGINT received, exiting container ..."
   _exit
   exit 0
}

function _term {
    echo "SIGTERM received, exiting container ..."
    _exit
    exit 0
}

function _kill {
   echo "SIGKILL received, exiting container ..."
   _exit
   exit 0
}

# Set handlers for SIGINT, SIGTERM, and SIGKILL
trap _int INT
trap _term TERM
trap _kill KILL

# Note: - 'sleep infinity' is run in the background. This is done for signal handling.
#         If 'sleep infinity' is called directly, signals like TERM are never captured.
#       - Uses /usr/bin/sleep instead of just sleep as we don't want to use ksh's built-in sleep function
/usr/bin/sleep infinity &
SLEEP_PID=$!
wait $SLEEP_PID
