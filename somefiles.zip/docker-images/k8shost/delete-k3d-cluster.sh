#!/bin/bash

function check_path {
    builtin type -P "$1" &> /dev/null
}

# Check prerequisites
# k3d
if ! check_path k3d; then
    echo "k3d not found in path"
    exit 1
fi

if [ -z ${CLUSTER_NAME} ]; then
    CLUSTER_NAME=sv
fi

# Delete the cluster
k3d cluster delete ${CLUSTER_NAME}
k3d registry delete registry.localhost

echo
echo
echo "### Cluster deletion complete"

