#!/usr/bin/env perl

use strict;
use Getopt::Long;
use FindBin;
use lib "$FindBin::Bin/sv_test/Library/InstallUtils";
use InstallUtils;

use lib "$FindBin::Bin/sv_test/Library/Utils";
use sv_package_path qw(get_package_path);

use constant {
    # Exit Codes
    EXIT_CODE_SUCC  => 0,
    EXIT_CODE_FAIL  => 1,
    EXIT_CODE_USAGE => 2,
};


###############################################################################
# Build Confman
###############################################################################
sub install_confman
{
    InstallUtils::Log(LOG_DASHES, "Installing confman in the current environment...");
    # Source confman from the latest stable build, invoke the gradle make job to download and install it
    if (InstallUtils::ExecuteCmd("cd $ENV{ATA_HOME}/sv_test/Test_Suites; ATA_DISABLE_ATAIENV=1 " .
                                 "./gradlew :RefreshConfmanInstall --configure-on-demand --rerun-tasks")) {
        zWarn(__LINE__, "Could not install Confman. Attempting to use an existing version in the environment.");
        InstallUtils::ExecuteCmd("which confman")
            && InstallUtils::Die("Confman does not exist in the environment path and could not be installed");
    }
}

sub zUsage
{
    print q{
        Usage: prebuild.pl -usepackage <Package URL>
            usepackage option is mandatory
    }
}
my $opt_usepackage;

my $opt_sv_test_loc = "$ENV{ATA_HOME}/sv_test";

if (!GetOptions(
                "usepackage=s"  => \$opt_usepackage
                )) {
    zUsage();
    exit(EXIT_CODE_USAGE);
}

my $lsv_path;
my $lsvlib_path;
my $opt_notstcfg = 0; # default value as per st_createenv

# Turn the SV package location into a local path, if it isn't already.
#$lsv_path = get_package_path($opt_usepackage);
#if (!defined($lsv_path)) {
#    exit(EXIT_CODE_FAIL);
#}

# The same jenkins url that contains the SV package also contains svlib,
# so we can download the svlib package from there
#$lsvlib_path = get_package_path($opt_usepackage, undef, 1);

# Validate that the svlib path is now set
#if (!defined($lsvlib_path)) {
#    exit(EXIT_CODE_FAIL);
#}

# prepare_environment();
#
my $s3Branch = $ENV{CBSVNBRANCH};
$s3Branch =~ s/\//-/g;
#my $s3Folder = $s3Branch . "-cb".$ENV{SVNCBREV}."-pe".$ENV{SVNPEREV}."-web".$ENV{SVNWEBREV};
my $s3Folder;
if($ENV{PACKAGE_S3_FOLDER}) {
    $s3Folder = $ENV{PACKAGE_S3_FOLDER};
    print "Using provided S3 folder $s3Folder to retrieve package\n";
} else {
    die "PACKAGE_S3_FOLDER must be set";
}
#system("aws s3 sync $s3Path .");
system("wget -q https://csgibri-svrndct-packages.s3-ap-southeast-2.amazonaws.com/sv/$s3Folder/file.list") && die "Cannot download file.list from https://csgibri-svrndct-packages.s3-ap-southeast-2.amazonaws.com/sv/$s3Folder/\n";
open FL, "file.list";
while(<FL>) {
    chomp;
    print "Downloading $_";
    system "wget -q https://csgibri-svrndct-packages.s3-ap-southeast-2.amazonaws.com/sv/$s3Folder/$_";
    system "mv $_ /home/svdev";
}
close FL;
$lsv_path = "/home/svdev/sv_".$ENV{SVVERSION}."_linux.tar.gz";
InstallUtils::UnpackSVRelease($lsv_path, undef);
install_confman();
$lsvlib_path= "/home/svdev/svlib_".$ENV{SVVERSION}."_linux.tar.gz";
InstallUtils::UnpackSVLib($lsvlib_path);
# check_oracle;

InstallUtils::ExecuteCmd("ATA_NOTSTCFG=$opt_notstcfg ksh $opt_sv_test_loc/Library/Utils/st_createenv_pkg.sh")
    && InstallUtils::Die("SV Dev build has failed: $!");

`mkdir -p $ENV{ATA_DATA_SERVER_REPORTS}`;
`ln -s $ENV{ATA_REL_SERVER_CONFIG}/mibs $ENV{ATA_DATA_SERVER_CONFIG}/mibs`;
`cp -f $ENV{ATA_REL_SERVER_CONFIG}/ubbconfig.tpl $ENV{ATA_DATA_SERVER_CONFIG}`;
`cp -f $ENV{ATA_REL_SERVER_CONFIG}/f_xsi.dat $ENV{ATA_DATA_SERVER_CONFIG}`;
`cp -f $ENV{ATA_REL_SERVER_CONFIG}/envfile.tpl $ENV{ATA_DATA_SERVER_CONFIG}`;
`cp -f $ENV{ATA_REL_JAVA_CONFIG}/ejienvfile.tpl $ENV{ATA_DATA_JAVA_CONFIG}`;

# Linking and copying to allow the client to login
`ln -s $ENV{ATA_REL_CLIENT_BIN} $ENV{ATA_DATA_CLIENT}/bin`;
`ln -s $ENV{ATA_DATA_SERVER_CONFIG}/msg $ENV{ATA_DATA_CLIENT_CONFIG}/msg`;
`cp -f $ENV{ATA_REL_CLIENT_CONFIG}/wsenvfile.tpl $ENV{ATA_DATA_CLIENT_CONFIG}/wsenvfile.tpl`;
`cp -f $ENV{ATA_REL_CLIENT_CONFIG}/pe.ini $ENV{ATA_DATA_CLIENT_CONFIG}/pe.ini`;
`chmod +w $ENV{ATA_DATA_CLIENT_CONFIG}/pe.ini`;

