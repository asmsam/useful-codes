#!/bin/ksh
sudo -u sv_ora /opt/oracle/startDBrman.sh

. ./.profile
#perl ./getSVPackage.pl -usepackage $1
BRANCHDASHES=$(echo $SVNBRANCH | sed -e 's/\//-/g')
echo $BRANCHDASHES
echo "Downloading https://csgibri-svrndct-packages.s3-ap-southeast-2.amazonaws.com/sv/${BRANCHDASHES}-latest/file.list"
if [[ -z ${SVNCBREV} ]];then
    URL=https://csgibri-svrndct-packages.s3-ap-southeast-2.amazonaws.com/sv/${BRANCHDASHES}-latest
else
    URL=https://csgibri-svrndct-packages.s3-ap-southeast-2.amazonaws.com/sv/${BRANCHDASHES}-cb${SVNCBREV}-pe${SVNPEREV}-web${SVNWEBREV}
fi
wget ${URL}/file.list
wget ${URL}/package.version
    
PACKAGE_VERSION=$(head -1 package.version)
cat file.list | while read i
do
    echo "Downloading ${URL}/$i"
    rm -f $i
    wget -q ${URL}/$i
done

#rm -f $HOME/rel
cd $HOME/sv
#rm -rf 1*
tar -zxvf $HOME/sv_*tar.gz
cd $HOME
#ln -s sv/1* rel

. ./.profile

for i in \
    BillingConfiguration \
    DCEA_FUNCTION_MAPPING \
    dDiam_Request_Details \
    dDiam_Variant \
    DisplayImageMethod \
    DisplayImageType \
    DownloadDirectories \
    ENMSet \
    EntitlementCategory \
    EntityClassAssociation \
    GatewayPortMap \
    ProductOfferEntitlementCat
do
    da_dump $i -f $i.da.save
done

for i in ACCOUNT_ACTION \
    CUSTOMER_BILLING_CONFIGURATION \
    DISPLAY_IMAGE_TYPE \
    ENTITLEMENT_CATEGORY \
    FACILITY_GROUP_INSTANCE_STATUS \
    OUTPUT_IMAGE_TYPE \
    OUTPUT_TYPE \
    PRODUCT_INSTANCE_STATUS \
    SCHEDULED_FUNC_CATEGORY \
    SCHEDULED_FUNC_ENTITY \
    SCHEDULED_FUNC_SUB_CATEGORY \
    SERVICE_STATUS
do
    rt_dump $i -f $i.rt.save
done


# Diameter
rm -f $ATA_HOME/dcea/product/rel
rm -f $ATA_HOME/dceaenv
rm -f $ATA_HOME/diameter/product/rel
rm -f $ATA_HOME/diameterenv
DIAM=$(ls diam*install)
chmod +x $DIAM
./$DIAM


EPM=$(ls compile*install)
chmod +x $EPM
./$EPM

ata_load
pe_coreupgrade -u

for i in ACCOUNT_ACTION \
    CUSTOMER_BILLING_CONFIGURATION \
    DISPLAY_IMAGE_TYPE \
    ENTITLEMENT_CATEGORY \
    FACILITY_GROUP_INSTANCE_STATUS \
    OUTPUT_IMAGE_TYPE \
    OUTPUT_TYPE \
    PRODUCT_INSTANCE_STATUS \
    SCHEDULED_FUNC_CATEGORY \
    SCHEDULED_FUNC_ENTITY \
    SCHEDULED_FUNC_SUB_CATEGORY \
    SERVICE_STATUS
do
    rt_load -s $i $i.rt.save
done

for i in \
    BillingConfiguration \
    DCEA_FUNCTION_MAPPING \
    dDiam_Request_Details \
    dDiam_Variant \
    DisplayImageMethod \
    DisplayImageType \
    DownloadDirectories \
    ENMSet \
    EntitlementCategory \
    EntityClassAssociation \
    GatewayPortMap \
    ProductOfferEntitlementCat
do
    da_load -s $i.da.save $i
done

cfg CUSTOMER_CACHE 1 CUSTOMER_FIELD_NAMES -v 'ratingusage.sample.CUSTOMER_CACHE.FieldNames$[]()'
# The function that defines the field names is overwritten by ata_load
archive -d -f ent_cache_fields.archive -x -r 2 -o

sqlplus $ATADBACONNECT <<EOF
insert into function_role_map select 1,FUNCTION_DEFN_ID,FUNCTION_DEFN_ID from function_defn_history fdh where function_defn_name like 'TrerestApi%' and not exists (select 1 from function_role_map where function_defn_id = fdh.function_defn_id);
commit;
quit;
EOF

msg_create

sv_stop -k -k
sudo -u sv_ora /opt/oracle/stopDBrman.sh

rm -f $HOME/sv_*tar.gz
rm -f $HOME/svlib*tar.gz
rm -f $HOME/diam*install
rm -f $HOME/compile*install

echo PACKAGE_VERSION=$PACKAGE_VERSION
