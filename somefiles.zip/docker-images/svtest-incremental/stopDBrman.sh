#!/bin/ksh
PATH=/usr/local/bin:$PATH
ORAENV_ASK=NO
ORACLE_SID=SVDEV
. oraenv

cd /opt/oracle
rman target=/ @incr_l1_and_stop.rman && \
rm -f /opt/oracle/oradata/SVDEV/*dbf /opt/oracle/oradata/SVDEV/redo* /opt/oracle/product/12.1.0.2/rdbms/audit/* /opt/oracle/diag/rdbms/svdev/SVDEV/trace/*
