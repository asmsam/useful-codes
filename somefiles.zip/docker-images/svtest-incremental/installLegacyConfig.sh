#!/bin/ksh

. ./.profile

echo "Start the database and listener"
ssh sv_ora@`hostname` "export ORACLE_SID=$ORACLE_SID;\
    export ORACLE_HOME=$ORACLE_HOME;\
    export PATH=$ORACLE_HOME/bin:$PATH;\
    lsnrctl start $ORACLE_SID;\
    echo \"startup\"|sqlplus / as sysdba";

sv_start

cd $ATA_HOME/sv_test/Library/Configuration/cb/BaseConfig
./install.sh
exit $?