#!/bin/ksh

START=$1
END=$2
LOGFILE=$3

if [ -z $START ] || [ -z $END ] || [ -z $LOGFILE ]; then
    echo 'All options are mandatory'
    echo 'Usage : '
    echo 'runStCreateEnv.sh <start_step> <end_step> <logFile_name>'
    exit 2
fi
sudo -u sv_ora /opt/oracle/startDBrman.sh

# Retain the ubbconfig file while building steps 11 to 25
if [ $START -eq "11" ] && [ $END -eq "25" ]; then
    OPTS=" -keepubb "
    if ! sv_start ; then # need SV running to start from step 11
        . $HOME/.profile 
        sv_start
    fi
fi

# Hack to workaround a problem with using local path for package url
# Code uses dirname on the path when trying to find diameter package
# and therefore ends up looking in parent dir
sudo cp /home/svdev/diameter*install /home
. $HOME/.profile; cd $HOME/sv_test/Library/Utils; \
cd $HOME/sv_test/Library/Utils
perl st_createenv.pl ${OPTS} -norman -usepackage ${PACKAGE_BUILD_URL} -nosvnupdate -installdcea -s ${START} -e ${END} -log ${LOGFILE}

sv_stop -k -k
sudo -u sv_ora /opt/oracle/stopDBrman.sh

if [ $END -eq "25" ]; then
    # Need to cache gradle dependencies before pushing image to AWS
    cd $HOME/sv_test/Test_Suites
    gradlew dependencies
    RC=${?}

    if [ ${RC} -ne 0 ];then
        echo "Failed to cache gradle dependencies RC=${RC} "
        exit ${RC}
    fi

    # Run the ProcessEngineSanity checkstyle test to save checkstyle dependencies
    gradlew :ProcessEngineSanity:checkstyleTest
    RC=${?}

    if [ ${RC} -ne 0 ];then
        echo "Failed to cache checkstyle dependencies RC=${RC} "
        exit ${RC}
    fi

fi
cd $HOME/sv_test
export SVNSTREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')
cd $HOME/cb
export SVNCBREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')
cd $HOME/pe
export SVNPEREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')
cd $HOME/webgui
export SVNWEBREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')

echo SVNSTREV=$SVNSTREV
echo SVNCBREV=$SVNCBREV
echo SVNPEREV=$SVNPEREV
echo SVNWEBREV=$SVNWEBREV
echo "IMAGENAME=$(echo $STSVNBRANCH |sed -e 's/\//-/g')-st$SVNSTREV-cb$SVNCBREV-pe$SVNPEREV-web$SVNWEBREV"
