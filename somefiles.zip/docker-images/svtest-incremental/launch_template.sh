#!/bin/bash

set -x
exec > >(tee /var/log/user-data.log|logger -t user-data ) 2>&1

systemctl disable iptables
systemctl stop iptables

#install aws-cli, docker and other related tools
yum -y install wget
wget https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum -y install epel-release-latest-7.noarch.rpm
yum -y install dstat perl lvm2 pigz docker-engine unzip
curl -L https://github.com/docker/compose/releases/download/1.19.0/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose && chmod +x /usr/local/bin/docker-compose

curl "https://s3.amazonaws.com/aws-cli/awscli-bundle.zip" -o "awscli-bundle.zip"
unzip awscli-bundle.zip
sudo ./awscli-bundle/install -i /usr/local/aws -b /usr/local/bin/aws

service docker stop
yum install -y nvme-cli
for i in /dev/nvme*n1
do
    nvme id-ctrl -v $i 2>&1|grep -q "Instance Storage" && nvmedev=${i} && echo "Using instance store" && break
done
if [[ -z ${nvmedev} ]];then
    for i in /dev/nvme*n1
    do
        nvme id-ctrl -v $i 2>&1|grep -q "xvdb" && nvmedev=${i} && echo "Using EBS" && break
    done
fi
if [[ -z ${nvmedev} ]];then
    echo "Failed to find instance store or EBS volume at xvdb"
    exit 1
fi
fdisk ${nvmedev} <<EOF
d

n



+44G
n



+25G
w
EOF
sleep 2
mkdir -p /etc/docker
touch /etc/docker/daemon.json
cat >/etc/docker/daemon.json  <<EOF
{
  "hosts": ["tcp://0.0.0.0:2376"],
  "storage-driver": "devicemapper",
  "storage-opts": [
    "dm.directlvm_device=${nvmedev}p1",
    "dm.thinp_percent=95",
    "dm.thinp_metapercent=1",
    "dm.thinp_autoextend_threshold=80",
    "dm.thinp_autoextend_percent=20",
    "dm.directlvm_device_force=false",
    "dm.basesize=60G",
    "dm.directlvm_device_force=true"
  ]
}
EOF

cat >/tmp/monitor_instance_termination.sh  <<EOF
#!/bin/bash
export DOCKER_HOST=tcp://\`curl http://169.254.169.254/latest/meta-data/local-ipv4\`:2376
while curl -s http://169.254.169.254/latest/meta-data/spot/termination-time|grep -q "404 - Not Found"
do
    sleep 5
done
echo \`date\` \`hostname\` " is being terminated, killing docker containers and jenkins processes" >> /efs/ct/log/instance_monitor.log
# Set the jenkins node offline to prevent jobs executing on it
echo \`date\` \`hostname\` ": Setting the node offline first" >> /efs/ct/log/instance_monitor.log
curl -X POST http://10.61.1.76:8080/jenkins/job/SetNodeTemporarilyOffline/buildWithParameters?NODE_IP=\`curl http://169.254.169.254/latest/meta-data/local-ipv4\`
# Terminate any running containers
for i in \`docker ps --format '{{.Names}}' | grep -v jenkins |awk '{print \$1}'\`
do
    echo \`date\` \`hostname\` ": killing \${i}" >> /efs/ct/log/instance_monitor.log
    if docker kill \${i} >/dev/null; then
      echo \`date\` \`hostname\` ": Successfully killed \$i" >> /efs/ct/log/instance_monitor.log
    else
      echo \`date\` \`hostname\` ": Failed to kill \$i" >> /efs/ct/log/instance_monitor.log
    fi
done
# Keep killing script processes created by jenkins by checking every second
while true
do
  sleep 1
  if pgrep script.sh -c >/dev/null ; then
      echo \`date\` \`hostname\` ": Killing jenkins script processes" >> /efs/ct/log/instance_monitor.log
      kill \$(pgrep script.sh)
  fi
done
EOF

chmod +x /tmp/monitor_instance_termination.sh

mkfs.xfs ${nvmedev}p2
sleep 2
mkdir -p /var/lib/docker
mount ${nvmedev}p2 /var/lib/docker
sleep 2
service docker start
mkdir /efs
yum install -y nfs-utils
cat >> /etc/fstab <<EOF
fs-66e8705f.efs.ap-southeast-2.amazonaws.com:/  /efs nfs4  nfsvers=4.1,rsize=1048576,wsize=1048576,hard,timeo=600,retrans=2 0 0
EOF
mount -a
export DOCKER_HOST=tcp://`hostname`:2376
`aws ecr get-login --no-include-email --region ap-southeast-2`
timedatectl set-timezone Australia/Brisbane
nohup /tmp/monitor_instance_termination.sh > /tmp/instance_terminate.log 2>&1 &
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region|awk -F\" '{print $4}')
JENKINS_URL=$(aws ssm get-parameter --name /ct/jenkins/url --region $REGION --query 'Parameter.Value' --output text)
JENKINS_USER=$(aws ssm get-parameter --name /ct/jenkins/username --region $REGION --query 'Parameter.Value' --output text)
JENKINS_PASS=$(aws ssm get-parameter --name /ct/jenkins/password --with-decryption --region $REGION --query 'Parameter.Value' --output text)
LABELS=`aws ec2 describe-tags --region $REGION --filter "Name=resource-id,Values=\`curl http://169.254.169.254/latest/meta-data/instance-id\`" --output=text | grep Name|awk '{print $5 " " $3}'`
IMAGE_TO_PULL=`aws ec2 describe-tags --region $REGION --filter "Name=resource-id,Values=\`curl http://169.254.169.254/latest/meta-data/instance-id\`" --output=text | grep ImageToPull|awk '{print $5}'`
docker pull $IMAGE_TO_PULL
docker run -h `hostname` -d --name jenkins-slave --restart=unless-stopped -v /var/run/docker.sock:/var/run/docker.sock -e JENKINS_URL=$JENKINS_URL -e JENKINS_USER=$JENKINS_USER -e JENKINS_PASS=$JENKINS_PASS -e SLAVE_LABELS="${LABELS}" 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/ct/jenkins/jenkins-agent-aws
