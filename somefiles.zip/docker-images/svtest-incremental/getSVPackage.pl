#!/usr/bin/env perl

use strict;
use Getopt::Long;
use FindBin;
use lib "$FindBin::Bin/sv_test/Library/InstallUtils";
use InstallUtils;

use lib "$FindBin::Bin/sv_test/Library/Utils";
use sv_package_path qw(get_package_path);

use constant {
    # Exit Codes
    EXIT_CODE_SUCC  => 0,
    EXIT_CODE_FAIL  => 1,
    EXIT_CODE_USAGE => 2,
};


sub zUsage
{
    print q{
        Usage: getSVPackage.pl -usepackage <Package URL>
            usepackage option is mandatory
    }
}
my $opt_usepackage;

my $opt_sv_test_loc = "$ENV{ATA_HOME}/sv_test";

if (!GetOptions(
                "usepackage=s"  => \$opt_usepackage
                )) {
    zUsage();
    exit(EXIT_CODE_USAGE);
}

my $lsv_path;
my $lsvlib_path;
my $opt_notstcfg = 0; # default value as per st_createenv

# Turn the SV package location into a local path, if it isn't already.
$lsv_path = get_package_path($opt_usepackage);
if (!defined($lsv_path)) {
    exit(EXIT_CODE_FAIL);
}

# The same jenkins url that contains the SV package also contains svlib,
# so we can download the svlib package from there
$lsvlib_path = get_package_path($opt_usepackage, undef, 1);

# Validate that the svlib path is now set
if (!defined($lsvlib_path)) {
    exit(EXIT_CODE_FAIL);
}

# prepare_environment();
InstallUtils::UnpackSVRelease($lsv_path, undef);
InstallUtils::UnpackSVLib($lsvlib_path);
