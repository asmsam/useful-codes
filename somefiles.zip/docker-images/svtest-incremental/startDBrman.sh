#!/bin/ksh
PATH=/usr/local/bin:$PATH
ORAENV_ASK=NO
ORACLE_SID=SVDEV
. oraenv

cd /opt/oracle
lsnrctl start && \
rman target=/ @restore.rman && \
sqlplus / as sysdba @recover.sql

