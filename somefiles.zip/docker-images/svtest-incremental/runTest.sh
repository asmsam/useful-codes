#!/bin/ksh

. ./.profile

# For incremental builds we always start the db here, using rman backups
sudo -u sv_ora /opt/oracle/startDBrman.sh

# Start SingleView
sv_start

# Start greenmail
runGreenMail -start

if [[ ${LEGACY_CONFIG} ]]; then
    echo "Installing Legacy configuration"
    cd ${ATA_HOME}/sv_test/Library/Configuration/cb/BaseConfig
    ./install.sh
fi

# Change directory to the test module
cd ${ATA_HOME}/sv_test/Test_Suites/${TEST_GROUP}

# Run tests appropriately
if [[ ${TEST_GROUP} == "Confman" ]]; then
    ./run_confman_tests.sh
elif [[ ${TEST_GROUP} == "BAS" ]] || [[ ${TEST_GROUP} == "Trerest" ]]; then
    make regress
elif [[ ${TEST_GROUP} == "BatchLoader" ]]; then
    ./Run_BatchLoad.sh 10 12 5
elif [[ ${TEST_GROUP} == "BatchExtractor" ]]; then
    ./Run_BatchExtract.sh 8 12
elif [[ ${TEST_GROUP} == "EventProcessing" ]]; then
    ./run_event_processing.sh
elif [[ ${TEST_GROUP} == "Reservation" ]]; then
    ./run_Reservation_tests.sh
elif [[ ${TEST_GROUP} == "NonDBMode" ]]; then
    ./run_Non_DB_mode_tests.sh
elif [[ ${TEST_GROUP} == "Entitlements" ]]; then
    ./run_entitlements_tests.sh
elif [[ ${TEST_GROUP} == "ProductOffers" ]]; then
    ./run_product_offers_tests.sh
elif [[ ${TEST_GROUP} == "PurgingWithoutPartitioning" ]]; then
    ./Run_PWP.sh
else
    gradle --offline test
fi
