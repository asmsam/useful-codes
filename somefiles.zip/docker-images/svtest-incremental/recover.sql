-- Assumes rman has been run to restore and recover database
-- This file is required to open the db when the online redo logs are not present
recover database until cancel
alter database open resetlogs;
quit;

