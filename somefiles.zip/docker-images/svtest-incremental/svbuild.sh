#!/bin/ksh

## Check if environment variables for SVN branches are set, default to trunk if not
if [ -z "$CBSVNBRANCH" ]; then
    echo "CB branch not specified, defaulting to trunk"
    export CBSVNBRANCH=trunk
fi
if [ -z "$PESVNBRANCH" ]; then
    echo "PE branch not specified, defaulting to trunk"
    export PESVNBRANCH=trunk
fi
if [ -z "$STSVNBRANCH" ]; then
    echo "ST branch not specified, defaulting to trunk"
    export STSVNBRANCH=trunk
fi
if [ -z "$PEWEBSVNBRANCH" ]; then
    echo "Peweb branch not specified, defaulting to trunk"
    export PEWEBSVNBRANCH=trunk
fi

## Check if sv_app version number is defined, if not derive it
if [ -z "$SVAPP_VERSION" ]; then
    echo "Deriving sv_app version number"
    SVAPP_VERSION=`echo $SV_VERSION  | awk -F"." '{print $1"."$2}'`
fi
echo "SVAPP_VERSION=$SVAPP_VERSION"

## Getting directory for parallel command
SVAPP_HOME=`grep app /etc/passwd | grep -v ora | grep -v snapp | awk -F":" '{print $6}'`
echo "SVAPP_HOME=$SVAPP_HOME"

## Check if ata_os is defined, if not derive it
if [ -z "$ATA_OS" ]; then
    echo "Deriving unix OS"
    ATA_OS=`uname | sed 's/^IRIX.*$/IRIX/'`
fi
echo "ATA_OS=$ATA_OS"

## Check if tpsdir is defined, if not derive it
if [ -z "$TPSDIR" ]; then
    echo "Deriving third party apps location"
    if [ $ATA_OS = "Linux" ]; then
        TPSDIR=$SVAPP_HOME/$SVAPP_VERSION
    else
        TPSDIR=$SVAPP_HOME
    fi
fi
echo "TPSDIR=$TPSDIR"

## Check if environment variables for revision numbers are set, default to head if not
if [ -z "$SVNCBREV" ]; then
    echo "CB revision not specified, defaulting to latest"
    SVNCBREV=HEAD
fi

if [ -z "$SVNPEREV" ]; then
    echo "PE revision not specified, defaulting to latest"
    SVNPEREV=HEAD
fi

if [ -z "$SVNSTREV" ]; then
    echo "ST revision not specified, defaulting to latest"
    SVNSTREV=HEAD
fi
if [ -z "$SVNWEBREV" ]; then
    echo "Peweb revision not specified, defaulting to latest"
    SVNWEBREV=HEAD
fi

cd $HOME
if [ "$1" != "keep_source" ] || [ ! -d $HOME/cb ]; then \
    echo "Checking out CB branch $CBSVNBRANCH at revision $SVNCBREV"
    sudo rm -rf cb/* cb/.svn
    sudo chown svdev:svdev cb
    REVISIONS="${REVISIONS} ${SVNCBREV}"
    PATHS="${PATHS} ${CBSVNROOT}/${CBSVNBRANCH}"
    DIRECTORIES="${DIRECTORIES} cb"
fi

if [ "$1" != "keep_source" ] || [ ! -d $ATA_HOME/pe ]; then
    echo "Checking out PE branch $PESVNBRANCH at revision $SVNPEREV"
    sudo rm -rf pe/* pe/.svn
    sudo chown svdev:svdev pe
    REVISIONS="${REVISIONS} ${SVNPEREV}"
    PATHS="${PATHS} ${PESVNROOT}/${PESVNBRANCH}/pe"
    DIRECTORIES="${DIRECTORIES} pe"
fi

if [ "$1" != "keep_source" ] || [ ! -d $ATA_HOME/sv_test ]; then
    echo "Checking out sv_test branch $STSVNBRANCH at revision $SVNSTREV"
    rm -rf sv_test sv_test/.svn
    REVISIONS="${REVISIONS} ${SVNSTREV}"
    PATHS="${PATHS} ${STSVNROOT}/${STSVNBRANCH}"
    DIRECTORIES="${DIRECTORIES} sv_test"
fi

if [ "$1" != "keep_source" ] || [ ! -d $ATA_HOME/webgui ]; then
    echo "Checking out PE WEB branch $PEWEBSVNBRANCH at revision $SVNWEBREV"
    sudo rm -rf webgui/* webgui/.svn
    sudo chown svdev:svdev webgui
    REVISIONS="${REVISIONS} ${SVNWEBREV}"
    PATHS="${PATHS} ${WEBSVNROOT}/${PEWEBSVNBRANCH}"
    DIRECTORIES="${DIRECTORIES} webgui"
fi

## Check out all the repos in parallel
if [ ! -z "$DIRECTORIES" ]; then
    echo "Running svn checkout"
    echo "$TPSDIR/tools/bin/parallel --xapply --willcite $TPSDIR/svn/rel/bin/svn co -q -r ::: $REVISIONS ::: $PATHS ::: $DIRECTORIES"
    $TPSDIR/tools/bin/parallel --xapply --willcite $TPSDIR/svn/rel/bin/svn co -q -r ::: $REVISIONS ::: $PATHS ::: $DIRECTORIES
    EXIT_CODE="$?"
    if [ $EXIT_CODE != "0" ]; then
        echo "Checkout failed!"
        exit $EXIT_CODE
    fi
    echo "Checkout finished"
else
    echo "Using existing source, no checkout performed"
fi
cd $HOME/cb
export SVNCBREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')
cd $HOME/pe
export SVNPEREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')
cd $HOME/webgui
export SVNWEBREV=$($TPSDIR/svn/rel/bin/svn info|grep "Last Changed Rev:"|awk '{print $4}')
cd $HOME

export SVVERSION=$(cat cb/server/include/version.h |grep ATLANTA_VERSION|sed -e 's/#define\s*ATLANTA_VERSION\s*//'|sed -e 's/[\"\(\)]//g')
env

echo "Bootstrapping the env to generate .profile and stenv links at $HOME"
cd $HOME/sv_test
make bootstrap

echo "Start the database and listener, making a level0 incremental backup as well"
ssh sv_ora@`hostname` "export ORACLE_SID=$ORACLE_SID;\
    export ORACLE_HOME=$ORACLE_HOME;\
    export PATH=$ORACLE_HOME/bin:$PATH;\
    lsnrctl start $ORACLE_SID;\
    rman target=/ @/opt/oracle/incr_l0.rman";

echo "Change to database password"
sqlplus system/atlanta <<EOF
  alter user system identified by manager;
  alter user sys identified by manager;
EOF

echo "Running the profile"
. $HOME/.profile

RC=1
perl $HOME/prebuild.pl -usepackage ${PACKAGE_BUILD_URL}
RC=${?}

if [ ${RC} -ne 0 ];then
    echo "Failed to build SingleView. RC=${?}  "
    exit ${RC}
fi

echo "Stop the database and do incremental backup"
sudo -u sv_ora /opt/oracle/stopDBrman.sh

# Remove sv and svlib tarballs
echo "Remove SV package tarballs"
cd $HOME
rm -f sv/sv*tar.gz
rm -f sv*tar.gz
env|grep ^SVN|grep REV=
env|grep SVNBRANCH=
env|grep SVVERSION
echo "IMAGENAME=$(echo $CBSVNBRANCH |sed -e 's/\//-/g')-cb$SVNCBREV-pe$SVNPEREV-web$SVNWEBREV"
