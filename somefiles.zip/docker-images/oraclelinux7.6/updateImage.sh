#!/bin/sh
#
#   File:      updateImage.sh
#   Created:   18-Jun-2018 14:26:59
#   Creator:   perkar02
#   $Revision: $
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2018 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#
#      ./updateImage.sh [--tls|--vm73] [--use_cache] [--no_push]
#
# DESCRIPTION:
#       Rebuilds and pushes the images oraclelinux:latest-7.6
#       and oraclelinux:DATE-7-6
#

#-------------------------------------------------------------------------------
#set -x   # uncomment for debugging

# Login as 'jenkins' for push access; otherwise assume we're already logged in
if [ -e /run/secrets/jenkins-nexus-password ]; then
    cat /run/secrets/jenkins-nexus-password | \
        docker login --username $(cat /run/secrets/jenkins-nexus-username) \
               --password-stdin ${DOCKER_REGISTRY}
fi

#-------------------------------------------------------------------------------
# Global Variables
#-------------------------------------------------------------------------------
DATE=`date +%Y%m%d`

REGISTRY_URL='registry-svrnd:5000/'
IMAGE_NAMES=( "${REGISTRY_URL}csg/os/oraclelinux" )
IMAGE_TAG=( "7.6" )
DOCKER_FILES=( 'Dockerfile' )
PUSH_IMAGE=( 1 )

#-------------------------------------------------------------------------------
# Process command line
#-------------------------------------------------------------------------------
unset build_args
unset extra_image_details
docker_cmd="docker"
no_cache='--no-cache'
do_push=1

OPTIND=1      # Reset in case getopts has been used previously in the shell.
while getopts "h-:" opt; do
    if [ "$opt" = "-" ]; then
        opt="${OPTARG%%=*}"
    fi
    case "$opt" in
        tls)
            export DOCKER_HOST=tcp://`hostname`:2376
            export DOCKER_CERT_PATH=~/dock_cert/
            docker_cmd="docker --tls"
            ;;
        vm73)
            export DOCKER_HOST=tcp://brilxvm73:2376
            export DOCKER_CERT_PATH=~/dock_cert/
            docker_cmd="docker --tls"
            ;;
        use_cache)
            unset no_cache
            ;;
        no_push)
            do_push=0
            ;;
        *)  echo "usage: ${0}"
            echo "         [--tls|--vm73]      vm73 has rhel subscriptions"
            echo "         [--use_cache]       Use existing cache (Defauly no-cache)"
            echo "         [--no_push]         Do not push the image";
            exit 2
            ;;
    esac
done

#-------------------------------------------------------------------------------
# zimageNameLatest/Date
#-------------------------------------------------------------------------------
function zimageNameLatest {
    echo "${IMAGE_NAMES[$1]}:latest-${IMAGE_TAG[$1]}"
}

function zimageNameDate {
    echo "${IMAGE_NAMES[$1]}:${DATE}-${IMAGE_TAG[$1]}"
}

#-------------------------------------------------------------------------------
# zcleanImages
#     Deletes the local images created
#-------------------------------------------------------------------------------
function zcleanImages {
    echo "### Cleaning up ###"
    if [ -z ${no_cache} ]; then
        echo "  Not cleaning up due to use-cache specified"
    else
        for (( i=0; i < ${#IMAGE_NAMES[@]}; i=i+1 )); do
            image_latest=$(zimageNameLatest $i)
            image_date=$(zimageNameDate $i)
            ${docker_cmd} rmi -f "${image_latest}" "${image_date}"
        done
    fi
    echo "### Clean up done ###"
}

#-------------------------------------------------------------------------------
# MAIN CODE
#-------------------------------------------------------------------------------

### Remove local images on script exit
trap zcleanImages EXIT

### Build and push each image, starting with the base image
for (( i=0; i < ${#IMAGE_NAMES[@]}; i=i+1 )); do
    image=${IMAGE_NAMES[$i]}
    dockerfile=${DOCKER_FILES[$i]}
    image_latest=$(zimageNameLatest $i)
    image_date=$(zimageNameDate $i)

    ### Build the image
    echo "Rebuilding: ${image}"
    if ! ${docker_cmd} image build ${no_cache} ${build_args} -t ${image_latest} -t ${image_date} -f ${dockerfile} .; then
        echo "!!! Failed to build image '${image_latest}' using Dockerfile '${dockerfile}' !!!"
        exit 1
    fi
    echo "### Successfully built: ${image} ###"

    if [[ $do_push -eq 1 && ${PUSH_IMAGE[$i]} -eq 1 ]];then
        echo "Pushing: ${image}"
        ### Push the image under each of its tags to the registry
        push_tags=( ${image_latest} ${image_date} )
        for t in ${push_tags[@]}; do
            if ! ${docker_cmd} push ${t}; then
                echo "!!! Failed to push image '${t}' !!!"
                exit 1
            fi
            echo "### Successfully pushed: ${t} ###"
        done
    else
        echo "Skipped pushing ${image}"
    fi
done

