#!/bin/sh
#
#   File: updateImage.sh 
#   Created: 14-Mar-2019 14:26:59
#   Creator: acoop
#   $Revision: $
#        
# ==================================================================================
#  COPYRIGHT (c) 1995-2019 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#
#      ./updateImage.sh
#
# DESCRIPTION:
#       Rebuilds and pushes the images registry-svrnd:5000/csg/sv/radiator:latest
#

#-------------------------------------------------------------------------------

# Login as 'jenkins' for push access
cat /run/secrets/jenkins-nexus-password | \
    docker login --username $(cat /run/secrets/jenkins-nexus-username) --password-stdin ${DOCKER_REGISTRY}

#-------------------------------------------------------------------------------
# Global Variables
#-------------------------------------------------------------------------------
DATE=`date +%Y%m%d`

LATEST_IMAGE="registry-svrnd:5000/csg/ct/radiator:latest"
LATEST_IMAGE_DATE="registry-svrnd:5000/csg/ct/radiator:${DATE}"

#-------------------------------------------------------------------------------
# zcleanImages
#     Deletes the local images created
#-------------------------------------------------------------------------------
function zcleanImages {
    echo "Removing local docker image"
	docker rmi -f ${LATEST_IMAGE} ${LATEST_IMAGE_DATE}
    if [[ $? != 0 ]]; then
        echo "Failed removing local docker image"
    fi
}

#-------------------------------------------------------------------------------
# MAIN CODE
#-------------------------------------------------------------------------------

echo "Rebuilding: ${LATEST_IMAGE}"
docker image build --no-cache -t ${LATEST_IMAGE} -f Dockerfile .
if [[ $? != 0 ]]; then
    echo "Failed building docker image"
    exit 1
fi

echo "Tagging"
docker tag ${LATEST_IMAGE} ${LATEST_IMAGE_DATE}
if [[ $? != 0 ]]; then
    echo "Failed taging docker image"
    exit 1
fi

echo "Pushing ${LATEST_IMAGE}"
docker push ${LATEST_IMAGE}
if [[ $? != 0 ]]; then
    zcleanImages
    echo "Failed to push the image"
    exit 1
fi

echo "Pushing ${LATEST_IMAGE_DATE}"
docker push ${LATEST_IMAGE_DATE}
if [[ $? != 0 ]]; then
    echo "Failed to push the image with date"
fi

zcleanImages
echo "Updated image successfully"
