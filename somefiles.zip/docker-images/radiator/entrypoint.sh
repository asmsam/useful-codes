#!/bin/bash

# Add TESTDB_OVERRIDE environment variable if set
if [[ ! -z $TESTDB_OVERRIDE ]];
then
    grep "TESTDB_OVERRIDE" intranet/conf/httpd.conf
    TESTDB_OVERRIDE_Exists=$?
    if [[ $TESTDB_OVERRIDE_Exists -eq 1 ]];
    then
        echo "
<VirtualHost *:8080>
  SetEnv TESTDB_OVERRIDE \${TESTDB_OVERRIDE}
</VirtualHost>
" >> /sv/app/intranet/conf/httpd.conf
  fi
fi

# start cron
sudo service crond start

# run apache
/usr/sbin/apachectl -DFOREGROUND -f /sv/app/intranet/conf/httpd.conf >> /sv/app/intranet/startup.log
