#!/bin/sh
# File:    buildImage.sh
# Created: 24-Feb-2022 000:00:00
# Creator: Andrew Coop  (acoop)
#
# USAGE:
#   buildImage.sh [-push] [-no-cache]
#
# DESCRIPTION:
#   Builds and optionally pushes the Singleview app image.
#-------------------------------------------------------------------------------
# set -x   # uncomment for debugging

#-------------------------------------------------------------------------------
# Process command line options.
#-------------------------------------------------------------------------------
no_cache='--no-cache'
dockerfile='Dockerfile-ol7.6-svwdev1b'
image_latest='785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/sv/oracle-database:latest-18.4xe-ol7.6-svwdev1b'

OPTIND=1      # Reset in case getopts has been used previously in the shell.
while getopts "h-:" opt; do
    if [ "$opt" = "-" ]; then
        opt="${OPTARG%%=*}"
    fi
    case "$opt" in
        use_cache)
            unset no_cache
            ;;
        *)
            echo 'Usage: buildImage.sh [--use_cache]'
            exit 2
            ;;
    esac
done

#-------------------------------------------------------------------------------
# Main code.
#-------------------------------------------------------------------------------

# Build and tag main images
docker image build ${no_cache} -t ${image_latest} -f ${dockerfile} . &&
docker image build --target no_dbf_files -t ${image_latest}-nodbf -f ${dockerfile} .

RC=$?

# Tag interum stages
[ $RC -eq 0 ] && docker image build --target base        -t db18-4-svwdev1b:base        -f ${dockerfile} .
[ $RC -eq 0 ] && docker image build --target orainstall  -t db18-4-svwdev1b:orainstall  -f ${dockerfile} .
[ $RC -eq 0 ] && docker image build --target oraminifier -t db18-4-svwdev1b:oraminifier -f ${dockerfile} .

exit $RC