#!/bin/ksh
#*********************************************************************
#        File: installPSU.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2018 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#
#      N/A
#
# DESCRIPTION:
#       Used to install the database patches.
#-------------------------------------------------------------------------------*/

#-------------------------------------------------------------------------------
# zinstallOPatch
#-------------------------------------------------------------------------------
function zinstallOPatch
{
    typeset RC=1

    # Parameters
    typeset OPatchZip="${1}"

    # Download patch
    if ! curl http://svrelease/release/oracle/OPatch/$OPatchZip -o $ORACLE_BASE/$OPatchZip; then
        echo "Failed to download patch $OPatchZip"
        exit 1
    fi

    # Install Opatch
    cd $ORACLE_HOME
    unzip $ORACLE_BASE/$OPatchZip
    RC=$?
    if [[ $RC -ne 0 && $RC -ne 1 ]]; then
        echo "Failed to unzip patch $OPatchZip"
        exit 1
    fi

    # Cleanup
    rm -f $ORACLE_BASE/$OPatchZip
}

#-------------------------------------------------------------------------------
# zinstallOraclePatch
#-------------------------------------------------------------------------------
function zinstallOraclePatch
{
    typeset RC=1

    # Parameters
    typeset OraPatchNumer="${1}"
    typeset OraPatchZip="${2}"

    # Download patch
    if ! curl http://svrelease/release/oracle/19.3/$OraPatchZip -o $ORACLE_BASE/$OraPatchZip; then
        echo "Failed to download patch $OraPatchZip"
        exit 1
    fi

    # Install patch
    cd $ORACLE_BASE
    unzip $OraPatchZip
    RC=$?
    if [[ $RC -ne 0 && $RC -ne 1 ]]; then
        echo "Failed to unzip patch $OraPatchZip"
        exit 1
    fi
    cd $OraPatchNumer/
    if ! PATH=$ORACLE_HOME/OPatch:$PATH opatch apply -silent; then
        echo "Failed to install patch $OraPatchZip"
        exit 1
    fi

    # Cleanup
    rm -rf $ORACLE_BASE/$OraPatchNumer
    rm -f $ORACLE_BASE/$OraPatchZip
    rm -f $ORACLE_BASE/PatchSearch.xml
}

#-------------------------------------------------------------------------------
# Main Code
#-------------------------------------------------------------------------------

# Install OPatch
zinstallOPatch p6880880_190000_Linux-x86-64.zip

# Install Patch
zinstallOraclePatch 29865658 p29865658_193000DBRU_Linux-x86-64.zip
