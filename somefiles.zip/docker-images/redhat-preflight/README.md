# Red Hat Preflight

## Overview

Red Hat Preflight is a tool that is used to certify Singleview container images with Red Hat.

This image extends the `stable` Preflight image from `quay.io/opdev/preflight` to add the following:

* The ECR credentials helper to allow Preflight to pull images from ECR when run on an AWS EC2 image with the necessary instance role attached to it.
* A docker `config.json` file to enable the use of the ECR credentials helper. 

The image can be built and used on any AWS environment that has `docker` or `podman` installed, is on an EC2 instance that has the necessary privileges to pull and push images from/to ECR, and has access to the `docker` socket.
This includes the `cbdev`, `pedev`, `webdev`, `k8sdev`, and possibly other container groups.

For environments using `podman`, replace all instances of `docker` below with `podman`.

## Building and pushing the image

To build the image, run the following:

````
docker build . -t 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/redhat/preflight:stable
````

To push the image, run:

````
docker push 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/redhat/preflight:stable
````

## Running the image

### Certification

To run the certification checks on an image, run the following, passing the full URL of the image to certify (e.g. `785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/release/singleview/singleview:12.00.06.01`) as the container image:

````
docker run -it --rm 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/redhat/preflight:stable \
       check container <container image>
````

Note that the image must be available from a container registry; locally tagged image with a registry name prefix cannot be used.

### Submit certification results

To submit the certification results after certifying the image, run the following:

````
docker run -it --rm 785148479268.dkr.ecr.ap-southeast-2.amazonaws.com/csg/redhat/preflight:stable \
       check container <container image> --certification-project-id <project_id> --pyxis-api-token <api_token>
````

The project Id and API token must be obtained from the Red Hat Partner Connect portal.
