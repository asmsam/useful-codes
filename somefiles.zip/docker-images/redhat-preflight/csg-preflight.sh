#!/bin/bash

PREFLIGHT_LOG=/tmp/preflight.log

# Run the Red Hat preflight utility using the passed in parameters.
/usr/local/bin/preflight $@ 2>&1 > ${PREFLIGHT_LOG} | tee ${PREFLIGHT_LOG}

RC=${PIPESTATUS[0]}

if [ $RC -eq 0 ]; then
  # Check if the preflight checks failed, even if the script returns a 0 exit code
  RC=$(grep -q "Preflight result: PASSED" ${PREFLIGHT_LOG})
fi

exit $RC
