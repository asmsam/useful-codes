#*********************************************************************
#        File: installDBBinaries.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2018 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#
#      N/A
#
# DESCRIPTION:
#       Used to install the database binaries.
#-------------------------------------------------------------------------------*/

INSTALL_DIR=$ORACLE_HOME
INSTALL_FILE=LINUX.X64_193000_db_home.zip
INSTALL_RSP=$ORACLE_BASE/install/db_inst.rsp

# Install Oracle binaries
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR       && \
curl -O http://svrelease/release/oracle/19.3/$INSTALL_FILE && \
unzip $INSTALL_FILE && \
rm $INSTALL_FILE    && \
$INSTALL_DIR/runInstaller -silent -force -waitforcompletion -responsefile $INSTALL_RSP && \
cd $HOME

# Ignore runInstaller warnings
true
