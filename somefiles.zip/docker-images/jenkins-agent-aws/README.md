# Jenkins Agent AWS

## Description
The jenkins agent docker image for use in AWS.

## Development
Refer to the Dockerfile for build instructions.

## Deployment
The final image should be built and pushed using the jenkins BASEIMAGES job
* http://jenkins-svrnd-aws:8080/jenkins/view/Docker%20Images/job/BASEIMAGES_jenkins-agent-aws/