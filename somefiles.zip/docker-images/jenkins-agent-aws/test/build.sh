#!/bin/bash

# Build the base image
docker build -f ../Dockerfile.awscliv2 -t jenkins-agent-aws ..
