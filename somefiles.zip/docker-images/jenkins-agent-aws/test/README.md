Tests for jenkins-agent-aws image
=================================

These tests are currently intended to be manual execution only.

```
sh test.sh
```