#!/bin/bash

# Build the base image
./build.sh
RC=$?
if [[ $RC != 0 ]]; then
    exit 1;
fi

# Build the test image
docker build -t jenkins-agent-aws-test .
RC=$?
if [[ $RC != 0 ]]; then
    exit 1;
fi

# Remove existing test container
docker inspect jenkins-agent-aws-test --type container >/dev/null 2>&1
RC=$?
if [[ $RC == 0 ]]; then
    docker rm jenkins-agent-aws-test
fi

# Run the test
docker run --rm --name jenkins-agent-aws-test jenkins-agent-aws-test


