#!/bin/env /sv/app/perl/product/perl-5.28.1/bin/perl

use strict;
use warnings;

use HTTP::Tiny;
use REST::Client;
use JIRA::REST;

# Show the environment variables
system("env");

sub test_svwid {
    # Lookup someone with svwid
    system("svwid -s pwi -r email") == 0
        or die "svwid lookup failed";
}
test_svwid();

sub test_perl_https {
    my $response = HTTP::Tiny->new->get('https://example.com/');

    if (not $response->{success}) {

        print "$response->{status} $response->{reason}\n";
        print "$response->{content}" if length $response->{content};

        die "perl https test failed!\n" unless $response->{success};
    }
}
test_perl_https();

# Test the jenkins agent connection
print("Manually test the jenkins agent connection by uncommenting\n");
print("the perltest.pl CMD in test/Dockerfile.\n");

# If we get here, the test is successful as the modules were loaded.
print("Test successful\n");
