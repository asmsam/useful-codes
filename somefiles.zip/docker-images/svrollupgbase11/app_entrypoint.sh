#!/bin/bash
# File:    app_entrypoint.sh
# Created: 24-July-2023 000:00:00
# Creator: Md Naseem  (nasmd001)
#
# USAGE:
#   app_entrypoint.sh
#
# DESCRIPTION:
#   Entry point for the container.
#-------------------------------------------------------------------------------
# set -x   # uncomment for debugging

#-------------------------------------------------------------------------------
# _fixetchosts
#
# For AWS ECS the network setup in a cluster of containers doesn't automatically
# allow us to reach other containers by hostname (eg. dbhost) so we populate
# /etc/hosts on startup if there is more than 1 container in the task
#-------------------------------------------------------------------------------

function _fixetchosts
{
    local task
    local region
    if [[ ! -z $ECS_CONTAINER_METADATA_URI ]];then
        # Get the list of expected container names from the task definition
        task=$(curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Family + ":" + .Revision')
        region=$(curl -s http://169.254.169.254/latest/meta-data/placement/region)
        aws ecs describe-task-definition --task-definition ${task} --region ${region}| \
            jq -r '.taskDefinition.containerDefinitions[].name'| \
            sort > /tmp/defn.list
        # Continue into the loop if we expect to have more than 1 container
        if [[ $(wc -l /tmp/defn.list) > 1 ]];then
            # Metadata is used to check the list of containers - this may not be fully populated until all containers are started
            curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Containers[].Name'|sort > /tmp/metadata.list
            # Keep checking until the running containers match the expected list
            while ! diff /tmp/metadata.list /tmp/defn.list;do
                sleep 10
                curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Containers[].Name'|sort >/tmp/metadata.list
            done
            # Containers are up, now set /etc/hosts
            curl $ECS_CONTAINER_METADATA_URI/task| \
                jq -r '.Containers[] | .Name,.Networks[0].IPv4Addresses[0]'| \
                sudo /usr/local/bin/fixetchosts
        fi

        rm -f /tmp/defn.list /tmp/metadata.list
    fi
}

function _installpackages
{
    # URL of the SV repository
    SV_REPO_URL="http://yum-svrnd.csgicorp.com/repos/ol/8/stable/x86_64/"

    # Packages to be installed
    packages=("haproxy-sv" "redis-server-sv")

    for package in "${packages[@]}"
    do
        if ! rpm -q $package; then
            echo "Installing $package."
            # Fetch the HTML content
            SV_REPO_PAGE_HTML_CONTENT=$(curl -s "$SV_REPO_URL")

            # Filter package based on version and get latest package
            LATEST_PACKAGE=$(echo "$SV_REPO_PAGE_HTML_CONTENT" | grep -o "$package-[0-9].*e.*\.x86_64\.rpm" | sed 's/">.*$//' | sort -r -g | head -n 1)

            # URL for the latest package
            LATEST_PACKAGE_URL="${SV_REPO_URL}${LATEST_PACKAGE}"

            # Install the latest package
            curl -O ${LATEST_PACKAGE_URL}
            sudo rpm -i ${LATEST_PACKAGE}

            # Retrive installed version
            rpm_installed_version=$(rpm -qp --queryformat '%{VERSION}' ${LATEST_PACKAGE} 2>/dev/null)

            # create a soft link
            updated_package_name="${package/-sv/}"
            sudo ln -s ${TPSDIR}/${updated_package_name}/product/${updated_package_name}-${rpm_installed_version} ${TPSDIR}/${updated_package_name}/rel

            # remove downloaded package
            rm -f ${LATEST_PACKAGE}
        else
            echo "$package is already installed."
        fi
    done
}

#-------------------------------------------------------------------------------
# Main Code
#-------------------------------------------------------------------------------
### Start sshd, which doesn't happen automatically
# Need to remove sshd.pid before starting sshd as it was found that in some occasions,
# when starting a new database container, the sshd.pid file existed when sshd was not running.
# The database then used this pid to run one of its processes and when we tried to restart sshd,
# we ended up killing the database instead. To avoid this we avoid using 'restart' or 'stop'.
# Instead, remove the incorrect pid file and start sshd.
sudo rm -f /var/run/sshd.pid
sudo rm -f /etc/ssh/ssh_host_rsa_key /etc/ssh/ssh_host_dsa_key
sudo ssh-keygen -f /etc/ssh/ssh_host_rsa_key -N '' -t rsa
sudo ssh-keygen -f /etc/ssh/ssh_host_dsa_key -N '' -t dsa
sudo systemctl start sshd.service

# Create /run/systemd/system so PCSD detects that systemd is in-use
#   Only needed as systemctl was replaced so it is not created automatically.
#   Note: This MUST be done before the pcsd and pcsd-ruby services are started.
sudo mkdir -p /run/systemd/system

# start pcsd
if [[ -n $START_PCSD ]];then
  GEM_HOME=/usr/lib/pcsd/vendor/bundle/ruby
   sudo systemctl disable pacemaker.service
   sudo systemctl disable corosync.service
   sudo systemctl enable pcsd.service
   sudo systemctl start pcsd.service pcsd-ruby.service
fi


# If a UID was passed in for the svdev user, update the user now.
if [[ -n $SVWDEV_UID ]];then
  echo "Setting svwdev uid to $SVWDEV_UID"
  sudo usermod -u $SVWDEV_UID svwdev
fi

_fixetchosts

# Run the waitForDbhost.sh if it exists
if [ -e ${ATA_BASE:-$HOME}/waitForDbhost.sh ]; then
    ${ATA_BASE:-$HOME}/waitForDbhost.sh
    if [ $? -ne 0 ]; then
        exit 1
    fi
fi

# Run the .profile if it exists
if [ -e ${ATA_BASE:-$HOME}/.profile ]; then
    . ${ATA_BASE:-$HOME}/.profile
else
    echo 'No profile loaded.'
fi

_installpackages

ERR_CODE=0
COMMANDS=$@
if [ -z "$COMMANDS" ];then
    sleep infinity
else
    unset COMMANDS
    "$@"
    ERR_CODE=$?
fi

exit $ERR_CODE
