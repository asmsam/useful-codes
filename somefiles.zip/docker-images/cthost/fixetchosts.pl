#!/bin/env perl
#---------------------------------------------------------------------------
#
#   File:       fixetchosts.pl
#   Created:    26-Mar-2020 12:08:19
#   Creator:    stw (Steven walker)
#
# ===========================================================================
# COPYRIGHT (C) 2017 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS
# AFFILIATES ("CSG INTERNATIONAL"). ALL RIGHTS RESERVED. THE INFORMATION
# CONTAINED WITHIN THIS DOCUMENT OR APPLICATION IS THE PROPERTY OF CSG
# INTERNATIONAL, WHICH IS CONFIDENTIAL AND PROTECTED BY INTERNATIONAL
# COPYRIGHT LAWS AND ANY UNAUTHORISED USE OF THIS DOCUMENT OR APPLICATION
# OR ITS CONTENTS MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. NO
# PART OF THIS DOCUMENT OR APPLICATION MAY BE PHOTOCOPIED, REPRODUCED
# OR TRANSLATED IN ANY FORM OR BY ANY MEANS, OR STORED IN A RETRIEVAL
# SYSTEM OR TRANSMITTED ELECTRONICALLYOR OTHERWISE, WITHOUT THE PRIOR
# WRITTEN CONSENT OF CSG INTERNATIONAL.
# ===========================================================================
#
# USAGE:
#   /usr/local/bin/fixetchosts.pl
#
# DESCRIPTION:
#   Fixes /etc/hosts in a cluster of ECS docker containers by copying
#   entries from /shared/hosts.  Used during entrypoint.sh processing
#
# EXIT STATUS:
#   0       - Succeeded
#   1       - Error (+ Description)
#   2       - Usage
#---------------------------------------------------------------------------

$MYHOST=`hostname`;
chomp $MYHOST;
open($fh,">>","/etc/hosts") || die "Could not open /etc/hosts for write";
# Loop through stdin (assumed to be from a list of hostnames and IP addresses)
# add that to /etc/hosts except for the current host
while(<>) {
    chomp;
    if(/^[0-9]/) {
        $ip = $_;
        if($host ne $MYHOST) {
            print $fh "$ip $host\n";
        }
    } else {
        $host = $_;
    }
}

