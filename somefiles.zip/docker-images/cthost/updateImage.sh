#!/bin/sh
#
#        File:    updateImages.sh
#     Created:    18-Jun-2018 14:26:59
#     Creator:    perkar02
#     Updated:    15-Jan-2020 00:00:00
#     Updated by: jansee01
#     $Revision: $
#
# ==================================================================================
#  COPYRIGHT (c) 1995-2021 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# ==================================================================================
#
# USAGE:
#
#   See zusage()
#
# DESCRIPTION:
#       Rebuilds and pushes the images
#         registry-svrnd:5000/csg/sv/oracle-database:latest-<SVapp version>-<DB version>-<OS_version>
#         registry-svrnd:5000/csg/sv/oracle-database:<yyyymmdd>-<SVapp version>-<DB version>-<OS_version>
#
#       Valid SV app versions
#         10, 11, 12
#
#       Valid DB versions
#         Oracle EE: ora12.1ee, ora19.3ee
#         Oracle SE: ora12.1se, ora19.3se
#
#       Valid OS versions
#         OracleLinux and Redhat : see zusage() for supported versions
#
#-------------------------------------------------------------------------------
#set -x   # uncomment for debugging

# Login as 'jenkins' for push access; otherwise assume we're already logged in
if [ -e /run/secrets/jenkins-nexus-password ]; then
    cat /run/secrets/jenkins-nexus-password | \
        docker login --username $(cat /run/secrets/jenkins-nexus-username) \
               --password-stdin ${DOCKER_REGISTRY}
fi

#-------------------------------------------------------------------------------
# Global Variables
#-------------------------------------------------------------------------------
DATE=`date +%Y%m%d`

REGISTRY_URL='785148479268.dkr.ecr.ap-southeast-2.amazonaws.com'
IMAGE_NAMES=( "${REGISTRY_URL}/csg/sv/cthost" )
DOCKER_FILES=( 'Dockerfile' )
PUSH_IMAGE=( 1 )

#-------------------------------------------------------------------------------
# Usage
#-------------------------------------------------------------------------------
function zusage() {
    echo "usage: ${0}"
    echo "         [--tls|--vm73]"
    echo "         [--app=(10|11|12)]                             Default: 10"
    echo "         [--db=(ora12.1ee|ora19.3ee "
    echo "         [      ora12.1se|ora19.3se|ora19.7ee)]         Default: ora12.1ee"
    echo "         [--os=(ol6.9|ol7.6|rhel6.9|rhel7.6|rhel7.7 "
    echo "         [      |rhel7.8|rhel7.9|rhel8.3|rhel8.4|rhel8.5|rhel8.6|rhel8.7|rhel8.8|rhel8.9)]      Default: ol6.9"
    echo "         [--use_cache]                                  Use existing cache (Defauly no-cache)"
    echo "         [--no_push]                                    Do not push the image"
    echo "         [--pcs_ver]                                    PCS version to use."
    echo "         [--pacemaker_ver]                              Pacemaker version to use."
    echo "         [--corosync_ver]                               Corosync version to use."
    exit 2
}

#-------------------------------------------------------------------------------
# Process command line
#-------------------------------------------------------------------------------
docker_cmd='docker'
app_version='10'
db_version='ora12.1ee'
os_version='ol6.9'
no_cache='--no-cache'
do_push=1

OPTIND=1
while getopts "h-:" opt; do
    if [ "$opt" = "-" ]; then
        opt="${OPTARG%%=*}"
    fi
    case "$opt" in
        app)
            app_version=${OPTARG#*=}
            if [ "${app_version}" == 'app' ]; then
                app_version="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            if [ -z ${app_version} ] || \
                ([ "${app_version}" != '10' ] && [ "${app_version}" != '11' ] && [ "${app_version}" != '12' ]); then
                echo "Invalid SV app version '${app_version}'"
                echo ''
                zusage
            fi
            ;;
        db)
            db_version=${OPTARG#*=}
            if [ "${db_version}" == 'db' ]; then
                db_version="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            if [ -z ${db_version} ] || \
                ([ "${db_version}" != 'ora12.1ee' ] && [ "${db_version}" != 'ora19.3ee' ] && \
                 [ "${db_version}" != 'ora12.1se' ] && [ "${db_version}" != 'ora19.3se' ] && [ "${db_version}" != 'ora19.7ee' ]); then
                echo "Invalid db version '${db_version}'"
                echo ''
                zusage
            fi
            ;;
        os)
            os_version=${OPTARG#*=}
            if [ "${os_version}" == 'os' ]; then
                os_version="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            if [ -z ${os_version} ] || \
                ([ "${os_version}" != 'ol6.9' ]   && [ "${os_version}" != 'ol7.6' ] && \
                 [ "${os_version}" != 'rhel6.9' ] && \
                 [ "${os_version}" != 'rhel7.6' ] && [ "${os_version}" != 'rhel7.7' ] && \
                 [ "${os_version}" != 'rhel7.8' ] && [ "${os_version}" != 'rhel7.9' ] && \
                 [ "${os_version}" != 'rhel8.3' ] && [ "${os_version}" != 'rhel8.4' ] && \
                 [ "${os_version}" != 'rhel8.5' ] && [ "${os_version}" != 'rhel8.6' ] && \
                 [ "${os_version}" != 'rhel8.7' ] && [ "${os_version}" != 'rhel8.8' ] && \
                 [ "${os_version}" != 'rhel8.9' ]); then
                echo "Invalid OS version '${os_version}' specified via --os"
                echo ''
                zusage
            fi
            ;;
        pcs_ver)
            opt_pcs_ver=${OPTARG#*=}
            if [ "${opt_pcs_ver}" == 'pcs_ver' ]; then
                opt_pcs_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        corosync_ver)
            opt_corosync_ver=${OPTARG#*=}
            if [ "${opt_corosync_ver}" == 'corosync_ver' ]; then
                opt_corosync_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        pacemaker_ver)
            opt_pacemaker_ver=${OPTARG#*=}
            if [ "${opt_pacemaker_ver}" == 'pacemaker_ver' ]; then
                opt_pacemaker_ver="${!OPTIND}"; OPTIND=$(( $OPTIND + 1 ))
            fi
            ;;
        tls)
            export DOCKER_HOST=tcp://`hostname`:2376
            export DOCKER_CERT_PATH=~/dock_cert/
            docker_cmd="docker --tls"
            ;;
        vm73)
            export DOCKER_HOST=tcp://brilxvm73:2376
            export DOCKER_CERT_PATH=~/dock_cert/
            docker_cmd="docker --tls"
            ;;
        use_cache)
            unset no_cache
            ;;
        no_push)
            do_push=0
            ;;
        *)  zusage
            ;;
    esac
done

#-------------------------------------------------------------------------------
# zcustomTag
#   Creates a custom tag.
#-------------------------------------------------------------------------------
function zcustomTag {
    local customTag

    if [ ! -z $opt_pcs_ver ]; then
        customTag="PCS${opt_pcs_ver}"
    fi

    if [ ! -z ${opt_corosync_ver} ]; then
        [[ ! -z ${customTag} ]] && customTag="${customTag}_"
        customTag="${customTag}COROSYNC${opt_corosync_ver}"
    fi

    if [ ! -z ${opt_pacemaker_ver} ]; then
        [[ ! -z ${customTag} ]] && customTag="${customTag}_"
        customTag="${customTag}PACEMAKER${opt_pacemaker_ver}"
    fi

    [[ ! -z ${customTag} ]] && customTag="-${customTag}"

    echo $customTag
}

#-------------------------------------------------------------------------------
# zdockerfileName
#   Returns the dockerfile to use
#-------------------------------------------------------------------------------

function zdockerfileName {
    local filename

    # For rhel os_major_ver will include only the major version component,
    # otherwise it will be set to the full os_version string
    local os_major_ver=$(echo $os_version | sed -e "s/\(rhel[0-9]\).[0-9]/\1/");

    if [[ "$os_major_ver" == "rhel7" ]] || [[ "$os_major_ver" == "rhel8" ]] &&
       # Exclude older versions rhel6.9 and rhel7.6 as they are not supported by the generic x files
       [[ "$os_version" != "rhel6.9" ]] && [[ "$os_version" != "rhel7.6" ]]; then
        filename="${app_version}-${db_version}-${os_major_ver}.x"

    else
        filename="${app_version}-${db_version}-${os_version}"
    fi

    echo $filename
}

#-------------------------------------------------------------------------------
# zimageNameLatest/Date
#-------------------------------------------------------------------------------

function zimageNameLatest {
    echo "${IMAGE_NAMES[$1]}:latest-${app_version}-${db_version}-${os_version}$(zcustomTag)"
}

function zimageNameDate {
    echo "${IMAGE_NAMES[$1]}:${DATE}-${app_version}-${db_version}-${os_version}$(zcustomTag)"
}

function zimageNameLatestOld {
    if [ "${db_version}" == 'ora19.3ee' ] && [ "${os_version}" == 'rhel7.6' ]; then
        echo "${IMAGE_NAMES[$1]}:${app_version}-ora19${os_version}-latest"
    elif [ "${db_version}" == 'ora19.3ee' ]; then
        echo "${IMAGE_NAMES[$1]}:${app_version}-${os_version}-latest"
    elif [ "${db_version}" == 'ora12.1ee' ]; then
        echo "${IMAGE_NAMES[$1]}:${app_version}-${os_version}-latest"
    else
        echo "$(zimageNameLatest $1)"
    fi
}

#-------------------------------------------------------------------------------
# zcleanImages
#     Deletes the local images created
#-------------------------------------------------------------------------------
function zcleanImages {
    echo "### Cleaning up ###"
    for (( i=0; i < ${#IMAGE_NAMES[@]}; i=i+1 )); do
        image_date=$(zimageNameDate $i)
        ${docker_cmd} rmi ${image_date}
        if [ -z ${no_cache} ]; then
            echo "  Not cleaning latest tag as use-cache has been specified"
        else
            image_latest=$(zimageNameLatest $i)
            image_latest_old=$(zimageNameLatestOld $i)
            echo ${docker_cmd} rmi ${image_latest} ${image_latest_old}
        fi
    done
    echo "### Clean up done ###"
}

#-------------------------------------------------------------------------------
# MAIN CODE
#-------------------------------------------------------------------------------

### Remove local images on script exit
trap zcleanImages EXIT

# Building the DB_TAG
db_version_int=$(echo $db_version | sed -e "s/ora//");
build_args="--build-arg DB_TAG="latest-${db_version_int}-${os_version}$(zcustomTag)""

### Build and push each image, starting with the base image
for (( i=0; i < ${#IMAGE_NAMES[@]}; i=i+1 )); do
    image="$(zimageNameLatest)"
    dockerfile="Dockerfile-$(zdockerfileName)"
    image_latest=$(zimageNameLatest $i)
    image_date=$(zimageNameDate $i)
    image_latest_old=$(zimageNameLatestOld $i)

    ### Build the image
    echo "Rebuilding: ${image} using ${dockerfile}"
    if ! ${docker_cmd} image build ${no_cache} ${build_args} -t ${image_latest} -t ${image_date} -t ${image_latest_old} -f ${dockerfile} .; then
        echo "!!! Failed to build image '${image_latest}' using Dockerfile '${dockerfile}' !!!"
        exit 1
    fi
    echo "### Successfully built: ${image} ###"

    if [[ $do_push -eq 1 && ${PUSH_IMAGE[$i]} -eq 1 ]];then
        echo "Pushing: ${image}"
        ### Push the image under each of its tags to the registry
        push_tags=( ${image_latest} ${image_date} ${image_latest_old} )
        for t in ${push_tags[@]}; do
            if ! ${docker_cmd} push ${t}; then
                echo "!!! Failed to push image '${t}' !!!"
                exit 1
            fi
            echo "### Successfully pushed: ${t} ###"
        done
    else
        echo "Skipped pushing ${image}"
    fi
done
