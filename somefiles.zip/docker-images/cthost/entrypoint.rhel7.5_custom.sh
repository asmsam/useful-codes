#!/bin/bash
#*********************************************************************
#        File: entrypoint.rhel7.5_custom.sh
# ==================================================================================
#  COPYRIGHT (c) 1995-2018 CSG SYSTEMS INTERNATIONAL, INC. AND/OR ITS AFFILIATES ( CSG ).
#  ALL RIGHTS RESERVED.
#
#  THIS SOFTWARE AND RELATED INFORMATION IS CONFIDENTIAL AND PROPRIETARY TO CSG
#  AND MAY NOT BE DISCLOSED, COPIED, MODIFIED, OR OTHERWISE USED EXCEPT IN
#  ACCORDANCE WITH THE LICENSE AGREEMENT ENTERED INTO WITH CSG. THIS INFORMATION
#  IS PROTECTED BY INTERNATIONAL COPYRIGHT LAWS AND ANY UNAUTHORIZED USE THEREOF
#  MAY VIOLATE COPYRIGHT, TRADEMARK, AND OTHER LAWS. ANY UNAUTHORIZED USE OF THIS
#  SOFTWARE AND/OR INFORMATION WILL AUTOMATICALLY TERMINATE YOUR RIGHT TO USE THIS
#  SOFTWARE AND/OR INFORMATION.
# =====================================================================================
#
# USAGE:
#
#      Used as the ENTRYPOINT on the docker cthost image
#
# DESCRIPTION:
#       This script is run as soon as the cthost container is created (entrypoint)
#       It is used to start the database and pacemaker using environment variables
#
#-------------------------------------------------------------------------------*/

function _printCloudwatchLinks() {
    local amiID instanceID instanceType asgGroupName
    local diskUsageURL memUsageURL cpuUsageURL

    instanceID=$(curl -f -s http://169.254.169.254/latest/meta-data/instance-id)
    [ -z ${instanceID} ] && echo 'Could not get instance ID' && return 0

    asgGroupName=$(aws ec2 describe-tags --filters Name=resource-id,Values=${instanceID} Name=key,Values=aws:autoscaling:groupName  --output text | awk '{print $5}')
    [ -z ${asgGroupName} ] && echo 'Could not get ASG groupName' && return 0

    amiID=$(curl -f -s http://169.254.169.254/latest/meta-data/ami-id)
    [ -z ${amiID} ] && echo 'Could not get ami ID' && return 0

    instanceType=$(curl -f -s http://169.254.169.254/latest/meta-data/instance-type)
    [ -z ${instanceType} ] && echo 'Could not get instance type' && return 0

    diskUsageURL="https://ap-southeast-2.console.aws.amazon.com/cloudwatch/home?"\
"region=ap-southeast-2#metricsV2:graph=~("\
"view~'timeSeries~stacked~false~region~'ap-southeast-2~start~'-P7D~end~'P0D~"\
"metrics~(~(~'CWAgent~'disk_used_percent~"\
"'path~'*2f~'InstanceId~'${instanceID}~'AutoScalingGroupName~'${asgGroupName}~"\
"'ImageId~'${amiID}~'InstanceType~'${instanceType}~'device~'nvme0n1p1~'fstype~'xfs)))"
    memUsageURL="https://ap-southeast-2.console.aws.amazon.com/cloudwatch/home?"\
"region=ap-southeast-2#metricsV2:graph=~("\
"view~'timeSeries~stacked~false~region~'ap-southeast-2~start~'-P7D~end~'P0D~"\
"metrics~(~(~'CWAgent~'mem_used_percent~"\
"'InstanceId~'${instanceID}~'AutoScalingGroupName~'${asgGroupName}~"\
"'ImageId~'${amiID}~'InstanceType~'${instanceType})))"
    cpuUsageURL="https://ap-southeast-2.console.aws.amazon.com/cloudwatch/home?"\
"region=ap-southeast-2#metricsV2:graph=~("\
"view~%27timeSeries~stacked~false~metrics~(~(~%27AWS*2fEC2~%27CPUUtilization~"\
"%27InstanceId~%27${instanceID}))~region~%27ap-southeast-2~start~%27-P28D~end~%27P0D);"\
"query=~%27*7bAWS*2fEC2*2cInstanceId*7d*20${instanceID}"

    echo "Disk Usage: ${diskUsageURL}"
    echo "Mem  Usage: ${memUsageURL}"
    echo "CPU  Usage: ${cpuUsageURL}"

    if [[ -n ${S3_LOG_LOCATION} && -n ${TEST_GROUP} && -n ${ATTEMPT_NUM} ]]; then
        cat <<EOF >/tmp/CloudWatchGraphs.html
<html>
  <h1>Cloud Watch Graphs</h1>
  <hr>
  <p><a href="${diskUsageURL}">Disk Usage</a></p>
  <p><a href="${memUsageURL}">Memory Usage</a></p>
  <p><a href="${cpuUsageURL}">CPU Usage</a></p>
</html>
EOF

        aws s3 cp /tmp/CloudWatchGraphs.html ${S3_LOG_LOCATION}/${TEST_GROUP}/attempt${ATTEMPT_NUM}/CloudWatchGraphs.html
        rm -f /tmp/CloudWatchGraphs.html
    fi
}

#Perform a clean shutdown of all databases.  Called from SIGINT and SIGTERM handlers.
function _shutdownDB() {
    if [[ -z $NO_DB_SHUTDOWN ]];then
        if [[ -n $ORACLE_HOME ]];then
            echo "Shutting down (immediate) database!"
            sudo -u sv_ora $ORACLE_HOME/bin/sqlplus / as sysdba <<EOF
                shutdown immediate;
                exit;
EOF
            sudo -u sv_ora $ORACLE_HOME/bin/lsnrctl stop
        fi

        _closePostgresDB
        echo "Database shutdown completed"
    fi
}

#Perform an emergency shutdown of all databases.  Called from SIGKILL handler.
function _abortDB() {
    if [[ -z $NO_DB_SHUTDOWN ]];then
        if [[ -n $ORACLE_HOME ]];then
            echo "Shutting down (abort) database!"
            sudo -u sv_ora $ORACLE_HOME/bin/sqlplus / as sysdba <<EOF
                shutdown abort;
                exit;
EOF
            sudo -u sv_ora $ORACLE_HOME/bin/lsnrctl stop
        fi

        _closePostgresDB
        echo "Database shutdown completed"
    fi
}

#Perform a graceful shutdown of all databases.  Called if script exits normally.
function _closeDB() {
    if [[ -z $NO_DB_SHUTDOWN ]];then
        echo "Shutting down database!"

        # Stop Oracle
        if [[ -n $ORACLE_HOME ]];then
            echo "Stopping Oracle"
            sudo -u sv_ora $ORACLE_HOME/bin/sqlplus / as sysdba <<EOF
                shutdown abort;
                startup;
                shutdown immediate;
                exit;
EOF
            sudo -u sv_ora $ORACLE_HOME/bin/lsnrctl stop
        fi

        _closePostgresDB
        echo "Database shutdown completed"
   fi
}

#Perform a clean shutdown of Postgres databases.  
#Can be called for normal termination of script or from SIGKILL, SIGINT and SIGTERM handlers.
function _closePostgresDB() {
    if [[ -n $PG_HOME ]];then
        echo "Stopping open-source Postgres"
        sudo systemctl stop postgresql-14
        sudo rm -f /tmp/.s.PGSQL.5432* /var/run/postgresql/.s.PGSQL*
    fi
    if [[ -n $EDB_HOME ]];then
        echo "Stopping EDB Postgres"
        sudo systemctl stop edb-as-14
        sudo rm -f /tmp/.s.PGSQL.5444*
        if [[ ! -s /var/lib/edb/as14/data/postmaster.pid ]];then
            sudo rm -f /var/lib/edb/as14/data/postmaster.pid
        fi
    fi
}

#Start up the Postgres databases and wait for them to be ready for user connections.  
function _startPostgresDB() {
    if [[ -n $PG_HOME ]];then
        echo "Starting open-source Postgres"
        sudo rm -f /tmp/.s.PGSQL.5432* /var/run/postgresql/.s.PGSQL*
        sudo systemctl start postgresql-14
        # Poll for 5 minutes checking if database ready to accept connections
        for i in {1..30};do
            echo "Waiting for database to start up, connection attempt $i of 30"
            
            if $PG_HOME/bin/pg_isready -p 5432;then
                echo "Open-source Postgres accepting connections"
                break
            fi
            sleep 10
        done
    else
        echo "Skipping open-source Postgres start"
    fi

    if [[ -n $EDB_HOME ]];then
        echo "Starting EDB Postgres"
        sudo rm -f /tmp/.s.PGSQL.5444*
        # Remove left-over lock file if it is empty
        if [[ ! -s /var/lib/edb/as14/data/postmaster.pid ]];then
            sudo rm -f /var/lib/edb/as14/data/postmaster.pid
        fi
        sudo systemctl start edb-as-14
        # Poll for 5 minutes checking if database ready to accept connections
        for i in {1..30};do
            echo "Waiting for database to start up, connection attempt $i of 30"
            
            if $EDB_HOME/bin/pg_isready -p 5444;then
                echo "EDB Postgres accepting connections"
                break
            fi
            sleep 10
        done
    else
        echo "Skipping EDB Postgres start"
    fi
}

#Start up the Oracle database and wait for it to be ready for user connections.  
function _startOracleDB() {
    if [[ -n $ORACLE_HOME ]];then
        echo "Starting Oracle"
        sudo -u sv_ora $ORACLE_HOME/bin/lsnrctl start
        sudo -u sv_ora $ORACLE_HOME/bin/sqlplus / as sysdba <<EOF
            startup open;
            exit;
EOF
    else
        echo "Skipping Oracle start"
    fi
}

########### SIGINT handler ############
function _int() {
   echo "SIGINT received, Stopping container."
   _shutdownDB
}

########### SIGTERM handler ############
function _term() {
   echo "SIGTERM received, Stopping container."
   _shutdownDB
}

########### SIGKILL handler ############
function _kill() {
   echo "SIGKILL received, Stopping container"
   _abortDB
}

# Set SIGINT handler
trap _int SIGINT

# Set SIGTERM handler
trap _term SIGTERM

# Set SIGKILL handler.  Note according to shellcheck SIGKILL can not be trapped.
trap _kill SIGKILL

# print cloudwatch links at the top of the logs
_printCloudwatchLinks

if [[ -n $START_DB ]];then
    _startOracleDB
    _startPostgresDB
fi

### Start sshd, which doesn't happen automatically
# Need to remove sshd.pid before starting sshd as it was found that in some occasions,
# when starting a new database container, the sshd.pid file existed when sshd was not running.
# The database then used this pid to run one of its processes and when we tried to restart sshd,
# we ended up killing the database instead. To avoid this we avoid using 'restart' or 'stop'.
# Instead, remove the incorrect pid file and start sshd.
sudo rm -f /var/run/sshd.pid
sudo rm -f /etc/ssh/ssh_host_rsa_key /etc/ssh/ssh_host_dsa_key
sudo ssh-keygen -f /etc/ssh/ssh_host_rsa_key -N '' -t rsa
sudo ssh-keygen -f /etc/ssh/ssh_host_dsa_key -N '' -t dsa
sudo systemctl start sshd.service

# start pcsd
if [[ -n $START_PCSD ]];then
  GEM_HOME=/usr/lib/pcsd/vendor/bundle/ruby
  sudo service pcsd start
fi

# If a UID was passed in for the svdev user, update the user now.
if [[ -n $SVDEV_UID ]];then
  echo "Setting svdev uid to $SVDEV_UID"
  sudo usermod -u $SVDEV_UID svdev
fi

# For AWS ECS the network setup in a cluster of containers doesn't automatically
# allow us to reach other containers by hostname (eg. dbhost) so we populate
# /etc/hosts on startup if there is more than 1 container in the task
if [[ ! -z $ECS_CONTAINER_METADATA_URI ]];then
    # Get the list of expected container names from the task definition
    TASK=$(curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Family + ":" + .Revision')
    aws ecs describe-task-definition --task-definition ${TASK} --region ap-southeast-2| \
        jq -r '.taskDefinition.containerDefinitions[].name'| \
        sort > /tmp/defn.list
    # Continue into the loop if we expect to have more than 1 container
    if [[ $(wc -l /tmp/defn.list) > 1 ]];then
        # Metadata is used to check the list of containers - this may not be fully populated until all containers are started
        curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Containers[].Name'|sort > /tmp/metadata.list
        # Keep checking until the running containers match the expected list
        while ! diff /tmp/metadata.list /tmp/defn.list;do
            sleep 10
            curl $ECS_CONTAINER_METADATA_URI/task|jq -r '.Containers[].Name'|sort >/tmp/metadata.list
        done
        # Containers are up, now set /etc/hosts
        curl $ECS_CONTAINER_METADATA_URI/task| \
            jq -r '.Containers[] | .Name,.Networks[0].IPv4Addresses[0]'| \
            sudo /usr/local/bin/fixetchosts
    fi
fi

ERR_CODE=0
COMMANDS=$@
if [[ -z $COMMANDS ]];then
    sleep infinity
else
    "$@"
    ERR_CODE=$?
fi

if [[ -n $START_DB ]];then
  _closeDB
fi

# print cloudwatch links at the bottom of the logs
_printCloudwatchLinks

exit $ERR_CODE
